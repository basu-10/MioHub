# Chrome Extension - Quick Reference

## 🚀 Quick Start Commands

```powershell
# 1. Run migration (one-time)
python migrate_add_extension_api_tokens.py

# 2. Start server
python flask_app.py

# 3. Visit settings page
# http://localhost:5555/extension-settings

# 4. Load extension in Chrome
# chrome://extensions/ → Developer mode ON → Load unpacked → Select chrome_extension/
```

## 🔑 API Token Management

**Generate Token:**
```
Visit: http://localhost:5555/extension-settings
Click: Generate API Token
Copy: Token displayed on page
```

**Test Token with curl:**
```bash
# Verify token
curl -X POST http://localhost:5555/api/extension/verify-token \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"

# Get folders
curl http://localhost:5555/api/extension/folders \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"

# Save text
curl -X POST http://localhost:5555/api/extension/save-content \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d "{\"type\":\"text\",\"content\":\"Hello from curl\",\"title\":\"Test\"}"
```

## 🎯 Extension Usage

**Method 1: Popup Interface**
1. Click extension icon in toolbar
2. Use buttons:
   - Save Current Page URL
   - Save Selected Text
   - Save Image from Page

**Method 2: Context Menu (Right-Click)**
- On images → "Save Image to MioHub"
- On links → "Save Link to MioHub"
- On selected text → "Save Text to MioHub"
- On page → "Save Page URL to MioHub"

## 📁 Folder Selection

**Set Default Folder:**
1. Open extension popup
2. Select folder from dropdown
3. Click "Set as Default"

**Folders are hierarchical:**
```
🏠 root
  📁 Work
    📁 Projects
  📁 Personal
    📁 Bookmarks
```

## 🐛 Troubleshooting

**Extension not loading:**
```powershell
# Check for syntax errors
cd chrome_extension
python -m json.tool manifest.json
```

**API not responding:**
```powershell
# Test if server is running
curl http://localhost:5555/health

# Check blueprint registration
python -c "from blueprints import bps; print(len(bps))"
```

**Token issues:**
```sql
-- Check token in database
SELECT id, username, api_token IS NOT NULL as has_token, api_token_expires 
FROM user 
WHERE username = 'testuser';
```

**Clear extension storage:**
```javascript
// In extension popup console (right-click icon → Inspect)
chrome.storage.local.clear(() => console.log('Storage cleared'));
```

## 📊 Database Queries

**Check tokens:**
```sql
SELECT username, 
       LEFT(api_token, 10) as token_preview,
       api_token_expires,
       TIMESTAMPDIFF(DAY, NOW(), api_token_expires) as days_remaining
FROM user 
WHERE api_token IS NOT NULL;
```

**Recent saves from extension:**
```sql
SELECT f.id, f.title, f.type, f.created_at, u.username, fo.name as folder_name
FROM files f
JOIN user u ON f.owner_id = u.id
JOIN folder fo ON f.folder_id = fo.id
WHERE f.type = 'proprietary_note'
  AND f.metadata_json->'$.source_url' IS NOT NULL
ORDER BY f.created_at DESC
LIMIT 10;
```

## 🔄 Development Workflow

**After making changes to extension:**
```
1. Save files
2. Go to chrome://extensions/
3. Click refresh icon on MioHub extension
4. Close and reopen popup
5. Test changes
```

**After making API changes:**
```powershell
# Restart Flask server
Ctrl+C  # Stop server
python flask_app.py  # Start again
```

## 📦 Distribution

**Create ZIP for distribution:**
```powershell
cd chrome_extension
# Exclude unnecessary files
Compress-Archive -Path manifest.json,popup.*,background.js,icons -DestinationPath ..\chrome_extension.zip
```

**Upload to PythonAnywhere:**
```bash
# In PythonAnywhere console
cd mysite/static
wget your-domain.com/chrome_extension.zip
unzip chrome_extension.zip -d chrome_extension/
```

## 🎨 Customization

**Change icons:**
1. Replace files in `chrome_extension/icons/`
2. Must be PNG format
3. Sizes: 16x16, 48x48, 128x128
4. Reload extension in Chrome

**Update server URL:**
```javascript
// In popup.js
let serverUrl = 'https://your-domain.com';  // Change default
```

**Add new content type:**
1. Update `extension_api.py` save_content()
2. Add button in `popup.html`
3. Add handler in `popup.js`
4. Test thoroughly

## 🔐 Security Best Practices

**Token Security:**
- Never commit tokens to git
- Revoke tokens if exposed
- Use HTTPS in production
- Set short expiration for sensitive accounts

**Extension Permissions:**
- Only request needed permissions
- Review manifest regularly
- Document why each permission is needed

**API Security:**
- Add rate limiting in production
- Log suspicious activity
- Validate all inputs
- Use HTTPS only in production

## 📞 Support Checklist

When reporting issues, provide:
- [ ] Browser version (chrome://version)
- [ ] Extension manifest version
- [ ] Server URL being used
- [ ] Console errors (F12 → Console)
- [ ] Network tab showing failed requests
- [ ] Steps to reproduce

## 🎓 Learning Resources

**Chrome Extension Docs:**
- https://developer.chrome.com/docs/extensions/
- Manifest V3: https://developer.chrome.com/docs/extensions/mv3/intro/

**Flask API Patterns:**
- https://flask.palletsprojects.com/
- Flask-Login: https://flask-login.readthedocs.io/

**Testing Tools:**
- Postman: https://www.postman.com/
- curl: https://curl.se/docs/
- HTTPie: https://httpie.io/

## ✅ Verification Checklist

Before going live:
- [ ] Migration ran successfully
- [ ] Extension loads in Chrome
- [ ] Settings page accessible
- [ ] Token generation works
- [ ] Token verification works
- [ ] Folder dropdown populates
- [ ] Text saving works
- [ ] Image saving works
- [ ] URL saving works
- [ ] Context menus appear
- [ ] Storage quota enforced
- [ ] Error messages clear
- [ ] Loading states work
- [ ] Icons display correctly
- [ ] Documentation complete
