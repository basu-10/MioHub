# Chrome Extension - Smart URL Grouping

## Overview

The Chrome extension now uses **smart URL grouping** to prevent file proliferation. Instead of creating a new file for each save from the same webpage, all content from the same URL is appended to a single file.

## Design Decision

### Problem (Before)
- User saves 5 text snippets from the same article → 5 separate files created
- Cluttered "Web Clippings" folder with dozens of similar files
- Hard to find related content
- Inefficient storage tracking

### Solution (After)
- User saves 5 text snippets from same article → 1 file with 5 clips separated by visual dividers
- Clean folder structure (one file per source)
- Temporal context preserved (newest clips at bottom)
- Efficient delta-based quota tracking

## Technical Implementation

### Database Schema

**New Column: `files.source_url`**
```sql
ALTER TABLE files 
ADD COLUMN source_url VARCHAR(2048) NULL,
ADD INDEX idx_files_source_url (source_url(255));
```

### URL Normalization

URLs are normalized before comparison to ensure grouping works correctly:

```python
# Before normalization:
https://example.com/article?utm_source=twitter#section
https://example.com/article/
https://example.com/article

# After normalization (all become):
https://example.com/article
```

**Normalization Rules:**
1. Strip query parameters (`?utm_source=...`)
2. Strip fragments (`#section`)
3. Remove trailing slashes (`/`)
4. Preserve scheme, domain, and path

### File Grouping Logic

```python
def find_or_create_extension_file(user, folder, normalized_url, page_title):
    """
    Find existing file for this URL or create a new one.
    Returns: (file, is_new)
    """
    if normalized_url:
        # Try to find existing file by normalized source URL
        existing = File.query.filter_by(
            owner_id=user.id,
            folder_id=folder.id,
            source_url=normalized_url,
            type='proprietary_note'
        ).first()
        
        if existing:
            return existing, False
    
    # Create new file if no match
    return create_new_file(...), True
```

### Content Appending

Clips are separated with a visual divider:

```html
<!-- First clip -->
<p>📌 Saved: 2026-01-07 10:30:00</p>
<div>First text content...</div>
<p>🔗 <a href="...">source</a></p>

<!-- Visual separator -->
<hr style="border: none; border-top: 2px dashed #888; margin: 30px 0; opacity: 0.5;" />

<!-- Second clip -->
<p>📌 Saved: 2026-01-07 11:45:00</p>
<div>Second text content...</div>
<p>🔗 <a href="...">source</a></p>
```

### Quota Tracking (Delta-Based)

**CRITICAL:** Quota updates use size delta, not total file size.

```python
# Calculate old size
old_content_size = len(target_file.content_html.encode('utf-8')) if target_file.content_html else 0

# Append new content
target_file.content_html = append_to_html_content(target_file.content_html, new_content)

# CRITICAL: Flag modified for LONGTEXT column
flag_modified(target_file, 'content_html')

# Calculate new size and delta
new_content_size = len(target_file.content_html.encode('utf-8'))
content_delta = new_content_size - old_content_size

# Update quota with delta only
update_user_data_size(user, content_delta + image_bytes)
```

**Why Delta Matters:**
- ❌ Wrong: `update_user_data_size(user, new_content_size)` → Double-counts existing content
- ✅ Correct: `update_user_data_size(user, content_delta)` → Only adds new bytes

### Metadata Tracking

Each file tracks clip statistics:

```json
{
  "created_by": "chrome_extension",
  "clip_count": 5,
  "last_clip_at": "2026-01-07T11:45:00"
}
```

## User Experience

### Extension Response

```json
{
  "success": true,
  "message": "Content updated in \"Web Clippings\" (clip #5)",
  "file": {
    "id": 123,
    "title": "Article Title - Web Clips",
    "is_new": false,
    "clip_count": 5,
    "created_at": "2026-01-07 10:00:00",
    "last_modified": "2026-01-07 11:45:00"
  }
}
```

**User sees:**
- "Content updated in 'Web Clippings' (clip #5)" → Clear feedback about append operation
- `is_new: false` → Extension can show different icon/animation for updates
- `clip_count: 5` → User knows how many clips are in this file

### File Title Strategy

1. **First save:** Uses `page_title` from tab (e.g., "How to Cook Pasta - Recipe Guide")
2. **Subsequent saves:** Title stays the same (preserves first clip context)
3. **Fallback:** If no page title, uses `"Web Clips - 2026-01-07"`

## Edge Cases & Limitations

### Mixed Content Types

**Scenario:** User saves text, then image, then text from same URL

**Behavior:** All appended to same file with appropriate HTML
```html
<p>Text clip...</p>
<hr />
<img src="..." />
<hr />
<p>Another text clip...</p>
```

### URL Variations

**Grouped (same normalized URL):**
- `https://blog.com/post?utm_source=twitter` ✓
- `https://blog.com/post#section2` ✓
- `https://blog.com/post/` ✓

**Not grouped (different normalized URLs):**
- `https://blog.com/post` vs `https://blog.com/post2` ✗
- `https://blog.com` vs `https://www.blog.com` ✗
- `http://blog.com` vs `https://blog.com` ✗

### No URL Provided

If extension doesn't send `url` field, each save creates a new file (fallback to old behavior).

### Unbounded Growth

**Current:** No limit on clips per file

**Future consideration:** If file exceeds certain size (e.g., 5MB or 100 clips), create new file with timestamp suffix:
- "Article Title - Web Clips"
- "Article Title - Web Clips (2)"
- "Article Title - Web Clips (3)"

## Migration

Run migration script to add `source_url` column:

```bash
python migrate_add_source_url_column.py
```

**Safety:** Migration checks if column exists before adding. Safe to run multiple times.

## Testing Checklist

- [ ] Save text from same URL → appends to existing file
- [ ] Save image from same URL → appends with separator
- [ ] Save URL bookmark from same page → appends
- [ ] URLs with query params grouped correctly
- [ ] URLs with fragments grouped correctly
- [ ] Quota delta calculated correctly (not double-counting)
- [ ] Clip count increments properly
- [ ] Timestamp headers show correct times
- [ ] Guest users hit quota limits appropriately
- [ ] No URL provided → creates separate files (fallback)

## Performance Considerations

- **Index on `source_url(255)`** enables fast lookups (first 255 chars indexed)
- **Single DB query** to find existing file by URL
- **Delta calculation** is O(1) - just string length difference
- **No N+1 queries** - folder retrieved once, file looked up once

## Security Notes

- **URL length limit:** 2048 chars (standard browser URL limit)
- **HTML escaping:** All user text properly escaped before storage
- **Quota enforcement:** Checked before append operation
- **Token verification:** Standard bearer token auth

## Future Enhancements

1. **User preference:** Toggle between "group by URL" vs "always create new file"
2. **Manual split:** Button in UI to split large grouped file into individual clips
3. **Smart titles:** Update title if user saves from different section of same article
4. **Clip navigation:** Table of contents for files with many clips
5. **Max clips per file:** Configurable limit (default: unlimited)

## Documentation References

- Model changes: `blueprints/p2/models.py` (line 275)
- Migration script: `migrate_add_source_url_column.py`
- Extension API: `blueprints/p2/extension_api.py` (`save_content` endpoint)
- Chrome extension: `.DOCS/reference/CHROME_EXTENSION_SUMMARY.md`
