# Chrome Extension UI - Visual Examples

## Folder View Card

```
┌──────────────────────────────────────────────────┐
│ 📌                                          🌐   │  ← Badges (pin + public)
├──────────────────────────────────────────────────┤
│                                                  │
│  Article Title - Web Clips                      │  ← Title (clickable)
│                                                  │
│  ╔════════════════════════════════════════════╗ │
│  ║ ℹ️  🌐 Extension                           ║ │  ← Extension badge (teal)
│  ║    https://blog.com/article  [5 clips]    ║ │  ← URL + clip count
│  ╚════════════════════════════════════════════╝ │
│                                                  │
│  Lorem ipsum dolor sit amet, consectetur        │  ← Content preview
│  adipiscing elit...                             │
│                                                  │
│  📝 MioNote                                      │  ← File type indicator
└──────────────────────────────────────────────────┘
```

**Color Scheme:**
- Extension section has light teal background: `rgba(20, 184, 166, 0.1)`
- Badge uses teal: `#14b8a6`
- URL is clickable link in teal color

## Edit Page (Description Stubs Section)

```
Description stubs
───────────────────────────────────────────────────

┌─────────────────────────────────────────────────────────────┐
│ 🌐  Saved from Chrome extension                             │
│                                                              │
│     🔗 https://www.example.com/article/how-to-code          │
│        [3 clips saved]                                      │
└─────────────────────────────────────────────────────────────┘
                        ↑ 
                Light teal background
                Non-editable banner


[1]  ┌────────────────────────────────────────┐  [×]
     │ Python tutorial                        │
     └────────────────────────────────────────┘

[2]  ┌────────────────────────────────────────┐  [×]
     │ Tutorial                               │
     └────────────────────────────────────────┘
                        ↑
              Editable description stubs

[+] Add description

Add a brief description to help identify this note.
You can create multiple description stubs for saving urls, tags, etc.
```

## Multiple Clips View

When a user saves multiple clips from the same URL, the content shows:

```html
📌 Saved: 2026-01-07 10:30:00
First text content that user selected...
🔗 https://blog.com/article

─────────────────────────────────────────
                ↑
          Visual separator

📌 Saved: 2026-01-07 11:45:00
Second text content from same article...
🔗 https://blog.com/article

─────────────────────────────────────────

📌 Saved: 2026-01-07 15:20:00
Third clip with an image below
[Image displayed here]
🔗 https://blog.com/article
```

## Comparison: Extension vs Manual Note

### Extension-Created Note
```
┌────────────────────────────────────────┐
│  Web Article - Jan 7                   │
│                                        │
│  ╔══════════════════════════════════╗ │
│  ║ 🌐 Extension                     ║ │  ← Shows source
│  ║    blog.com/article  [2 clips]   ║ │
│  ╚══════════════════════════════════╝ │
│                                        │
│  Content preview...                    │
└────────────────────────────────────────┘
```

### Regular Manual Note
```
┌────────────────────────────────────────┐
│  My Meeting Notes                      │
│                                        │
│  ℹ️  Meeting                           │  ← Regular description
│     Planning                            │
│                                        │
│  Content preview...                    │
└────────────────────────────────────────┘
```

## Responsive Behavior

### Desktop (>1024px)
- Full URL displayed in cards
- Badge and clip count on same line
- Extension banner full width

### Tablet (768-1024px)
- URL truncated to 60 chars in cards
- Badge and URL stack on narrow cards
- Banner remains full width

### Mobile (<768px)
- URL truncated to 40 chars
- Extension badge + URL stacked
- Banner compact with smaller font

## State Variations

### New Save (1 clip)
```
🌐 Extension
   https://example.com/article
```

### Multiple Clips (5 clips)
```
🌐 Extension
   https://example.com/article  [5 clips]
```

### Long URL (truncated in cards)
```
🌐 Extension
   https://very-long-domain-name.com/very/dee...  [3 clips]
```

## Theme Integration

Uses existing Carbon Teal theme variables:
- `var(--accent)` - Teal accent color
- `var(--bg)` - Dark background
- `var(--card)` - Card background
- `var(--muted)` - Muted text color

**Light overlay for extension info:**
```css
background: rgba(20, 184, 166, 0.1);  /* 10% opacity teal */
border: 1px solid var(--accent);       /* Teal border */
border-radius: 6px;
padding: 4px 8px;
```

## Accessibility Features

1. **Semantic HTML**
   - `<a>` for links (keyboard navigable)
   - `<span>` for badges (proper ARIA if needed)
   - `<div>` with proper structure

2. **Color Contrast**
   - Teal on dark background meets WCAG AA
   - Badge text white on teal (high contrast)
   - URL text teal with underline on hover

3. **Screen Readers**
   - Icons paired with text labels
   - Links have descriptive text
   - Badges announce count clearly

4. **Keyboard Navigation**
   - All links are tabbable
   - Focus visible on links
   - No keyboard traps

## Print Styles (Future)

When printing, extension info should:
- Show full URL (no truncation)
- Remove interactive elements (badges become text)
- Maintain source attribution
- Include timestamp of save

---

**Design Rationale:** The extension source is visually distinct but not overwhelming. Users can quickly identify web-clipped content while maintaining clean aesthetics for manually created notes.
