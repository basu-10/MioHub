from PIL import Image, ImageDraw

def create_icon(size, filename):
    """Create a simple teal bookmark icon"""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Calculate dimensions
    margin = size // 6
    
    # Draw rounded rectangle (bookmark shape)
    draw.rounded_rectangle(
        [(margin, margin), (size - margin, size - margin)],
        radius=size // 6,
        fill='#14b8a6'
    )
    
    # Draw V-notch at bottom for bookmark effect
    notch_width = size // 4
    notch_height = size // 5
    center_x = size // 2
    bottom_y = size - margin
    
    draw.polygon([
        (center_x - notch_width // 2, bottom_y),
        (center_x, bottom_y - notch_height),
        (center_x + notch_width // 2, bottom_y),
        (center_x, bottom_y)
    ], fill='#14b8a6')
    
    img.save(filename, 'PNG')
    print(f'Created {filename}')

# Generate icons
create_icon(16, 'chrome_extension/icons/icon16.png')
create_icon(48, 'chrome_extension/icons/icon48.png')
create_icon(128, 'chrome_extension/icons/icon128.png')

print('\n✓ All icons generated successfully!')
