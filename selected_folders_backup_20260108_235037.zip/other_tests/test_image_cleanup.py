"""
Test script to verify that deleting notes/boards also cleans up orphaned images.

This script:
1. Creates a test user
2. Creates a note with an image
3. Deletes the note
4. Verifies that the orphaned image is cleaned up
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import User, Note, Folder
from blueprints.p2.utils import cleanup_orphaned_images_for_user
import config
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_image_cleanup():
    with app.app_context():
        print("=" * 60)
        print("Testing Image Cleanup on Note Deletion")
        print("=" * 60)
        
        # Find or create test user
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            print("ERROR: Test user 'testuser' not found. Please run init_db.py first.")
            return
        
        user_id = test_user.id
        print(f"\n1. Using test user: {test_user.username} (ID: {user_id})")
        
        # Create a root folder if needed
        root_folder = Folder.query.filter_by(user_id=user_id, parent_id=None).first()
        if not root_folder:
            root_folder = Folder(name='root', user_id=user_id)
            db.session.add(root_folder)
            db.session.commit()
            print(f"   Created root folder (ID: {root_folder.id})")
        
        # Create a test note with fake image reference
        # In real scenario, this would be an actual uploaded image
        test_image_path = f"/static/uploads/images/{user_id}_test_fake_image.webp"
        test_content = f'<p>Test note with image</p><img src="{test_image_path}" alt="test">'
        
        test_note = Note(
            title="Test Note for Cleanup",
            content=test_content,
            user_id=user_id,
            folder_id=root_folder.id
        )
        db.session.add(test_note)
        db.session.commit()
        print(f"\n2. Created test note (ID: {test_note.id})")
        print(f"   Content contains: {test_image_path}")
        
        # Count images before deletion
        from values_main import UPLOAD_FOLDER
        user_images_before = [f for f in os.listdir(UPLOAD_FOLDER) if f.startswith(f"{user_id}_")]
        print(f"\n3. User images before deletion: {len(user_images_before)}")
        
        # Delete the note
        note_id = test_note.id
        db.session.delete(test_note)
        db.session.commit()
        print(f"\n4. Deleted note (ID: {note_id})")
        
        # Run cleanup
        deleted_count, freed_bytes = cleanup_orphaned_images_for_user(user_id)
        print(f"\n5. Cleanup results:")
        print(f"   - Deleted images: {deleted_count}")
        print(f"   - Freed bytes: {freed_bytes}")
        
        # Count images after deletion
        user_images_after = [f for f in os.listdir(UPLOAD_FOLDER) if f.startswith(f"{user_id}_")]
        print(f"\n6. User images after cleanup: {len(user_images_after)}")
        
        print("\n" + "=" * 60)
        print("Test Complete!")
        print("=" * 60)
        
        if deleted_count > 0:
            print("✓ SUCCESS: Orphaned images were cleaned up")
        else:
            print("ℹ INFO: No orphaned images to clean up (expected if no actual image files exist)")

if __name__ == "__main__":
    test_image_cleanup()
