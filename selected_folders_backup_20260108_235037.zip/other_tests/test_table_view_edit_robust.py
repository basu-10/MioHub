"""
End-to-end test for table file view and edit functionality.
Tests both Luckysheet format and legacy Tabulator format conversion.
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, User, Folder
from datetime import datetime
import config
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SECRET_KEY'] = 'test-key'
db.init_app(app)

def test_luckysheet_format():
    """Test table file with proper Luckysheet format."""
    print("\n=== Testing Luckysheet Format ===")
    
    with app.app_context():
        # Get test user
        user = User.query.filter_by(username='testuser').first()
        if not user:
            print("⚠️  Test user not found. Run init_db.py first.")
            return False
        
        # Get user's root folder
        folder = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
        if not folder:
            print("⚠️  Root folder not found.")
            return False
        
        # Create Luckysheet format data
        luckysheet_data = [
            {
                "name": "Products",
                "color": "",
                "status": 1,
                "order": 0,
                "data": [
                    ["Product", "Price", "Stock", "Category"],
                    ["Widget A", 19.99, 100, "Hardware"],
                    ["Widget B", 29.99, 50, "Software"],
                    ["Widget C", 39.99, 75, "Hardware"]
                ],
                "config": {},
                "index": 0
            },
            {
                "name": "Orders",
                "color": "",
                "status": 0,
                "order": 1,
                "data": [
                    ["Order ID", "Customer", "Total"],
                    [1001, "John Doe", 59.98],
                    [1002, "Jane Smith", 119.96]
                ],
                "config": {},
                "index": 1
            }
        ]
        
        # Create file
        table_file = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='table',
            title='Test Luckysheet Table',
            content_json=luckysheet_data,
            metadata_json={'description': 'Test table with Luckysheet format'},
            created_at=datetime.utcnow(),
            last_modified=datetime.utcnow()
        )
        
        db.session.add(table_file)
        db.session.commit()
        
        # Verify
        retrieved = File.query.get(table_file.id)
        if retrieved.content_json == luckysheet_data:
            print(f"✅ Luckysheet table created successfully (ID: {table_file.id})")
            print(f"   Sheets: {len(retrieved.content_json)}")
            print(f"   First sheet rows: {len(retrieved.content_json[0]['data'])}")
            return table_file.id
        else:
            print("❌ Data mismatch after save")
            return False

def test_tabulator_legacy_format():
    """Test table file with legacy Tabulator format."""
    print("\n=== Testing Tabulator Legacy Format ===")
    
    with app.app_context():
        # Find existing Tabulator format table
        legacy_table = File.query.filter_by(type='table', title='Product Inventory').first()
        
        if legacy_table:
            print(f"✅ Found legacy Tabulator table (ID: {legacy_table.id})")
            print(f"   Format: {type(legacy_table.content_json)}")
            
            # Check structure
            content = legacy_table.content_json
            if isinstance(content, dict) and 'data' in content and 'columns' in content:
                print(f"   Rows: {len(content['data'])}")
                print(f"   Columns: {len(content['columns'])}")
                print("   ✓ Proper Tabulator format")
                
                # Test conversion logic (simulated)
                headers = [col.get('title', col.get('field', '')) for col in content['columns']]
                rows = [headers]
                for row in content['data']:
                    row_data = [row.get(col['field'], '') for col in content['columns']]
                    rows.append(row_data)
                
                converted = [{
                    "name": "Sheet1",
                    "color": "",
                    "status": 1,
                    "order": 0,
                    "data": rows,
                    "config": {},
                    "index": 0
                }]
                
                print(f"   ✓ Conversion test: {len(converted[0]['data'])} rows (including header)")
                return legacy_table.id
            else:
                print("   ⚠️  Unexpected format")
                return False
        else:
            print("⚠️  No legacy Tabulator table found")
            return False

def test_empty_table():
    """Test table file with no data."""
    print("\n=== Testing Empty Table ===")
    
    with app.app_context():
        user = User.query.filter_by(username='testuser').first()
        folder = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
        
        # Create empty table
        empty_table = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='table',
            title='Empty Table Test',
            content_json=[{
                "name": "Sheet1",
                "color": "",
                "status": 1,
                "order": 0,
                "data": [[""]],
                "config": {},
                "index": 0
            }],
            metadata_json={},
            created_at=datetime.utcnow(),
            last_modified=datetime.utcnow()
        )
        
        db.session.add(empty_table)
        db.session.commit()
        
        print(f"✅ Empty table created (ID: {empty_table.id})")
        return empty_table.id

def test_view_edit_routes():
    """Test that view and edit routes work for table files."""
    print("\n=== Testing View/Edit Routes ===")
    
    with app.app_context():
        # Find all table files
        tables = File.query.filter_by(type='table').all()
        
        if not tables:
            print("⚠️  No table files to test")
            return False
        
        print(f"Found {len(tables)} table file(s):")
        for table in tables:
            print(f"\n  📊 {table.title} (ID: {table.id})")
            print(f"     Owner: User {table.owner_id}")
            print(f"     Format: {type(table.content_json).__name__}")
            
            # Simulate what templates will see
            content = table.content_json
            if isinstance(content, list):
                print(f"     ✓ Luckysheet format - {len(content)} sheet(s)")
            elif isinstance(content, dict) and 'data' in content:
                print(f"     ✓ Tabulator format - needs conversion")
            else:
                print(f"     ⚠️  Unknown format")
            
            # Check if content is serializable
            try:
                json_str = json.dumps(content)
                print(f"     ✓ JSON serializable ({len(json_str)} bytes)")
            except Exception as e:
                print(f"     ❌ JSON error: {e}")
        
        return True

def cleanup_test_tables():
    """Clean up test tables created during this test."""
    print("\n=== Cleanup ===")
    
    with app.app_context():
        test_titles = ['Test Luckysheet Table', 'Empty Table Test']
        deleted = 0
        
        for title in test_titles:
            table = File.query.filter_by(type='table', title=title).first()
            if table:
                db.session.delete(table)
                deleted += 1
        
        db.session.commit()
        print(f"Cleaned up {deleted} test table(s)")

if __name__ == '__main__':
    print("=" * 70)
    print("TABLE FILE VIEW/EDIT ROBUSTNESS TEST")
    print("=" * 70)
    
    try:
        # Run tests
        luckysheet_id = test_luckysheet_format()
        legacy_id = test_tabulator_legacy_format()
        empty_id = test_empty_table()
        routes_ok = test_view_edit_routes()
        
        # Summary
        print("\n" + "=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        
        if luckysheet_id:
            print(f"✅ Luckysheet format test PASSED (ID: {luckysheet_id})")
        else:
            print("❌ Luckysheet format test FAILED")
        
        if legacy_id:
            print(f"✅ Tabulator legacy format test PASSED (ID: {legacy_id})")
        else:
            print("⚠️  Tabulator legacy format test SKIPPED (no legacy data)")
        
        if empty_id:
            print(f"✅ Empty table test PASSED (ID: {empty_id})")
        else:
            print("❌ Empty table test FAILED")
        
        if routes_ok:
            print("✅ View/Edit routes test PASSED")
        else:
            print("❌ View/Edit routes test FAILED")
        
        # Instructions
        print("\n" + "=" * 70)
        print("NEXT STEPS")
        print("=" * 70)
        print("1. Start Flask server: python flask_app.py")
        print("2. Login as testuser")
        if luckysheet_id:
            print(f"3. View Luckysheet table: /p2/files/{luckysheet_id}/view")
            print(f"4. Edit Luckysheet table: /p2/files/{luckysheet_id}/edit")
        if legacy_id:
            print(f"5. View legacy table: /p2/files/{legacy_id}/view")
            print(f"6. Edit legacy table: /p2/files/{legacy_id}/edit")
        print("\n✓ Templates should auto-convert legacy format to Luckysheet")
        print("✓ Both view and edit modes should render without errors")
        print("✓ CSV export should work in both modes")
        
    finally:
        # Optional: comment out to keep test data
        # cleanup_test_tables()
        pass
    
    print("\n" + "=" * 70)
    print("TEST COMPLETE")
    print("=" * 70)
