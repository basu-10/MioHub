"""
Migration script to add summary tracking columns to chat_attachments.
Adds:
- original_content_hash (VARCHAR(64))
- summary_is_stale (BOOLEAN)
- word_count (INT)
- summary_word_count (INT)

This script is idempotent and will skip columns that already exist.
"""
import sys
from pathlib import Path

from flask import Flask
from sqlalchemy import text

# Ensure project root is on sys.path for module imports
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import config
from extensions import db


def main():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    db.init_app(app)

    with app.app_context():
        inspector = db.inspect(db.engine)
        existing_columns = {col['name'] for col in inspector.get_columns('chat_attachments')}

        missing_columns = []
        if 'original_content_hash' not in existing_columns:
            missing_columns.append('original_content_hash VARCHAR(64)')
        if 'summary_is_stale' not in existing_columns:
            missing_columns.append('summary_is_stale BOOLEAN DEFAULT FALSE')
        if 'word_count' not in existing_columns:
            missing_columns.append('word_count INT')
        if 'summary_word_count' not in existing_columns:
            missing_columns.append('summary_word_count INT')

        if not missing_columns:
            print("✓ Columns already exist — no changes applied")
            return

        alter_statement = "ALTER TABLE chat_attachments " + ", ".join(
            f"ADD COLUMN {col_def}" for col_def in missing_columns
        )

        db.session.execute(text(alter_statement))
        db.session.commit()
        print(f"✓ Added columns: {', '.join(missing_columns)}")


if __name__ == '__main__':
    main()
