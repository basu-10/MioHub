"""
Test script for infinite whiteboard layer functionality
Tests that the layers module is properly integrated and routes work correctly
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import User, File
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_layers_module_exists():
    """Test that the layers module file exists"""
    import os
    layers_path = os.path.join(
        os.path.dirname(__file__),
        'blueprints', 'p2', 'static', 'js', 'infinite_whiteboard',
        'infinite_whiteboard_layers.js'
    )
    assert os.path.exists(layers_path), f"Layers module not found at {layers_path}"
    print("✓ Layers module file exists")
    
    # Check module content
    with open(layers_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # Check for key functions
        assert 'IWB.bringToFront' in content, "Missing bringToFront function"
        assert 'IWB.sendToBack' in content, "Missing sendToBack function"
        assert 'IWB.moveUp' in content, "Missing moveUp function"
        assert 'IWB.moveDown' in content, "Missing moveDown function"
        assert 'IWB.drawLayerIndicator' in content, "Missing drawLayerIndicator function"
        assert 'IWB.drawLayerStack' in content, "Missing drawLayerStack function"
        assert 'IWB.initLayerShortcuts' in content, "Missing initLayerShortcuts function"
        assert 'IWB.createLayerUndoAction' in content, "Missing createLayerUndoAction function"
        assert 'IWB.applyLayerUndo' in content, "Missing applyLayerUndo function"
        assert 'IWB.applyLayerRedo' in content, "Missing applyLayerRedo function"
        
        print("✓ All layer functions present in module")

def test_template_integration():
    """Test that infinite_whiteboard.html loads the layers module"""
    import os
    template_path = os.path.join(
        os.path.dirname(__file__),
        'blueprints', 'p2', 'templates', 'p2',
        'infinite_whiteboard.html'
    )
    assert os.path.exists(template_path), f"Template not found at {template_path}"
    print("✓ Template file exists")
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # Check module is loaded
        assert 'infinite_whiteboard_layers.js' in content, "Layers module not loaded in template"
        print("✓ Layers module loaded in template")
        
        # Check toolbar buttons exist
        assert 'bringToFrontHandler' in content, "Missing bring to front button"
        assert 'sendToBackHandler' in content, "Missing send to back button"
        assert 'moveUpHandler' in content, "Missing move up button"
        assert 'moveDownHandler' in content, "Missing move down button"
        print("✓ Layer control buttons present")
        
        # Check handler functions exist
        assert 'function bringToFrontHandler()' in content, "Missing bringToFrontHandler function"
        assert 'function sendToBackHandler()' in content, "Missing sendToBackHandler function"
        assert 'function moveUpHandler()' in content, "Missing moveUpHandler function"
        assert 'function moveDownHandler()' in content, "Missing moveDownHandler function"
        print("✓ Layer handler functions implemented")
        
        # Check keyboard shortcuts initialized
        assert 'IWB.initLayerShortcuts' in content, "Layer shortcuts not initialized"
        print("✓ Layer keyboard shortcuts initialized")
        
        # Check visualization in render function
        assert 'IWB.drawLayerIndicator' in content, "Layer indicator not drawn"
        assert 'IWB.drawLayerStack' in content, "Layer stack not drawn"
        print("✓ Layer visualization integrated")

def test_undo_redo_integration():
    """Test that undo/redo module handles layer operations"""
    import os
    undo_path = os.path.join(
        os.path.dirname(__file__),
        'blueprints', 'p2', 'static', 'js', 'infinite_whiteboard',
        'infinite_whiteboard_undo.js'
    )
    assert os.path.exists(undo_path), f"Undo module not found at {undo_path}"
    print("✓ Undo module file exists")
    
    with open(undo_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # Check layer undo/redo handling
        assert "action.type === 'layer'" in content, "Layer action type not handled in undo"
        assert 'IWB.applyLayerUndo' in content, "applyLayerUndo not called in undo"
        assert 'IWB.applyLayerRedo' in content, "applyLayerRedo not called in redo"
        
        print("✓ Undo/redo module handles layer operations")

def test_module_documentation():
    """Test that module has proper documentation"""
    import os
    layers_path = os.path.join(
        os.path.dirname(__file__),
        'blueprints', 'p2', 'static', 'js', 'infinite_whiteboard',
        'infinite_whiteboard_layers.js'
    )
    
    with open(layers_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # Check for JSDoc comments
        assert '/**' in content, "Missing JSDoc comments"
        assert '@param' in content, "Missing parameter documentation"
        assert '@returns' in content, "Missing return documentation"
        
        print("✓ Module has proper JSDoc documentation")

def main():
    print("Testing Infinite Whiteboard Layer Implementation")
    print("=" * 60)
    
    try:
        test_layers_module_exists()
        print()
        
        test_template_integration()
        print()
        
        test_undo_redo_integration()
        print()
        
        test_module_documentation()
        print()
        
        print("=" * 60)
        print("✓ ALL TESTS PASSED")
        print()
        print("Layer Features Implemented:")
        print("  • Bring to Front (Ctrl+])")
        print("  • Send to Back (Ctrl+[)")
        print("  • Move Up One Layer (])")
        print("  • Move Down One Layer ([)")
        print("  • Layer Position Indicator (top-right corner)")
        print("  • Layer Stack Panel (bottom-left corner)")
        print("  • Full Undo/Redo Support")
        print("  • Visual Layer Feedback")
        print()
        
    except AssertionError as e:
        print(f"\n✗ TEST FAILED: {e}")
        return False
    
    return True

if __name__ == '__main__':
    success = main()
    exit(0 if success else 1)
