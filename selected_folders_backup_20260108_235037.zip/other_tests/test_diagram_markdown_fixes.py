"""
Test script to verify markdown Ctrl+S fix and diagram save/load fix.
Run this after starting the Flask app to manually test the fixes.
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, Folder, User
from datetime import datetime
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/app_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    # Find test user
    user = User.query.filter_by(username='testuser').first()
    if not user:
        print("Error: testuser not found. Run init_db.py first.")
        exit(1)
    
    # Find user's root folder
    root_folder = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
    if not root_folder:
        print("Error: Root folder not found for testuser")
        exit(1)
    
    print(f"Testing with user: {user.username} (ID: {user.id})")
    print(f"Root folder ID: {root_folder.id}")
    
    # Test 1: Create a diagram file with JSON content
    print("\n=== Test 1: Creating diagram with JSON content ===")
    diagram_data = {
        "nodes": [
            {"id": "test1", "label": "Test Node 1", "x": 100, "y": 100, "color": "#14b8a6"},
            {"id": "test2", "label": "Test Node 2", "x": 300, "y": 100, "color": "#3b82f6"}
        ],
        "edges": [
            {"from": "test1", "to": "test2", "label": "Test Edge"}
        ]
    }
    
    diagram_file = File(
        owner_id=user.id,
        folder_id=root_folder.id,
        type='diagram',
        title='Test Diagram Save/Load',
        content_json=diagram_data,
        is_public=False,
        metadata_json={"description": "Testing diagram save/load fix"}
    )
    
    db.session.add(diagram_file)
    db.session.commit()
    print(f"✓ Created diagram file ID: {diagram_file.id}")
    
    # Verify it was saved correctly
    loaded_diagram = File.query.get(diagram_file.id)
    if loaded_diagram.content_json == diagram_data:
        print("✓ Diagram content_json matches saved data")
    else:
        print("✗ ERROR: Diagram content_json does NOT match!")
        print(f"  Expected: {diagram_data}")
        print(f"  Got: {loaded_diagram.content_json}")
    
    # Test 2: Create a markdown file
    print("\n=== Test 2: Creating markdown file ===")
    markdown_content = "# Test Markdown\n\nThis is a test to verify Ctrl+S works correctly."
    
    markdown_file = File(
        owner_id=user.id,
        folder_id=root_folder.id,
        type='markdown',
        title='Test Markdown Ctrl+S',
        content_text=markdown_content,
        is_public=False,
        metadata_json={"description": "Testing markdown Ctrl+S fix"}
    )
    
    db.session.add(markdown_file)
    db.session.commit()
    print(f"✓ Created markdown file ID: {markdown_file.id}")
    
    # Verify it was saved correctly
    loaded_markdown = File.query.get(markdown_file.id)
    if loaded_markdown.content_text == markdown_content:
        print("✓ Markdown content_text matches saved data")
    else:
        print("✗ ERROR: Markdown content_text does NOT match!")
        print(f"  Expected: {markdown_content}")
        print(f"  Got: {loaded_markdown.content_text}")
    
    # Test 3: Verify diagram view will render correctly
    print("\n=== Test 3: Checking diagram content for view rendering ===")
    if loaded_diagram.content_json and 'nodes' in loaded_diagram.content_json:
        print(f"✓ Diagram has nodes: {len(loaded_diagram.content_json['nodes'])} nodes")
        print(f"✓ Diagram has edges: {len(loaded_diagram.content_json.get('edges', []))} edges")
    else:
        print("✗ ERROR: Diagram content_json is missing or invalid!")
    
    print("\n=== Manual Testing Instructions ===")
    print(f"1. Start Flask app: python flask_app.py")
    print(f"2. Login as 'testuser' / 'password123'")
    print(f"3. Test Markdown Ctrl+S:")
    print(f"   - Edit file ID {markdown_file.id}: /p2/files/{markdown_file.id}/edit")
    print(f"   - Change content and press Ctrl+S")
    print(f"   - Verify content is saved (reload page)")
    print(f"4. Test Diagram save/load:")
    print(f"   - Edit file ID {diagram_file.id}: /p2/files/{diagram_file.id}/edit")
    print(f"   - Verify existing diagram data loads in Monaco editor")
    print(f"   - Change diagram (add node, change color, etc.)")
    print(f"   - Click Save button")
    print(f"   - View file: /p2/files/{diagram_file.id}/view")
    print(f"   - Verify diagram renders correctly on canvas")
    print(f"   - Go back to edit mode - verify changes persisted")
    
    print(f"\n=== Cleanup ===")
    print(f"To delete test files:")
    print(f"DELETE FROM files WHERE id IN ({diagram_file.id}, {markdown_file.id});")
