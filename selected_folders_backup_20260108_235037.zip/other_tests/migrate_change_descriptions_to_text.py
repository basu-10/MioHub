"""
Migration script: change description columns to TEXT

This script will:
 - connect to the MySQL database using values in config.py
 - check the DATA_TYPE of the target columns
 - ALTER TABLE ... MODIFY COLUMN ... TEXT NULL when needed

Run with the project's venv python:
& "D:/dev_work/web_dev/personal site/from pythonanywhere/myproject_backup.v2.16/.venv/Scripts/python.exe" "D:/dev_work/web_dev/personal site/from pythonanywhere/myproject_backup.v2.16/migrate_change_descriptions_to_text.py"
"""

import mysql.connector
import sys
import config


def ensure_text(cursor, db_name, table, column):
    cursor.execute(
        "SELECT DATA_TYPE, COLUMN_TYPE, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS "
        "WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s AND COLUMN_NAME=%s",
        (db_name, table, column),
    )
    row = cursor.fetchone()
    if not row:
        print(f"- {table}.{column}: column not found, skipping")
        return
    data_type, column_type, is_nullable = row
    data_type = data_type.lower() if data_type else ''
    print(f"- {table}.{column}: current type={data_type}, column_type={column_type}, is_nullable={is_nullable}")
    if data_type == 'text':
        print(f"  -> already TEXT, skipping")
        return
    # Perform alter; preserve NULL/NOT NULL if desired, here we allow NULL
    alter_sql = f"ALTER TABLE `{table}` MODIFY COLUMN `{column}` TEXT"
    if is_nullable == 'NO':
        alter_sql += " NOT NULL"
    else:
        alter_sql += " NULL"
    print(f"  -> executing: {alter_sql}")
    cursor.execute(alter_sql)
    print(f"  -> {table}.{column} altered to TEXT")


def main():
    try:
        cnx = mysql.connector.connect(
            host=config.DB_HOST,
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            port=int(config.DB_PORT),
            database=config.DB_NAME,
            autocommit=False,
        )
    except Exception as e:
        print(f"Failed to connect to database: {e}")
        sys.exit(1)

    cursor = cnx.cursor()
    try:
        targets = [
            ("folder", "description"),
            ("note", "description"),
            ("boards", "description"),
        ]
        for table, column in targets:
            ensure_text(cursor, config.DB_NAME, table, column)
        cnx.commit()
        print("Migration completed and committed.")
    except Exception as e:
        print(f"Error during migration: {e}")
        print("Rolling back...")
        cnx.rollback()
        raise
    finally:
        cursor.close()
        cnx.close()


if __name__ == '__main__':
    main()
