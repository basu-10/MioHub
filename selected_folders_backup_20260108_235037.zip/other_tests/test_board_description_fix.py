"""
Test script to verify MioDraw (whiteboard) description display fix.

This test verifies:
1. Board descriptions are saved correctly to metadata_json
2. The description property correctly reads from metadata_json
3. Board descriptions display in the folder view
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, Folder, User
from sqlalchemy.orm.attributes import flag_modified
from datetime import datetime
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_board_description_property():
    """Test that the description property correctly reads from metadata_json."""
    with app.app_context():
        # Test 1: Board with description in metadata_json
        board1 = File(
            type='whiteboard',
            title='Test Board 1',
            metadata_json={'description': 'This is a test description'}
        )
        assert board1.description == 'This is a test description', f"Expected 'This is a test description', got '{board1.description}'"
        print("✓ Test 1 passed: Description property reads from metadata_json")
        
        # Test 2: Board with empty metadata_json
        board2 = File(
            type='whiteboard',
            title='Test Board 2',
            metadata_json={}
        )
        assert board2.description == '', f"Expected empty string, got '{board2.description}'"
        print("✓ Test 2 passed: Empty metadata_json returns empty string")
        
        # Test 3: Board with None metadata_json
        board3 = File(
            type='whiteboard',
            title='Test Board 3',
            metadata_json=None
        )
        assert board3.description == '', f"Expected empty string, got '{board3.description}'"
        print("✓ Test 3 passed: None metadata_json returns empty string")
        
        # Test 4: Board with metadata_json but no description key
        board4 = File(
            type='whiteboard',
            title='Test Board 4',
            metadata_json={'other_field': 'value'}
        )
        assert board4.description == '', f"Expected empty string, got '{board4.description}'"
        print("✓ Test 4 passed: metadata_json without description returns empty string")

def test_board_description_persistence():
    """Test that board descriptions persist correctly to database."""
    with app.app_context():
        # Find test user
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            print("⚠ Test user 'testuser' not found. Skipping persistence test.")
            return
        
        # Find or create test folder
        test_folder = Folder.query.filter_by(user_id=test_user.id, name='Test Folder').first()
        if not test_folder:
            test_folder = Folder(
                user_id=test_user.id,
                name='Test Folder',
                parent_id=None
            )
            db.session.add(test_folder)
            db.session.commit()
        
        # Create a test board with description
        test_board = File(
            owner_id=test_user.id,
            folder_id=test_folder.id,
            type='whiteboard',
            title=f'Test Board {datetime.now().strftime("%H:%M:%S")}',
            content_json={'version': 3, 'pages': []},
            metadata_json={'description': 'Sample whiteboard description'}
        )
        
        db.session.add(test_board)
        db.session.commit()
        board_id = test_board.id
        print(f"✓ Test board created with ID: {board_id}")
        
        # Retrieve the board and verify description
        retrieved_board = File.query.get(board_id)
        assert retrieved_board is not None, "Board not found after commit"
        assert retrieved_board.description == 'Sample whiteboard description', \
            f"Expected 'Sample whiteboard description', got '{retrieved_board.description}'"
        print("✓ Board description persisted correctly to database")
        
        # Update description and verify
        retrieved_board.metadata_json['description'] = 'Updated description'
        flag_modified(retrieved_board, 'metadata_json')
        db.session.commit()
        
        # Re-query to verify update
        updated_board = File.query.get(board_id)
        assert updated_board.description == 'Updated description', \
            f"Expected 'Updated description', got '{updated_board.description}'"
        print("✓ Board description updated correctly")
        
        # Clean up
        db.session.delete(test_board)
        db.session.commit()
        print("✓ Test board cleaned up")

if __name__ == '__main__':
    print("Testing MioDraw description display fix...")
    print("=" * 60)
    
    test_board_description_property()
    print()
    test_board_description_persistence()
    
    print("=" * 60)
    print("All tests passed! ✓")
