"""
Test script to verify todo preview functionality in folder view.
Checks that todo items show preview when:
- Content preview toggle is ON
- Card size is normal or large
- File type is 'todo'
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, User, Folder
from datetime import datetime
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/myproject'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_todo_preview():
    """Test creating a todo file with items and verify structure."""
    with app.app_context():
        # Get test user
        user = User.query.filter_by(username='testuser').first()
        if not user:
            print("Error: testuser not found. Run init_db.py first.")
            return
        
        # Get root folder
        root_folder = Folder.query.filter_by(owner_id=user.id, parent_id=None).first()
        if not root_folder:
            print("Error: Root folder not found for testuser.")
            return
        
        # Create a test todo file with sample items
        todo_items = [
            {"id": 1, "text": "Complete project documentation", "completed": True},
            {"id": 2, "text": "Review pull requests", "completed": False},
            {"id": 3, "text": "Update dependencies", "completed": True},
            {"id": 4, "text": "Write unit tests for new features", "completed": False},
            {"id": 5, "text": "Deploy to production", "completed": False},
            {"id": 6, "text": "Monitor application metrics", "completed": False},
        ]
        
        # Check if test todo already exists
        test_todo = File.query.filter_by(
            owner_id=user.id,
            folder_id=root_folder.id,
            title='Test Todo Preview'
        ).first()
        
        if test_todo:
            print(f"Test todo file already exists (ID: {test_todo.id})")
            print(f"Updating with {len(todo_items)} items...")
            test_todo.content_json = {"items": todo_items}
            test_todo.metadata_json = {"description": "Sample todo list for testing preview"}
        else:
            print("Creating new test todo file...")
            test_todo = File(
                owner_id=user.id,
                folder_id=root_folder.id,
                type='todo',
                title='Test Todo Preview',
                content_json={"items": todo_items},
                metadata_json={"description": "Sample todo list for testing preview"},
                created_at=datetime.utcnow(),
                last_modified=datetime.utcnow()
            )
            db.session.add(test_todo)
        
        db.session.commit()
        
        print(f"\n✓ Test todo file created/updated successfully!")
        print(f"  File ID: {test_todo.id}")
        print(f"  Title: {test_todo.title}")
        print(f"  Total items: {len(todo_items)}")
        print(f"  Completed: {sum(1 for item in todo_items if item['completed'])}")
        print(f"  Pending: {sum(1 for item in todo_items if not item['completed'])}")
        print(f"\nPreview should show:")
        print(f"  - Progress bar: {sum(1 for item in todo_items if item['completed'])}/{len(todo_items)} done")
        print(f"  - First 5 items with checkmarks")
        print(f"  - '+ 1 more...' indicator")
        print(f"\nView the folder at: http://localhost:5555/p2/folders/{root_folder.id}")
        print(f"Make sure to:")
        print(f"  1. Toggle 'Content Previews' ON in View dropdown")
        print(f"  2. Set Card Size to 'Normal' or 'Large'")

if __name__ == '__main__':
    test_todo_preview()
