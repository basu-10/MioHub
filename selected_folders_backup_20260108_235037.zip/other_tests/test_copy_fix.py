"""
Test copy operation with the fixed clone_folder function
"""
from flask import Flask
from flask_login import login_user
from extensions import db, login_manager
from blueprints.p2.models import User
from blueprints.p2.folder_ops import copy_folder_recursive
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SECRET_KEY'] = config.SECRET_KEY
db.init_app(app)
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def test_copy_folder():
    """Test copying folder 1028"""
    with app.app_context():
        # Get test user
        user = User.query.filter_by(username='testuser').first()
        if not user:
            print("❌ Test user not found")
            return
        
        # Simulate login
        with app.test_request_context():
            login_user(user)
            
            from flask_login import current_user
            print(f"Logged in as: {current_user.username}")
            print()
            
            # Try copying folder 1028 to root folder (id=1)
            print("Testing copy_folder_recursive(1028, 1)...")
            try:
                result = copy_folder_recursive(1028, 1)
                if result:
                    print(f"✅ Copy successful!")
                    print(f"   New folder ID: {result.id}")
                    print(f"   New folder name: '{result.name}'")
                else:
                    print("❌ Copy returned None")
            except RecursionError as e:
                print(f"❌ RecursionError: {e}")
            except Exception as e:
                print(f"❌ Error: {type(e).__name__}: {e}")
                import traceback
                traceback.print_exc()

if __name__ == '__main__':
    test_copy_folder()
