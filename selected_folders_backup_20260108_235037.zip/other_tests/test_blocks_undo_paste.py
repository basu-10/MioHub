"""
Test script to verify Blocks editor undo/redo and paste functionality fixes.

This test verifies:
1. Undo plugin (editorjs-undo) is loaded correctly
2. Quote block configuration includes paste handler
3. Warning block configuration includes paste handler
4. Editor initialization includes onReady callback for undo setup

Run this test after starting the Flask app to ensure the Blocks editor works properly.
"""

import re

def test_blocks_editor_fixes():
    """Test that the Blocks editor template has all required fixes."""
    
    template_path = "blueprints/p2/templates/p2/file_edit_blocks.html"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Test 1: Check for undo plugin script
    print("Test 1: Checking for editorjs-undo plugin...")
    assert 'editorjs-undo' in content, "❌ Undo plugin script not found"
    print("✅ Undo plugin script is included")
    
    # Test 2: Check for onReady callback with Undo initialization
    print("\nTest 2: Checking for Undo initialization in onReady...")
    assert 'onReady: () => {' in content, "❌ onReady callback not found"
    assert 'new Undo({ editor })' in content, "❌ Undo initialization not found"
    print("✅ Undo is properly initialized in onReady callback")
    
    # Test 3: Check Quote block has pasteHandler
    print("\nTest 3: Checking Quote block pasteHandler...")
    quote_config_pattern = r'quote:\s*\{[^}]*config:\s*\{[^}]*pasteHandler'
    assert re.search(quote_config_pattern, content, re.DOTALL), "❌ Quote pasteHandler not found"
    assert "tags: ['BLOCKQUOTE', 'P']" in content, "❌ Quote pasteHandler tags not configured"
    print("✅ Quote block has pasteHandler configured")
    
    # Test 4: Check Warning block has pasteHandler
    print("\nTest 4: Checking Warning block pasteHandler...")
    warning_config_pattern = r'warning:\s*\{[^}]*config:\s*\{[^}]*pasteHandler'
    assert re.search(warning_config_pattern, content, re.DOTALL), "❌ Warning pasteHandler not found"
    assert "tags: ['DIV', 'P']" in content, "❌ Warning pasteHandler tags not configured"
    print("✅ Warning block has pasteHandler configured")
    
    # Test 5: Check shortcuts are defined
    print("\nTest 5: Checking keyboard shortcuts...")
    assert 'CMD+SHIFT+Q' in content, "❌ Quote shortcut not found"
    assert 'CMD+SHIFT+W' in content, "❌ Warning shortcut not found"
    print("✅ Keyboard shortcuts configured (Quote: Cmd+Shift+Q, Warning: Cmd+Shift+W)")
    
    print("\n" + "="*60)
    print("✅ All tests passed! Blocks editor should now support:")
    print("   - Ctrl+Z / Cmd+Z for undo")
    print("   - Ctrl+Shift+Z / Cmd+Shift+Z for redo")
    print("   - Pasting text into Quote blocks")
    print("   - Pasting text into Warning blocks")
    print("="*60)

if __name__ == "__main__":
    try:
        test_blocks_editor_fixes()
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        exit(1)
    except FileNotFoundError:
        print("❌ Template file not found. Make sure you're running from project root.")
        exit(1)
