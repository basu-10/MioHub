"""
Test script to verify MioBook migration to Files table.

This script tests:
1. Creating new MioBook documents
2. Querying MioBooks from the Files table
3. Updating MioBook content
4. Verifying content_json storage
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, Folder, User
from sqlalchemy.orm.attributes import flag_modified
import config
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_miobook_operations():
    """Test MioBook creation, update, and query operations."""
    with app.app_context():
        print("=" * 80)
        print("Testing MioBook Operations with Files Table")
        print("=" * 80)
        print()
        
        # 1. Get test user
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            print("❌ Test user not found. Run init_db.py first.")
            return
        
        print(f"✅ Test user found: {test_user.username} (ID: {test_user.id})")
        
        # 2. Get or create test folder
        test_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
        if not test_folder:
            print("❌ No root folder found for test user")
            return
        
        print(f"✅ Test folder found: {test_folder.name} (ID: {test_folder.id})")
        print()
        
        # 3. Create a new MioBook
        print("Creating new MioBook...")
        test_blocks = [
            {'type': 'note', 'note_id': 1, 'title': 'Test Note Block'},
            {'type': 'board', 'board_id': 2, 'title': 'Test Board Block'}
        ]
        
        new_book = File(
            owner_id=test_user.id,
            folder_id=test_folder.id,
            type='book',
            title='Test MioBook',
            content_json=test_blocks,
            metadata_json={'description': 'Test MioBook document', 'test': True}
        )
        
        db.session.add(new_book)
        db.session.commit()
        
        print(f"✅ Created MioBook ID: {new_book.id}")
        print(f"   Title: {new_book.title}")
        print(f"   Blocks: {len(new_book.content_json)}")
        print(f"   Size: {new_book.get_content_size()} bytes")
        print()
        
        # 4. Query MioBooks
        print("Querying MioBooks from Files table...")
        all_books = File.query.filter_by(type='book', owner_id=test_user.id).all()
        print(f"✅ Found {len(all_books)} MioBook(s)")
        for book in all_books[:5]:  # Show first 5
            print(f"   - ID {book.id}: '{book.title}' ({len(book.content_json or [])} blocks)")
        if len(all_books) > 5:
            print(f"   ... and {len(all_books) - 5} more")
        print()
        
        # 5. Update MioBook content
        print(f"Updating MioBook ID {new_book.id}...")
        old_size = new_book.get_content_size()
        
        updated_blocks = test_blocks + [
            {'type': 'note', 'note_id': 3, 'title': 'Another Note Block'}
        ]
        new_book.content_json = updated_blocks
        flag_modified(new_book, 'content_json')  # Required for JSON columns
        db.session.commit()
        
        new_size = new_book.get_content_size()
        print(f"✅ Updated MioBook")
        print(f"   Old size: {old_size} bytes")
        print(f"   New size: {new_size} bytes")
        print(f"   Delta: {new_size - old_size} bytes")
        print(f"   Blocks: {len(new_book.content_json)}")
        print()
        
        # 6. Verify content_json structure
        print("Verifying content_json structure...")
        book = File.query.get(new_book.id)
        content = book.content_json
        
        if isinstance(content, list):
            print("✅ content_json is a list (correct)")
            print(f"   Blocks: {len(content)}")
            for i, block in enumerate(content, 1):
                if isinstance(block, dict):
                    block_type = block.get('type', 'unknown')
                    block_title = block.get('title', 'untitled')
                    print(f"   Block {i}: type={block_type}, title='{block_title}'")
                else:
                    print(f"   Block {i}: Invalid structure (not a dict)")
        else:
            print(f"❌ content_json is not a list: {type(content)}")
        print()
        
        # 7. Test get_content() method
        print("Testing get_content() method...")
        content = book.get_content()
        if content is not None:
            print(f"✅ get_content() returned: {type(content)}")
            if isinstance(content, list):
                print(f"   Length: {len(content)} blocks")
        else:
            print("❌ get_content() returned None")
        print()
        
        # 8. Cleanup test book
        print(f"Cleaning up test MioBook ID {new_book.id}...")
        db.session.delete(new_book)
        db.session.commit()
        print("✅ Test MioBook deleted")
        print()
        
        print("=" * 80)
        print("All tests passed! ✅")
        print("=" * 80)

if __name__ == '__main__':
    test_miobook_operations()
