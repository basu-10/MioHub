"""
Migration: Add notifications table for telemetry system

Creates the notifications table to store user activity notifications
with automatic cleanup to maintain only the last 50 per user.
"""

from flask import Flask
from extensions import db
from sqlalchemy import text, inspect
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def migrate():
    """Add notifications table if it doesn't exist."""
    with app.app_context():
        inspector = inspect(db.engine)
        
        # Check if notifications table already exists
        if 'notifications' in inspector.get_table_names():
            print("✓ Table 'notifications' already exists. Skipping migration.")
            return
        
        print("Creating 'notifications' table...")
        
        # Create notifications table
        create_table_sql = """
        CREATE TABLE notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            message VARCHAR(500) NOT NULL,
            timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            type VARCHAR(20) NOT NULL DEFAULT 'info',
            INDEX idx_user_id (user_id),
            INDEX idx_timestamp (timestamp),
            FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        """
        
        try:
            db.session.execute(text(create_table_sql))
            db.session.commit()
            print("✓ Successfully created 'notifications' table")
            print("  - Columns: id, user_id, message, timestamp, type")
            print("  - Indexes: user_id, timestamp")
            print("  - Foreign key constraint on user_id")
        except Exception as e:
            db.session.rollback()
            print(f"✗ Error creating table: {e}")
            raise

if __name__ == '__main__':
    print("=" * 60)
    print("Migration: Add notifications table")
    print("=" * 60)
    migrate()
    print("=" * 60)
    print("Migration complete!")
