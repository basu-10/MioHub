"""
Migration script to add description columns to note and board tables
Run this script to add the description fields to existing notes and boards
"""

import config
from extensions import db
from flask import Flask
from sqlalchemy import text

def migrate_add_descriptions():
    """Add description columns to note and board tables"""
    app = Flask(__name__)
    
    # Configure database
    db_uri = config.get_database_uri()
    app.config['SQLALCHEMY_DATABASE_URI'] = db_uri
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        inspector = db.inspect(db.engine)
        
        # Check and add description to note table
        note_columns = [col['name'] for col in inspector.get_columns('note')]
        if 'description' not in note_columns:
            try:
                with db.engine.connect() as conn:
                    conn.execute(text(
                        "ALTER TABLE note ADD COLUMN description VARCHAR(500) NULL"
                    ))
                    conn.commit()
                print("✓ Successfully added description column to note table")
            except Exception as e:
                print(f"✗ Error adding description to note table: {e}")
        else:
            print("✓ Description column already exists in note table")
        
        # Check and add description to boards table
        board_columns = [col['name'] for col in inspector.get_columns('boards')]
        if 'description' not in board_columns:
            try:
                with db.engine.connect() as conn:
                    conn.execute(text(
                        "ALTER TABLE boards ADD COLUMN description VARCHAR(500) NULL"
                    ))
                    conn.commit()
                print("✓ Successfully added description column to boards table")
            except Exception as e:
                print(f"✗ Error adding description to boards table: {e}")
        else:
            print("✓ Description column already exists in boards table")

if __name__ == "__main__":
    print("Starting migration: Add description columns to note and board tables")
    migrate_add_descriptions()
    print("Migration completed!")
