"""
Migration script to convert all Note and Board records to File table.

This script:
1. Copies all Note records to File table with type='note'
2. Copies all Board records to File table with type='whiteboard'
3. Preserves all metadata (title, content, description, timestamps, public flags)
4. Creates a backup mapping file for rollback if needed
5. Does NOT delete original Note/Board records (manual cleanup after verification)

Run this script BEFORE deploying code changes that deprecate Note/Board models.
"""

import json
from datetime import datetime
from flask import Flask
from extensions import db
from blueprints.p2.models import Note, Board, File, User, Folder
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def migrate_notes_to_files():
    """Migrate all Note records to File table with type='note'"""
    with app.app_context():
        notes = Note.query.all()
        migrated = 0
        skipped = 0
        errors = []
        mapping = {}  # For backup/rollback: {note_id: file_id}
        
        print(f"\n{'='*80}")
        print(f"Starting Note -> File migration")
        print(f"Total notes to migrate: {len(notes)}")
        print(f"{'='*80}\n")
        
        for note in notes:
            try:
                # Check if already migrated (avoid duplicates)
                existing = File.query.filter_by(
                    owner_id=note.user_id,
                    folder_id=note.folder_id,
                    type='note',
                    title=note.title
                ).first()
                
                if existing and existing.content_html == note.content:
                    print(f"  SKIP: Note {note.id} '{note.title}' already migrated as File {existing.id}")
                    skipped += 1
                    mapping[note.id] = existing.id
                    continue
                
                # Create File record
                file_obj = File(
                    owner_id=note.user_id,
                    folder_id=note.folder_id,
                    type='note',
                    title=note.title or 'Untitled',
                    content_html=note.content,  # Legacy notes use HTML content
                    created_at=note.created_at,
                    last_modified=note.last_modified,
                    is_public=getattr(note, 'is_public', False)
                )
                
                # Store description and is_pinned in metadata
                metadata = {}
                if hasattr(note, 'description') and note.description:
                    metadata['description'] = note.description
                if hasattr(note, 'is_pinned') and note.is_pinned:
                    metadata['is_pinned'] = note.is_pinned
                metadata['migrated_from_note_id'] = note.id
                metadata['migration_date'] = datetime.utcnow().isoformat()
                
                if metadata:
                    file_obj.metadata_json = metadata
                
                db.session.add(file_obj)
                db.session.flush()  # Get the file_obj.id
                
                mapping[note.id] = file_obj.id
                migrated += 1
                
                if migrated % 100 == 0:
                    print(f"  Progress: {migrated} notes migrated...")
                
            except Exception as e:
                error_msg = f"Error migrating note {note.id} '{note.title}': {str(e)}"
                print(f"  ERROR: {error_msg}")
                errors.append(error_msg)
                db.session.rollback()
        
        # Commit all changes
        try:
            db.session.commit()
            print(f"\n{'='*80}")
            print(f"Note migration complete!")
            print(f"  Migrated: {migrated}")
            print(f"  Skipped (already migrated): {skipped}")
            print(f"  Errors: {len(errors)}")
            print(f"{'='*80}\n")
            
            # Save mapping for rollback
            with open('migration_notes_mapping.json', 'w') as f:
                json.dump(mapping, f, indent=2)
            print(f"Mapping saved to: migration_notes_mapping.json")
            
            if errors:
                print("\nErrors encountered:")
                for err in errors:
                    print(f"  - {err}")
            
            return migrated, skipped, errors
            
        except Exception as e:
            db.session.rollback()
            print(f"\n{'='*80}")
            print(f"FATAL ERROR during commit: {str(e)}")
            print(f"{'='*80}\n")
            return 0, 0, [str(e)]


def migrate_boards_to_files():
    """Migrate all Board records to File table with type='whiteboard'"""
    with app.app_context():
        boards = Board.query.all()
        migrated = 0
        skipped = 0
        errors = []
        mapping = {}  # For backup/rollback: {board_id: file_id}
        
        print(f"\n{'='*80}")
        print(f"Starting Board -> File migration")
        print(f"Total boards to migrate: {len(boards)}")
        print(f"{'='*80}\n")
        
        for board in boards:
            try:
                # Check if already migrated (avoid duplicates)
                existing = File.query.filter_by(
                    owner_id=board.user_id,
                    folder_id=board.folder_id,
                    type='whiteboard',
                    title=board.title
                ).first()
                
                if existing:
                    # Compare content to ensure it's the same board
                    existing_content = existing.content_json if existing.content_json else None
                    board_content = None
                    if board.content:
                        try:
                            board_content = json.loads(board.content)
                        except:
                            board_content = board.content
                    
                    if existing_content == board_content:
                        print(f"  SKIP: Board {board.id} '{board.title}' already migrated as File {existing.id}")
                        skipped += 1
                        mapping[board.id] = existing.id
                        continue
                
                # Parse board content (usually JSON)
                content_json = None
                if board.content:
                    try:
                        content_json = json.loads(board.content)
                    except json.JSONDecodeError:
                        # If not valid JSON, store as-is in content_text
                        print(f"  WARN: Board {board.id} content is not valid JSON, storing as text")
                        content_json = None
                
                # Create File record
                file_obj = File(
                    owner_id=board.user_id,
                    folder_id=board.folder_id,
                    type='whiteboard',
                    title=board.title or 'Untitled Whiteboard',
                    content_json=content_json,
                    created_at=board.created_at,
                    last_modified=board.last_modified,
                    is_public=getattr(board, 'is_public', False)
                )
                
                # If content wasn't JSON, store as text
                if content_json is None and board.content:
                    file_obj.content_text = board.content
                
                # Store description in metadata
                metadata = {}
                if hasattr(board, 'description') and board.description:
                    metadata['description'] = board.description
                metadata['migrated_from_board_id'] = board.id
                metadata['migration_date'] = datetime.utcnow().isoformat()
                
                if metadata:
                    file_obj.metadata_json = metadata
                
                db.session.add(file_obj)
                db.session.flush()  # Get the file_obj.id
                
                mapping[board.id] = file_obj.id
                migrated += 1
                
                if migrated % 100 == 0:
                    print(f"  Progress: {migrated} boards migrated...")
                
            except Exception as e:
                error_msg = f"Error migrating board {board.id} '{board.title}': {str(e)}"
                print(f"  ERROR: {error_msg}")
                errors.append(error_msg)
                db.session.rollback()
        
        # Commit all changes
        try:
            db.session.commit()
            print(f"\n{'='*80}")
            print(f"Board migration complete!")
            print(f"  Migrated: {migrated}")
            print(f"  Skipped (already migrated): {skipped}")
            print(f"  Errors: {len(errors)}")
            print(f"{'='*80}\n")
            
            # Save mapping for rollback
            with open('migration_boards_mapping.json', 'w') as f:
                json.dump(mapping, f, indent=2)
            print(f"Mapping saved to: migration_boards_mapping.json")
            
            if errors:
                print("\nErrors encountered:")
                for err in errors:
                    print(f"  - {err}")
            
            return migrated, skipped, errors
            
        except Exception as e:
            db.session.rollback()
            print(f"\n{'='*80}")
            print(f"FATAL ERROR during commit: {str(e)}")
            print(f"{'='*80}\n")
            return 0, 0, [str(e)]


def verify_migration():
    """Verify that all notes and boards have been migrated"""
    with app.app_context():
        print(f"\n{'='*80}")
        print(f"Verifying migration...")
        print(f"{'='*80}\n")
        
        note_count = Note.query.count()
        board_count = Board.query.count()
        file_note_count = File.query.filter_by(type='note').count()
        file_whiteboard_count = File.query.filter_by(type='whiteboard').count()
        
        print(f"Original counts:")
        print(f"  Notes: {note_count}")
        print(f"  Boards: {board_count}")
        print(f"\nMigrated counts:")
        print(f"  Files (type='note'): {file_note_count}")
        print(f"  Files (type='whiteboard'): {file_whiteboard_count}")
        
        if file_note_count >= note_count and file_whiteboard_count >= board_count:
            print(f"\n✅ Migration verification PASSED")
            print(f"   All notes and boards have been migrated to File table.")
        else:
            print(f"\n⚠️  Migration verification WARNING")
            print(f"   Some records may not have been migrated.")
            if file_note_count < note_count:
                print(f"   Missing {note_count - file_note_count} notes")
            if file_whiteboard_count < board_count:
                print(f"   Missing {board_count - file_whiteboard_count} boards")
        
        print(f"{'='*80}\n")


if __name__ == '__main__':
    print("\n" + "="*80)
    print("NOTE AND BOARD TO FILE MIGRATION SCRIPT")
    print("="*80)
    print("\nThis script will migrate all Note and Board records to the File table.")
    print("Original Note and Board records will be preserved (not deleted).")
    print("\nMapping files will be created for rollback:")
    print("  - migration_notes_mapping.json")
    print("  - migration_boards_mapping.json")
    print("\n" + "="*80)
    
    response = input("\nProceed with migration? (yes/no): ").strip().lower()
    
    if response == 'yes':
        # Migrate notes
        note_migrated, note_skipped, note_errors = migrate_notes_to_files()
        
        # Migrate boards
        board_migrated, board_skipped, board_errors = migrate_boards_to_files()
        
        # Verify
        verify_migration()
        
        print("\n" + "="*80)
        print("MIGRATION SUMMARY")
        print("="*80)
        print(f"\nNotes:")
        print(f"  Migrated: {note_migrated}")
        print(f"  Skipped: {note_skipped}")
        print(f"  Errors: {len(note_errors)}")
        print(f"\nBoards:")
        print(f"  Migrated: {board_migrated}")
        print(f"  Skipped: {board_skipped}")
        print(f"  Errors: {len(board_errors)}")
        print("\n" + "="*80)
        print("\nNext steps:")
        print("1. Verify migrated data in database")
        print("2. Test application with File-only routes")
        print("3. Once verified, manually drop Note and Board tables")
        print("="*80 + "\n")
    else:
        print("\nMigration cancelled.")
