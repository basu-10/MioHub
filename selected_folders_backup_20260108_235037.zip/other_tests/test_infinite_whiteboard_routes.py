"""
Test script for infinite whiteboard routes.
Run with: python test_infinite_whiteboard_routes.py
"""

from flask import Flask
from extensions import db
from blueprints import bps
import config

def test_routes():
    """Test that infinite whiteboard routes are registered."""
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SECRET_KEY'] = 'test-secret-key'
    
    db.init_app(app)
    
    # Register all blueprints
    for bp in bps:
        app.register_blueprint(bp)
        print(f"✓ Registered blueprint: {bp.name}")
    
    with app.app_context():
        # List all routes
        print("\n=== All Registered Routes ===")
        routes = []
        for rule in app.url_map.iter_rules():
            routes.append({
                'endpoint': rule.endpoint,
                'methods': ', '.join(sorted(rule.methods - {'HEAD', 'OPTIONS'})),
                'path': rule.rule
            })
        
        # Sort by path
        routes.sort(key=lambda x: x['path'])
        
        # Filter infinite whiteboard routes
        print("\n=== Infinite Whiteboard Routes ===")
        infinite_routes = [r for r in routes if 'infinite' in r['endpoint'].lower() or 'infinite' in r['path'].lower()]
        
        if infinite_routes:
            for route in infinite_routes:
                print(f"  {route['methods']:15} {route['path']:50} -> {route['endpoint']}")
            print(f"\n✓ Found {len(infinite_routes)} infinite whiteboard routes")
        else:
            print("  ✗ No infinite whiteboard routes found!")
            return False
        
        # Check for specific expected routes
        expected_routes = [
            '/infinite_boards/new',
            '/infinite_boards/edit/<int:board_id>',
            '/infinite_boards/view/<int:board_id>'
        ]
        
        print("\n=== Checking Expected Routes ===")
        registered_paths = [r['path'] for r in routes]
        all_found = True
        
        for expected in expected_routes:
            # Check if route exists in registered paths
            found = expected in registered_paths
            status = "✓" if found else "✗"
            print(f"  {status} {expected}")
            if not found:
                all_found = False
        
        if all_found:
            print("\n✓ All expected routes are registered!")
            return True
        else:
            print("\n✗ Some expected routes are missing!")
            return False

if __name__ == '__main__':
    try:
        success = test_routes()
        exit(0 if success else 1)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
