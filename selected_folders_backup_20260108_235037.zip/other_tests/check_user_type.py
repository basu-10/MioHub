"""
Quick script to check user_type values in the database
"""

import config
from flask import Flask
from blueprints.p2.models import db, User

def check_users():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        users = User.query.all()
        print("\n" + "="*60)
        print("User Types in Database:")
        print("="*60)
        for user in users:
            print(f"Username: {user.username:<20} | user_type: '{user.user_type}' | Total Data: {user.total_data_size or 0:,} bytes")
        print("="*60 + "\n")

if __name__ == '__main__':
    check_users()
