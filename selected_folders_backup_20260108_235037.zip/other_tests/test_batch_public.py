"""
Test script for batch set public functionality
"""
from flask import Flask
from extensions import db
from blueprints.p2.models import User, Folder, File
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    # Get test user
    user = User.query.filter_by(username='testuser').first()
    if not user:
        print("Test user not found!")
        exit(1)
    
    print(f"Testing with user: {user.username} (ID: {user.id})")
    
    # Get a sample folder
    folder = Folder.query.filter_by(user_id=user.id).first()
    if folder:
        print(f"\nFolder found: {folder.name} (ID: {folder.id})")
        print(f"  is_public: {folder.is_public}")
    else:
        print("\nNo folders found for user")
    
    # Get sample files
    files = File.query.filter_by(owner_id=user.id).limit(3).all()
    if files:
        print(f"\nFound {len(files)} files:")
        for f in files:
            print(f"  - {f.title} (ID: {f.id}, Type: {f.type}, is_public: {f.is_public})")
    else:
        print("\nNo files found for user")
    
    # Test that File and Folder models have is_public attribute
    print("\n=== Model Validation ===")
    print(f"Folder has is_public: {hasattr(Folder, 'is_public')}")
    print(f"File has is_public: {hasattr(File, 'is_public')}")
    
    if hasattr(Folder, 'is_public') and hasattr(File, 'is_public'):
        print("✓ Models are ready for batch public operation")
    else:
        print("✗ Models missing is_public attribute!")

print("\nTest complete!")
