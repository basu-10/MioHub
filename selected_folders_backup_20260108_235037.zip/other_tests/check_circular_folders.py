"""
Check for circular folder references in the database
"""
from flask import Flask
from extensions import db
from blueprints.p2.models import Folder
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
db.init_app(app)

def find_circular_references():
    """Find folders that have circular parent references"""
    with app.app_context():
        all_folders = Folder.query.all()
        print(f"Checking {len(all_folders)} folders for circular references...\n")
        
        issues_found = 0
        
        for folder in all_folders:
            visited = set()
            current = folder
            path = []
            
            # Walk up the parent chain
            while current:
                if current.id in visited:
                    # Circular reference found!
                    issues_found += 1
                    print(f"🔴 CIRCULAR REFERENCE DETECTED:")
                    print(f"   Folder ID: {folder.id}")
                    print(f"   Folder Name: '{folder.name}'")
                    print(f"   Owner ID: {folder.user_id}")
                    print(f"   Path: {' -> '.join(path)}")
                    print(f"   Circular at: {current.id} '{current.name}'")
                    print()
                    break
                
                visited.add(current.id)
                path.append(f"{current.id}:{current.name}")
                current = Folder.query.get(current.parent_id) if current.parent_id else None
        
        if issues_found == 0:
            print("✅ No circular references found!")
        else:
            print(f"\n❌ Found {issues_found} circular reference(s)!")
            print("\nTo fix, you can run:")
            print("UPDATE folder SET parent_id = NULL WHERE id = <problematic_folder_id>;")
        
        # Also check for self-referencing folders
        self_refs = Folder.query.filter(Folder.id == Folder.parent_id).all()
        if self_refs:
            print(f"\n🔴 Found {len(self_refs)} self-referencing folders:")
            for f in self_refs:
                print(f"   ID {f.id}: '{f.name}' (parent_id = {f.parent_id})")
                print(f"   Fix: UPDATE folder SET parent_id = NULL WHERE id = {f.id};")

if __name__ == '__main__':
    find_circular_references()
