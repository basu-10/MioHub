"""
Migration script to add new columns to existing PythonAnywhere database
Compares old schema with new models and adds missing columns
"""
import mysql.connector
import config
from datetime import datetime

DB_HOST = config.DB_HOST
DB_NAME = config.DB_NAME
DB_USER = config.DB_USER
DB_PASSWORD = config.DB_PASSWORD
DB_PORT = int(config.DB_PORT)

def get_connection():
    """Create database connection"""
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        port=DB_PORT
    )

def column_exists(cursor, table_name, column_name):
    """Check if a column exists in a table"""
    cursor.execute(f"SHOW COLUMNS FROM {table_name} LIKE '{column_name}'")
    return cursor.fetchone() is not None

def table_exists(cursor, table_name):
    """Check if a table exists"""
    cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
    return cursor.fetchone() is not None

def migrate_user_table(conn, cursor):
    """Add new columns to user table"""
    print("\n=== Migrating USER table ===")
    
    migrations = [
        {
            'column': 'user_type',
            'sql': "ALTER TABLE user ADD COLUMN user_type VARCHAR(20) NOT NULL DEFAULT 'guest'",
            'description': 'User type (guest, user, admin, moderator)'
        },
        {
            'column': 'total_data_size',
            'sql': "ALTER TABLE user ADD COLUMN total_data_size BIGINT DEFAULT 0",
            'description': 'Total data size tracking'
        }
    ]
    
    for migration in migrations:
        if not column_exists(cursor, 'user', migration['column']):
            print(f"Adding column: {migration['column']} - {migration['description']}")
            cursor.execute(migration['sql'])
            conn.commit()
            print(f"✓ Added {migration['column']}")
        else:
            print(f"○ Column {migration['column']} already exists")

def migrate_folder_table(conn, cursor):
    """Add new columns to folder table"""
    print("\n=== Migrating FOLDER table ===")
    
    migrations = [
        {
            'column': 'created_at',
            'sql': "ALTER TABLE folder ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
            'description': 'Folder creation timestamp'
        }
    ]
    
    for migration in migrations:
        if not column_exists(cursor, 'folder', migration['column']):
            print(f"Adding column: {migration['column']} - {migration['description']}")
            cursor.execute(migration['sql'])
            conn.commit()
            print(f"✓ Added {migration['column']}")
        else:
            print(f"○ Column {migration['column']} already exists")

def migrate_note_table(conn, cursor):
    """Add new columns to note table"""
    print("\n=== Migrating NOTE table ===")
    
    migrations = [
        {
            'column': 'created_at',
            'sql': "ALTER TABLE note ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
            'description': 'Note creation timestamp'
        }
    ]
    
    # Check if content column needs to be upgraded to LONGTEXT
    cursor.execute("SHOW COLUMNS FROM note LIKE 'content'")
    content_col = cursor.fetchone()
    if content_col and 'text' in content_col[1].lower() and 'longtext' not in content_col[1].lower():
        print("Upgrading content column from TEXT to LONGTEXT with utf8mb4_unicode_ci")
        cursor.execute("ALTER TABLE note MODIFY COLUMN content LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn.commit()
        print("✓ Upgraded content column")
    
    for migration in migrations:
        if not column_exists(cursor, 'note', migration['column']):
            print(f"Adding column: {migration['column']} - {migration['description']}")
            cursor.execute(migration['sql'])
            conn.commit()
            print(f"✓ Added {migration['column']}")
        else:
            print(f"○ Column {migration['column']} already exists")

def migrate_boards_table(conn, cursor):
    """Add new columns to boards table"""
    print("\n=== Migrating BOARDS table ===")
    
    migrations = [
        {
            'column': 'created_at',
            'sql': "ALTER TABLE boards ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP",
            'description': 'Board creation timestamp'
        }
    ]
    
    # Check if content column needs to be upgraded to LONGTEXT
    cursor.execute("SHOW COLUMNS FROM boards LIKE 'content'")
    content_col = cursor.fetchone()
    if content_col and 'text' in content_col[1].lower() and 'longtext' not in content_col[1].lower():
        print("Upgrading content column from TEXT to LONGTEXT with utf8mb4_unicode_ci")
        cursor.execute("ALTER TABLE boards MODIFY COLUMN content LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn.commit()
        print("✓ Upgraded content column")
    
    for migration in migrations:
        if not column_exists(cursor, 'boards', migration['column']):
            print(f"Adding column: {migration['column']} - {migration['description']}")
            cursor.execute(migration['sql'])
            conn.commit()
            print(f"✓ Added {migration['column']}")
        else:
            print(f"○ Column {migration['column']} already exists")

def create_p3_tables(conn, cursor):
    """Create Product 3 (AI Chatbot) tables if they don't exist"""
    print("\n=== Creating PRODUCT 3 tables ===")
    
    # ChatSession table
    if not table_exists(cursor, 'chat_sessions'):
        print("Creating chat_sessions table...")
        cursor.execute("""
            CREATE TABLE chat_sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                title VARCHAR(200) NOT NULL DEFAULT 'New chat',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """)
        conn.commit()
        print("✓ Created chat_sessions table")
    else:
        print("○ chat_sessions table already exists")
    
    # ChatMessage table
    if not table_exists(cursor, 'chat_messages'):
        print("Creating chat_messages table...")
        cursor.execute("""
            CREATE TABLE chat_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                session_id INT NOT NULL,
                model VARCHAR(100) NOT NULL,
                role VARCHAR(20) NOT NULL,
                content LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
                INDEX idx_session_id (session_id),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """)
        conn.commit()
        print("✓ Created chat_messages table")
    else:
        print("○ chat_messages table already exists")
    
    # ChatMemory table
    if not table_exists(cursor, 'chat_memories'):
        print("Creating chat_memories table...")
        cursor.execute("""
            CREATE TABLE chat_memories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                session_id INT NOT NULL,
                text LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                enabled TINYINT(1) DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
                INDEX idx_session_id (session_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """)
        conn.commit()
        print("✓ Created chat_memories table")
    else:
        print("○ chat_memories table already exists")
    
    # GameScore table
    if not table_exists(cursor, 'game_scores'):
        print("Creating game_scores table...")
        cursor.execute("""
            CREATE TABLE game_scores (
                id INT AUTO_INCREMENT PRIMARY KEY,
                game_name VARCHAR(100) NOT NULL,
                username VARCHAR(64),
                score INT NOT NULL,
                achieved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_game_name (game_name),
                INDEX idx_score (score),
                INDEX idx_achieved_at (achieved_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """)
        conn.commit()
        print("✓ Created game_scores table")
    else:
        print("○ game_scores table already exists")

def show_final_schema(cursor):
    """Display final schema after migration"""
    print("\n" + "="*60)
    print("FINAL DATABASE SCHEMA AFTER MIGRATION")
    print("="*60)
    
    cursor.execute("SHOW TABLES")
    tables = cursor.fetchall()
    
    for table in tables:
        table_name = table[0]
        print(f"\nTable: {table_name}")
        
        cursor.execute(f"DESCRIBE {table_name}")
        columns = cursor.fetchall()
        print("Columns:")
        for col in columns:
            col_name = col[0]
            col_type = col[1]
            nullable = "NULL" if col[2] == "YES" else "NOT NULL"
            default = f"DEFAULT {col[4]}" if col[4] is not None else ""
            print(f"  {col_name}: {col_type} {nullable} {default}")

def main():
    """Main migration function"""
    print("="*60)
    print("DATABASE MIGRATION SCRIPT")
    print("="*60)
    print(f"Database: {DB_NAME}")
    print(f"Host: {DB_HOST}:{DB_PORT}")
    print(f"User: {DB_USER}")
    print("="*60)
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Migrate existing tables
        migrate_user_table(conn, cursor)
        migrate_folder_table(conn, cursor)
        migrate_note_table(conn, cursor)
        migrate_boards_table(conn, cursor)
        
        # Create new Product 3 tables
        create_p3_tables(conn, cursor)
        
        # Show final schema
        show_final_schema(cursor)
        
        print("\n" + "="*60)
        print("✓ MIGRATION COMPLETED SUCCESSFULLY")
        print("="*60)
        
        cursor.close()
        conn.close()
        
    except mysql.connector.Error as err:
        print(f"\n✗ ERROR: {err}")
        print("Migration failed!")
        return 1
    
    return 0

if __name__ == "__main__":
    response = input("\n⚠ WARNING: This will modify your database structure.\nAre you sure you want to proceed? (yes/no): ")
    if response.lower() in ['yes', 'y']:
        exit(main())
    else:
        print("Migration cancelled.")
