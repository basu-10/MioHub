"""
Test the notification system implementation

This script verifies:
1. Notification model is accessible
2. add_notification() function works
3. Notifications are properly stored and retrieved
4. 50-notification limit is enforced
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import Notification, User
from blueprints.p2.utils import add_notification
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_notification_system():
    """Test the notification system end-to-end."""
    with app.app_context():
        print("=" * 70)
        print("Testing Notification System")
        print("=" * 70)
        
        # Get a test user
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            print("✗ Test user 'testuser' not found. Please run init_db.py first.")
            return
        
        print(f"✓ Found test user: {test_user.username} (ID: {test_user.id})")
        
        # Clear any existing notifications for clean test
        existing_count = Notification.query.filter_by(user_id=test_user.id).count()
        print(f"  Existing notifications: {existing_count}")
        
        # Test 1: Add a few notifications
        print("\nTest 1: Adding sample notifications...")
        test_messages = [
            ("Saved markdown: Test Document (2.5 KB)", "save"),
            ("Saved note: Meeting Notes (15.3 KB)", "save"),
            ("Saved board: Diagram Draft (45.2 KB)", "save"),
            ("Transfer complete: Folder copied to user123", "transfer"),
            ("Deleted file: Old Draft", "delete"),
        ]
        
        for msg, msg_type in test_messages:
            notif = add_notification(test_user.id, msg, msg_type)
            if notif:
                print(f"  ✓ Added {msg_type}: {msg[:50]}...")
            else:
                print(f"  ✗ Failed to add notification")
        
        # Test 2: Retrieve notifications
        print("\nTest 2: Retrieving notifications...")
        notifications = (
            Notification.query
            .filter_by(user_id=test_user.id)
            .order_by(Notification.timestamp.desc())
            .all()
        )
        
        print(f"  Retrieved {len(notifications)} notifications:")
        for i, notif in enumerate(notifications[:10], 1):
            print(f"    {i}. [{notif.type}] {notif.message[:50]}... ({notif.timestamp})")
        
        # Test 3: Verify 50-notification limit
        print("\nTest 3: Testing 50-notification limit...")
        print(f"  Current count: {len(notifications)}")
        
        # Add 55 more notifications to test limit enforcement
        print("  Adding 55 more notifications to test limit...")
        for i in range(55):
            add_notification(
                test_user.id,
                f"Test notification #{i+1} - Lorem ipsum dolor sit amet",
                "info"
            )
        
        # Check final count
        final_notifications = Notification.query.filter_by(user_id=test_user.id).all()
        final_count = len(final_notifications)
        
        if final_count == 50:
            print(f"  ✓ Limit enforced correctly: {final_count} notifications (max 50)")
        else:
            print(f"  ✗ Limit not enforced: {final_count} notifications (expected 50)")
        
        # Test 4: Verify to_dict() serialization
        print("\nTest 4: Testing JSON serialization...")
        latest = final_notifications[0] if final_notifications else None
        if latest:
            notif_dict = latest.to_dict()
            required_keys = {'id', 'message', 'timestamp', 'type'}
            if required_keys.issubset(notif_dict.keys()):
                print(f"  ✓ Serialization works: {notif_dict}")
            else:
                print(f"  ✗ Missing keys in serialization: {notif_dict.keys()}")
        
        print("\n" + "=" * 70)
        print("Notification System Test Complete!")
        print("=" * 70)
        print("\nNext Steps:")
        print("1. Open the Flask app in browser: http://localhost:5555")
        print("2. Log in as 'testuser' / 'password123'")
        print("3. Click the telemetry panel to open the modal")
        print("4. Verify notifications appear in the list")
        print("5. Save a file and watch for the notification in the mini panel")
        print("6. Refresh telemetry modal to see the new notification in the list")

if __name__ == '__main__':
    test_notification_system()
