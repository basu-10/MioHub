"""
Test script for dual-arrow sidebar toggle system
Verifies that the HTML structure and JavaScript functions are correctly implemented
"""

import os
import re

def test_dual_arrows():
    """Test that dual arrow system is properly implemented"""
    sidebar_file = r"d:\dev_work\web_dev\personal site\from pythonanywhere\myproject_backup.v2.16\blueprints\p2\templates\p2\folder_view_left_sidebar_partial.html"
    
    with open(sidebar_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: Check for dual toggle buttons in HTML
    print("Test 1: Checking for dual toggle buttons...")
    if 'id="foldersToggleBtn"' in content and 'id="socialToggleBtn"' in content:
        print("✓ Both toggle buttons found")
        tests_passed += 1
    else:
        print("✗ Toggle buttons not found")
        tests_failed += 1
    
    # Test 2: Check for correct icons
    print("\nTest 2: Checking for folder and people icons...")
    folder_icon_pattern = r'<i class="material-icons">folder</i>'
    people_icon_pattern = r'<i class="material-icons">people</i>'
    
    if re.search(folder_icon_pattern, content) and re.search(people_icon_pattern, content):
        print("✓ Both icons (folder and people) found")
        tests_passed += 1
    else:
        print("✗ Icons not found")
        tests_failed += 1
    
    # Test 3: Check for openFolderBrowserTab function
    print("\nTest 3: Checking for openFolderBrowserTab function...")
    if 'function openFolderBrowserTab(tabName)' in content:
        print("✓ openFolderBrowserTab function found")
        tests_passed += 1
    else:
        print("✗ openFolderBrowserTab function not found")
        tests_failed += 1
    
    # Test 4: Check for updateToggleButtonStates function
    print("\nTest 4: Checking for updateToggleButtonStates function...")
    if 'function updateToggleButtonStates(activeTab)' in content:
        print("✓ updateToggleButtonStates function found")
        tests_passed += 1
    else:
        print("✗ updateToggleButtonStates function not found")
        tests_failed += 1
    
    # Test 5: Check for closeFolderBrowser function
    print("\nTest 5: Checking for closeFolderBrowser function...")
    if 'function closeFolderBrowser()' in content:
        print("✓ closeFolderBrowser function found")
        tests_passed += 1
    else:
        print("✗ closeFolderBrowser function not found")
        tests_failed += 1
    
    # Test 6: Check for sidebar-toggles-container class
    print("\nTest 6: Checking for sidebar-toggles-container styling...")
    if '.sidebar-toggles-container' in content:
        print("✓ sidebar-toggles-container CSS found")
        tests_passed += 1
    else:
        print("✗ sidebar-toggles-container CSS not found")
        tests_failed += 1
    
    # Test 7: Check for active state styling
    print("\nTest 7: Checking for active button styling...")
    if '.folder-browser-toggle.active' in content:
        print("✓ Active button styling found")
        tests_passed += 1
    else:
        print("✗ Active button styling not found")
        tests_failed += 1
    
    # Test 8: Check localStorage integration
    print("\nTest 8: Checking for localStorage integration...")
    if "localStorage.getItem('folderBrowserActiveTab')" in content:
        print("✓ localStorage integration found")
        tests_passed += 1
    else:
        print("✗ localStorage integration not found")
        tests_failed += 1
    
    print("\n" + "="*50)
    print(f"Tests Passed: {tests_passed}/{tests_passed + tests_failed}")
    print(f"Tests Failed: {tests_failed}/{tests_passed + tests_failed}")
    print("="*50)
    
    if tests_failed == 0:
        print("\n✓ All tests passed! Dual-arrow system is properly implemented.")
        return True
    else:
        print("\n✗ Some tests failed. Please review the implementation.")
        return False

if __name__ == "__main__":
    test_dual_arrows()
