#!/usr/bin/env python3
"""
Migration: add `file_path` column to `chat_attachments` for disk-backed files (PDFs).

- Adds VARCHAR(500) NULL column when missing.
- Safe to re-run; skips if column already exists.

Usage (from project root, venv activated):
  python other_tests/migrate_add_chat_attachment_file_path.py
"""

import os
import sys
from datetime import datetime

# Ensure project root is on the import path so extensions/config resolve
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from flask import Flask
from extensions import db
import config


def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    return app


def column_exists(inspector, table_name, column_name):
    try:
        columns = inspector.get_columns(table_name)
        return column_name in [c['name'] for c in columns]
    except Exception as exc:  # noqa: BLE001
        print(f"Error checking {table_name}.{column_name}: {exc}")
        return None


def add_file_path_column():
    inspector = db.inspect(db.engine)
    table_name = 'chat_attachments'
    column_name = 'file_path'

    if table_name not in inspector.get_table_names():
        print(f"Table '{table_name}' not found; aborting.")
        return False

    exists = column_exists(inspector, table_name, column_name)
    if exists is None:
        return False
    if exists:
        print(f"Column '{column_name}' already present on '{table_name}'. Nothing to do.")
        return True

    print(f"Adding column '{column_name}' to '{table_name}'...")
    with db.engine.connect() as conn:
        conn.execute(db.text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} VARCHAR(500) NULL"))
        conn.commit()

    # Re-inspect
    inspector = db.inspect(db.engine)
    exists_after = column_exists(inspector, table_name, column_name)
    if exists_after:
        print(f"Column '{column_name}' successfully added to '{table_name}'.")
        return True
    print(f"Failed to verify column '{column_name}' on '{table_name}'.")
    return False


def main():
    print("\nADD file_path TO chat_attachments\n")
    print(f"Started: {datetime.now():%Y-%m-%d %H:%M:%S}\n")
    app = create_app()
    with app.app_context():
        success = add_file_path_column()
    print(f"\nFinished: {datetime.now():%Y-%m-%d %H:%M:%S}")
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
