"""
Migration script: Convert MioBook documents from notes table to files table.

This script:
1. Finds all Note records that are MioBook documents (contain JSON array with note/board blocks)
2. Creates corresponding File records with type='book' and content_json
3. Preserves all metadata (owner, folder, timestamps, public flags)
4. Updates user storage quota appropriately
5. Optionally deletes the migrated Note records

Run with: python migrate_miobook_to_files.py
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import Note, File, User
from sqlalchemy.orm.attributes import flag_modified
import config
import json
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def is_miobook_note(note):
    """Check if a Note is a MioBook document based on content structure."""
    if not note.content:
        return False
    try:
        content_data = json.loads(note.content)
        if isinstance(content_data, list) and any(
            block.get('type') in ['note', 'board'] for block in content_data if isinstance(block, dict)
        ):
            return True
    except (json.JSONDecodeError, TypeError):
        pass
    return False

def migrate_note_to_file(note):
    """Convert a MioBook Note to a File record."""
    try:
        # Parse the JSON content from the note
        content_blocks = json.loads(note.content)
        if not isinstance(content_blocks, list):
            print(f"  ⚠️  Note {note.id} has invalid content structure, skipping")
            return None
        
        # Create the File record
        book_file = File(
            owner_id=note.user_id,
            folder_id=note.folder_id,
            type='book',
            title=note.title,
            content_json=content_blocks,
            metadata_json={
                'description': 'MioBook combined document',
                'migrated_from_note_id': note.id,
                'migration_date': datetime.utcnow().isoformat()
            },
            created_at=note.created_at,
            last_modified=note.last_modified or note.created_at,
            is_public=getattr(note, 'is_public', False)
        )
        
        return book_file
        
    except Exception as e:
        print(f"  ❌ Error migrating note {note.id}: {e}")
        return None

def main():
    with app.app_context():
        print("=" * 80)
        print("MioBook Migration: Notes → Files Table")
        print("=" * 80)
        print()
        
        # Find all notes
        all_notes = Note.query.all()
        print(f"📊 Total notes in database: {len(all_notes)}")
        
        # Identify MioBook notes
        miobook_notes = [note for note in all_notes if is_miobook_note(note)]
        print(f"📚 MioBook documents found: {len(miobook_notes)}")
        print()
        
        if not miobook_notes:
            print("✅ No MioBook documents to migrate. Exiting.")
            return
        
        # Show preview
        print("Preview of MioBook documents to migrate:")
        print("-" * 80)
        for note in miobook_notes[:5]:  # Show first 5
            blocks = len(json.loads(note.content))
            print(f"  • ID {note.id}: '{note.title}' ({blocks} blocks, folder_id={note.folder_id})")
        if len(miobook_notes) > 5:
            print(f"  ... and {len(miobook_notes) - 5} more")
        print()
        
        # Confirm migration
        response = input("Proceed with migration? (yes/no): ").strip().lower()
        if response != 'yes':
            print("❌ Migration cancelled.")
            return
        
        print()
        print("Starting migration...")
        print("-" * 80)
        
        migrated_count = 0
        failed_count = 0
        
        for note in miobook_notes:
            print(f"Migrating note {note.id}: '{note.title}'...")
            
            # Convert to File
            book_file = migrate_note_to_file(note)
            if not book_file:
                failed_count += 1
                continue
            
            # Save the new File record
            try:
                db.session.add(book_file)
                db.session.flush()  # Get the ID without committing
                
                print(f"  ✅ Created File ID {book_file.id}")
                migrated_count += 1
                
            except Exception as e:
                print(f"  ❌ Failed to save: {e}")
                db.session.rollback()
                failed_count += 1
                continue
        
        # Commit all migrations
        try:
            db.session.commit()
            print()
            print("=" * 80)
            print(f"✅ Migration complete!")
            print(f"   Migrated: {migrated_count}")
            print(f"   Failed: {failed_count}")
            print("=" * 80)
            print()
            
            # Ask about cleanup
            print("⚠️  Old Note records are still in the database.")
            print("   They can be safely deleted after verifying the migration.")
            cleanup = input("Delete old MioBook Note records now? (yes/no): ").strip().lower()
            
            if cleanup == 'yes':
                print()
                print("Deleting old MioBook notes...")
                for note in miobook_notes:
                    db.session.delete(note)
                db.session.commit()
                print(f"✅ Deleted {len(miobook_notes)} old Note records")
            else:
                print("ℹ️  Old notes retained. You can delete them manually later.")
                
        except Exception as e:
            print(f"❌ Migration failed during commit: {e}")
            db.session.rollback()

if __name__ == '__main__':
    main()
