"""
Migration script to add description column to folder table
Run this script to add the description field to existing folders
"""

import config
from extensions import db
from flask import Flask
from blueprints.p2.models import Folder
from sqlalchemy import text

def migrate_add_description():
    """Add description column to folder table"""
    app = Flask(__name__)
    
    # Configure database
    db_uri = config.get_database_uri()
    app.config['SQLALCHEMY_DATABASE_URI'] = db_uri
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    with app.app_context():
        # Check if column already exists
        inspector = db.inspect(db.engine)
        columns = [col['name'] for col in inspector.get_columns('folder')]
        
        if 'description' in columns:
            print("✓ Description column already exists in folder table")
            return
        
        # Add description column
        try:
            with db.engine.connect() as conn:
                conn.execute(text(
                    "ALTER TABLE folder ADD COLUMN description VARCHAR(500) NULL"
                ))
                conn.commit()
            print("✓ Successfully added description column to folder table")
        except Exception as e:
            print(f"✗ Error adding description column: {e}")
            raise

if __name__ == "__main__":
    print("Starting migration: Add description column to folder table")
    migrate_add_description()
    print("Migration completed!")
