"""
Test script to verify Blocks editor UX enhancements.

This test verifies:
1. onChange handler is properly configured
2. logLevel is set to 'ERROR' to reduce console noise
3. Enhanced save indicator with visual states (saving, saved, unsaved)
4. Pulse animation for saving state
5. onReady callback logs success message

Run this test to ensure all UX improvements are in place.
"""

import re

def test_blocks_ux_enhancements():
    """Test that the Blocks editor template has all UX enhancements."""
    
    template_path = "blueprints/p2/templates/p2/file_edit_blocks.html"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Test 1: Check for logLevel configuration
    print("Test 1: Checking logLevel configuration...")
    assert "logLevel: 'ERROR'" in content, "❌ logLevel not set to ERROR"
    print("✅ logLevel set to 'ERROR' (reduces console noise)")
    
    # Test 2: Check for onChange handler
    print("\nTest 2: Checking onChange handler...")
    assert 'onChange: (api, event) => {' in content, "❌ onChange handler not found"
    print("✅ onChange handler is configured")
    
    # Test 3: Check for console.log in onReady
    print("\nTest 3: Checking onReady console message...")
    assert 'console.log' in content and 'Blocks editor ready' in content, "❌ Ready message not found"
    print("✅ onReady logs success message")
    
    # Test 4: Check for enhanced save indicator states
    print("\nTest 4: Checking enhanced save indicator CSS...")
    assert '.save-indicator.saving' in content, "❌ Saving state CSS not found"
    assert '.save-indicator.saved' in content, "❌ Saved state CSS not found"
    assert '.save-indicator.unsaved' in content, "❌ Unsaved state CSS not found"
    print("✅ All save indicator states defined (saving, saved, unsaved)")
    
    # Test 5: Check for visual enhancements
    print("\nTest 5: Checking visual enhancements...")
    assert 'transition: all 0.3s ease' in content, "❌ Transition animation not found"
    assert 'rgba(20, 184, 166, 0.1)' in content, "❌ Background color overlay not found"
    assert 'border-color: var(--accent)' in content, "❌ Border color change not found"
    print("✅ Visual transitions and color changes configured")
    
    # Test 6: Check for pulse animation
    print("\nTest 6: Checking pulse animation...")
    assert '@keyframes pulse' in content, "❌ Pulse keyframe animation not found"
    assert 'animation: pulse 1.5s ease-in-out infinite' in content, "❌ Pulse animation not applied"
    print("✅ Pulse animation configured for saving state")
    
    # Test 7: Check unsaved state color
    print("\nTest 7: Checking unsaved state styling...")
    assert '#fbbf24' in content, "❌ Unsaved (yellow) color not found"
    assert 'rgba(251, 191, 36, 0.1)' in content, "❌ Unsaved background not found"
    print("✅ Unsaved state has yellow/amber styling")
    
    print("\n" + "="*60)
    print("✅ All UX enhancement tests passed!")
    print("\n📊 Visual Feedback Summary:")
    print("   • READY:   Gray text, default border")
    print("   • UNSAVED: Yellow text, yellow border, amber background")
    print("   • SAVING:  Teal text, teal border, teal background, pulsing icon")
    print("   • SAVED:   Green text, green border, green background")
    print("\n🎯 User Experience Improvements:")
    print("   • Clear visual feedback for save states")
    print("   • Smooth transitions between states (0.3s)")
    print("   • Animated icon during save (pulse effect)")
    print("   • Console logging reduced (ERROR level only)")
    print("   • onChange handler tracks all edits")
    print("="*60)

if __name__ == "__main__":
    try:
        test_blocks_ux_enhancements()
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        exit(1)
    except FileNotFoundError:
        print("❌ Template file not found. Make sure you're running from project root.")
        exit(1)
