"""Check existing boards with descriptions."""
from flask import Flask
from extensions import db
from blueprints.p2.models import File
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
db.init_app(app)

with app.app_context():
    boards = File.query.filter_by(type='whiteboard').all()
    boards_with_desc = [b for b in boards if b.metadata_json and b.metadata_json.get('description')]
    
    print(f"Total boards: {len(boards)}")
    print(f"Boards with descriptions: {len(boards_with_desc)}")
    print()
    
    if boards_with_desc:
        print("Boards with descriptions:")
        for b in boards_with_desc[:10]:
            print(f"  - Board {b.id}: '{b.title[:40]}...' - Description: '{b.description[:60]}...'")
    else:
        print("No boards with descriptions found.")
