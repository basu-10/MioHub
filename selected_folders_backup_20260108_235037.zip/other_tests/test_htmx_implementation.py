"""
Test HTMX Paste Implementation

This script verifies that the updated routes return HTML fragments when htmx=true.
"""

import sys
import os

# Add project root to path
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

def test_htmx_integration():
    """Verify HTMX integration is working"""
    
    print("🔍 HTMX Paste Implementation Test")
    print("=" * 60)
    
    # Check that routes were updated
    routes_to_check = [
        ('blueprints/p2/folder_routes.py', 'duplicate_note'),
        ('blueprints/p2/folder_routes.py', 'duplicate_board_route'),
        ('blueprints/p2/folder_routes.py', 'copy_folder_route'),
        ('blueprints/p2/folder_routes.py', 'batch_paste_route'),
        ('blueprints/p2/file_routes.py', 'duplicate_file'),
    ]
    
    all_updated = True
    
    for file_path, route_name in routes_to_check:
        full_path = os.path.join(project_root, file_path)
        
        if not os.path.exists(full_path):
            print(f"❌ File not found: {file_path}")
            all_updated = False
            continue
        
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Check for HTMX support
        if "request.form.get('htmx') == 'true'" in content:
            if 'new_item_html' in content or 'new_items_html' in content:
                print(f"✅ {route_name}: HTMX support added")
            else:
                print(f"⚠️  {route_name}: HTMX check found but HTML response missing")
                all_updated = False
        else:
            print(f"❌ {route_name}: No HTMX support detected")
            all_updated = False
    
    print("=" * 60)
    
    if all_updated:
        print("✨ All routes successfully updated with HTMX support!")
        print("\n📝 Next steps:")
        print("1. Start your Flask app: python flask_app.py")
        print("2. Copy a note/board/file (Ctrl+C)")
        print("3. Paste it (Ctrl+V)")
        print("4. Watch it appear with smooth animation - no page reload!")
        return True
    else:
        print("⚠️  Some routes may need manual verification")
        return False

if __name__ == '__main__':
    success = test_htmx_integration()
    sys.exit(0 if success else 1)
