"""
Test script for table file viewing and editing functionality.
Verifies that table files render properly in both view and edit modes.
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, User
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SECRET_KEY'] = 'test-key'
db.init_app(app)

def test_table_file_access():
    """Test that table files can be accessed and their data is valid."""
    with app.app_context():
        # Find table files
        table_files = File.query.filter_by(type='table').all()
        print(f"Found {len(table_files)} table file(s)")
        
        for table_file in table_files:
            print(f"\n=== Table File ID: {table_file.id} ===")
            print(f"Title: {table_file.title}")
            print(f"Owner: {table_file.owner_id}")
            print(f"Content type: {type(table_file.content_json)}")
            
            # Check content structure
            content = table_file.content_json
            if isinstance(content, list):
                print(f"Format: Luckysheet (array of {len(content)} sheet(s))")
                for i, sheet in enumerate(content):
                    if isinstance(sheet, dict):
                        print(f"  Sheet {i}: {sheet.get('name', 'Unnamed')}")
                        data = sheet.get('data', [])
                        print(f"    Rows: {len(data)}")
            elif isinstance(content, dict):
                if 'data' in content and 'columns' in content:
                    print(f"Format: Tabulator (legacy)")
                    print(f"  Rows: {len(content['data'])}")
                    print(f"  Columns: {len(content['columns'])}")
                else:
                    print(f"Format: Unknown dict structure")
                    print(f"  Keys: {list(content.keys())}")
            else:
                print(f"Format: Unknown ({type(content)})")
            
            # Verify content_json is not None
            if table_file.content_json is None:
                print("  ⚠️  WARNING: content_json is None!")
            else:
                print("  ✓ content_json is populated")
            
            # Check metadata
            if table_file.metadata_json:
                print(f"Metadata: {table_file.metadata_json}")

def test_routes_exist():
    """Test that table file routes are properly registered."""
    with app.app_context():
        from flask import url_for
        
        print("\n=== Testing Route Registration ===")
        try:
            # Test new file route
            url = url_for('file.new_file', file_type='table', _external=False)
            print(f"✓ New table route: {url}")
        except Exception as e:
            print(f"✗ New table route error: {e}")
        
        try:
            # Test edit file route
            url = url_for('file.edit_file', file_id=1, _external=False)
            print(f"✓ Edit file route: {url}")
        except Exception as e:
            print(f"✗ Edit file route error: {e}")
        
        try:
            # Test view file route
            url = url_for('file.view_file', file_id=1, _external=False)
            print(f"✓ View file route: {url}")
        except Exception as e:
            print(f"✗ View file route error: {e}")

def test_template_existence():
    """Test that required templates exist."""
    import os
    
    print("\n=== Testing Template Files ===")
    template_dir = os.path.join(os.path.dirname(__file__), 'blueprints', 'p2', 'templates', 'p2')
    
    templates = [
        'file_new_table.html',
        'file_edit_table.html',
        'file_view_table.html'
    ]
    
    for template in templates:
        path = os.path.join(template_dir, template)
        if os.path.exists(path):
            size = os.path.getsize(path)
            print(f"✓ {template} ({size} bytes)")
        else:
            print(f"✗ {template} NOT FOUND")

if __name__ == '__main__':
    print("=" * 60)
    print("TABLE FILE FUNCTIONALITY TEST")
    print("=" * 60)
    
    test_template_existence()
    test_routes_exist()
    test_table_file_access()
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
