#!/usr/bin/env python3
"""
Test script to verify last_modified column functionality for notes and boards.
"""

import sys
import os
from datetime import datetime, timedelta
from time import sleep

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from extensions import db
from blueprints.p2.models import Note, Board, User, Folder
import config

def create_app():
    """Create Flask app for testing."""
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    return app

def test_last_modified_functionality():
    """Test the last_modified column updates."""
    print("Testing last_modified functionality...")
    print("=" * 50)
    
    # Get a test user
    test_user = User.query.filter_by(user_type='admin').first()
    if not test_user:
        print("No admin user found for testing")
        return False
    
    print(f"Using test user: {test_user.username}")
    
    # Get or create a test folder
    test_folder = Folder.query.filter_by(user_id=test_user.id).first()
    if not test_folder:
        test_folder = Folder(name="Test Folder", user_id=test_user.id)
        db.session.add(test_folder)
        db.session.commit()
    
    print(f"Using test folder: {test_folder.name}")
    
    # Test 1: Create a new note and verify last_modified is set
    print("\n1. Testing new note creation...")
    note = Note(
        title="Test Note for Last Modified",
        content="Initial content",
        user_id=test_user.id,
        folder_id=test_folder.id
    )
    db.session.add(note)
    db.session.commit()
    
    print(f"   Created note with ID: {note.id}")
    print(f"   created_at: {note.created_at}")
    print(f"   last_modified: {note.last_modified}")
    
    if note.last_modified is None:
        print("   ❌ ERROR: last_modified is None for new note")
        return False
    elif abs((note.created_at - note.last_modified).total_seconds()) < 1:
        print("   ✅ PASS: last_modified set correctly for new note")
    else:
        print("   ❌ ERROR: last_modified doesn't match created_at for new note")
        return False
    
    # Test 2: Update note and verify last_modified changes
    print("\n2. Testing note update...")
    sleep(1)  # Wait 1 second to ensure time difference
    original_last_modified = note.last_modified
    
    note.content = "Updated content"
    note.last_modified = datetime.utcnow()
    db.session.commit()
    
    print(f"   Original last_modified: {original_last_modified}")
    print(f"   New last_modified: {note.last_modified}")
    
    if note.last_modified > original_last_modified:
        print("   ✅ PASS: last_modified updated correctly for note")
    else:
        print("   ❌ ERROR: last_modified not updated for note")
        return False
    
    # Test 3: Create a new board and verify last_modified is set
    print("\n3. Testing new board creation...")
    board = Board(
        title="Test Board for Last Modified",
        content='{"elements": []}',
        user_id=test_user.id,
        folder_id=test_folder.id
    )
    db.session.add(board)
    db.session.commit()
    
    print(f"   Created board with ID: {board.id}")
    print(f"   created_at: {board.created_at}")
    print(f"   last_modified: {board.last_modified}")
    
    if board.last_modified is None:
        print("   ❌ ERROR: last_modified is None for new board")
        return False
    elif abs((board.created_at - board.last_modified).total_seconds()) < 1:
        print("   ✅ PASS: last_modified set correctly for new board")
    else:
        print("   ❌ ERROR: last_modified doesn't match created_at for new board")
        return False
    
    # Test 4: Update board and verify last_modified changes
    print("\n4. Testing board update...")
    sleep(1)  # Wait 1 second to ensure time difference
    original_board_last_modified = board.last_modified
    
    board.content = '{"elements": [{"type": "text", "text": "Updated"}]}'
    board.last_modified = datetime.utcnow()
    db.session.commit()
    
    print(f"   Original last_modified: {original_board_last_modified}")
    print(f"   New last_modified: {board.last_modified}")
    
    if board.last_modified > original_board_last_modified:
        print("   ✅ PASS: last_modified updated correctly for board")
    else:
        print("   ❌ ERROR: last_modified not updated for board")
        return False
    
    # Test 5: Verify onupdate functionality (SQLAlchemy should handle this automatically)
    print("\n5. Testing SQLAlchemy onupdate functionality...")
    sleep(1)
    original_note_last_modified = note.last_modified
    
    # Update without manually setting last_modified
    note.title = "Updated Title via SQLAlchemy onupdate"
    db.session.commit()
    
    print(f"   Original last_modified: {original_note_last_modified}")
    print(f"   New last_modified: {note.last_modified}")
    
    # Note: onupdate may or may not work depending on SQLAlchemy version and MySQL configuration
    if note.last_modified >= original_note_last_modified:
        print("   ✅ PASS: last_modified handled correctly (manual or automatic)")
    else:
        print("   ❌ ERROR: last_modified went backwards")
        return False
    
    # Cleanup test data
    print("\n6. Cleaning up test data...")
    db.session.delete(note)
    db.session.delete(board)
    db.session.commit()
    print("   ✅ Test data cleaned up")
    
    return True

def main():
    """Main test function."""
    print("Starting last_modified column tests...")
    print(f"Timestamp: {datetime.now()}")
    print("-" * 50)
    
    app = create_app()
    
    with app.app_context():
        success = test_last_modified_functionality()
        
    print("\n" + "=" * 50)
    if success:
        print("✅ All tests passed! last_modified functionality is working correctly.")
    else:
        print("❌ Some tests failed! Please check the implementation.")
        return 1
        
    return 0

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)