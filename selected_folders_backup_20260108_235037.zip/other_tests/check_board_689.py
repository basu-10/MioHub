"""Check board 689 from the logs."""
from flask import Flask
from extensions import db
from blueprints.p2.models import File
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
db.init_app(app)

with app.app_context():
    board = db.session.get(File, 689)
    if board:
        print(f'✓ Board 689 exists')
        print(f'  Title: {board.title}')
        print(f'  Type: {board.type}')
        print(f'  metadata_json: {board.metadata_json}')
        print(f'  Description (via property): "{board.description}"')
        print()
        print('✓ The description property is working correctly!')
    else:
        print('Board 689 not found in database')
