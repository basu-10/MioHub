

def align_delimiter(text, delimiter=";"):
    lines = text.strip().split("\n")

    # Find the position of the delimiter in each line
    positions = [line.index(delimiter) for line in lines if delimiter in line]
    max_pos = max(positions)

    aligned_lines = []
    for line in lines:
        if delimiter in line:
            left, right = line.split(delimiter, 1)
            # Pad the left part so all delimiters align
            padded_left = left.rstrip().ljust(max_pos)
            aligned_lines.append(f"{padded_left} {delimiter} {right.strip()}")
        else:
            aligned_lines.append(line)

    return "\n".join(aligned_lines)


# Example usage
text = """
Find Maximum Delimiters: First scans all lines to find the maximum number of delimiters present in any row
Calculate Column Count: numColumns = maxDelimiterCount + 1
Handle Irregular Rows: Each row is split by the delimiter and then padded with empty strings to match numColumns
Max Word Length Per Column: Iterates through ALL rows for each column position to find the longest word in that column
Proper Padding: Each cell is padded to match its column's max width
"""
delimiter = input("Enter the delimiter to align by (default is ':'): ") or ":"
print(align_delimiter(text, delimiter=delimiter))


"""
input:
User → has many Folders, Notes, Boards
Folder → can have a parent_id (self-reference. value of id is again set at parent_id column)
Each Folder → can have many child folders
SharedNote → links a Note to another User"""

'''
output:
User         → has many Folders, Notes, Boards
Folder       → can have a parent_id (self-reference. value of id is again set at parent_id column)
Each Folder  → can have many child folders
SharedNote   → links a Note to another User
'''



'''
input:
Find Maximum Delimiters: First scans all lines to find the maximum number of delimiters present in any row
Calculate Column Count: numColumns = maxDelimiterCount + 1
Handle Irregular Rows: Each row is split by the delimiter and then padded with empty strings to match numColumns
Max Word Length Per Column: Iterates through ALL rows for each column position to find the longest word in that column
Proper Padding: Each cell is padded to match its column's max width
'''

'''
output:
Find Maximum Delimiters    : First scans all lines to find the maximum number of delimiters present in any row
Calculate Column Count     : numColumns = maxDelimiterCount + 1
Handle Irregular Rows      : Each row is split by the delimiter and then padded with empty strings to match numColumns
Max Word Length Per Column : Iterates through ALL rows for each column position to find the longest word in that column
Proper Padding             : Each cell is padded to match its column's max width
'''