"""
Test script to verify auto-save, unsaved changes warning, and undo history limit implementation.
Run with: python test_whiteboard_improvements.py
"""

def test_template_changes():
    """Verify template file has all improvements."""
    template_path = "blueprints/p2/templates/p2/mioboard_v4.html"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    print("=== Testing Template Changes ===\n")
    
    # Test 1: Check for MAX_UNDO_HISTORY constant
    if "MAX_UNDO_HISTORY = 50" in content:
        print("✅ MAX_UNDO_HISTORY constant defined (50 actions)")
    else:
        print("❌ MAX_UNDO_HISTORY constant NOT found")
        return False
    
    # Test 2: Check for dirty state tracking variables
    if "hasUnsavedChanges = false" in content:
        print("✅ hasUnsavedChanges variable initialized")
    else:
        print("❌ hasUnsavedChanges variable NOT found")
        return False
    
    if "autoSaveTimer = null" in content:
        print("✅ autoSaveTimer variable initialized")
    else:
        print("❌ autoSaveTimer variable NOT found")
        return False
    
    if "isSaving = false" in content:
        print("✅ isSaving variable initialized")
    else:
        print("❌ isSaving variable NOT found")
        return False
    
    # Test 3: Check for auto-save implementation
    if "AUTO-SAVE IMPLEMENTATION" in content:
        print("✅ Auto-save implementation section found")
    else:
        print("❌ Auto-save implementation section NOT found")
        return False
    
    if "function startAutoSave()" in content:
        print("✅ startAutoSave() function defined")
    else:
        print("❌ startAutoSave() function NOT found")
        return False
    
    if "45000" in content and "45 seconds" in content:
        print("✅ Auto-save interval set to 45 seconds")
    else:
        print("❌ Auto-save interval NOT properly configured")
        return False
    
    # Test 4: Check for unsaved changes warning
    if "UNSAVED CHANGES WARNING" in content:
        print("✅ Unsaved changes warning section found")
    else:
        print("❌ Unsaved changes warning section NOT found")
        return False
    
    if "beforeunload" in content:
        print("✅ beforeunload event listener added")
    else:
        print("❌ beforeunload event listener NOT found")
        return False
    
    # Test 5: Check for undo history limit enforcement
    if "UNDO HISTORY LIMIT ENFORCEMENT" in content:
        print("✅ Undo history limit enforcement section found")
    else:
        print("❌ Undo history limit enforcement section NOT found")
        return False
    
    if "originalSaveCurrentPageState" in content:
        print("✅ saveCurrentPageState wrapped for history limit")
    else:
        print("❌ saveCurrentPageState wrapper NOT found")
        return False
    
    # Test 6: Check documentation fix
    if "Automatically saves every 45 seconds when changes detected" in content:
        print("✅ Documentation updated with accurate auto-save description")
    else:
        print("❌ Documentation NOT updated correctly")
        return False
    
    if "Unsaved Changes:" in content and "Warning before leaving page" in content:
        print("✅ Documentation includes unsaved changes warning")
    else:
        print("❌ Documentation missing unsaved changes warning description")
        return False
    
    return True

def test_commands_module():
    """Verify commands.js module has undo history limits."""
    commands_path = "blueprints/p2/static/js/whiteboard_commands.js"
    
    with open(commands_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    print("\n=== Testing Commands Module Changes ===\n")
    
    # Test 1: Check executeCommand has history limit
    if "window.MAX_UNDO_HISTORY || 50" in content:
        print("✅ executeCommand enforces MAX_UNDO_HISTORY (default 50)")
    else:
        print("❌ executeCommand does NOT enforce history limit")
        return False
    
    if "window.undoStack.shift()" in content:
        print("✅ executeCommand removes oldest action when limit exceeded")
    else:
        print("❌ executeCommand does NOT remove old actions")
        return False
    
    # Test 2: Check executeCommand marks dirty state
    if "window.hasUnsavedChanges = true" in content:
        print("✅ executeCommand marks hasUnsavedChanges = true")
    else:
        print("❌ executeCommand does NOT mark dirty state")
        return False
    
    # Test 3: Check commitAppliedChange has same features
    execute_count = content.count("window.MAX_UNDO_HISTORY || 50")
    if execute_count >= 2:
        print("✅ commitAppliedChange also enforces MAX_UNDO_HISTORY")
    else:
        print("❌ commitAppliedChange missing history limit enforcement")
        return False
    
    dirty_count = content.count("window.hasUnsavedChanges = true")
    if dirty_count >= 2:
        print("✅ commitAppliedChange also marks dirty state")
    else:
        print("❌ commitAppliedChange missing dirty state tracking")
        return False
    
    return True

def test_feature_counts():
    """Count occurrences of key features."""
    template_path = "blueprints/p2/templates/p2/mioboard_v4.html"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    print("\n=== Feature Occurrence Counts ===\n")
    
    features = {
        "MAX_UNDO_HISTORY": content.count("MAX_UNDO_HISTORY"),
        "hasUnsavedChanges": content.count("hasUnsavedChanges"),
        "autoSaveTimer": content.count("autoSaveTimer"),
        "startAutoSave": content.count("startAutoSave"),
        "stopAutoSave": content.count("stopAutoSave"),
        "beforeunload": content.count("beforeunload"),
        "originalSaveCurrentPageState": content.count("originalSaveCurrentPageState"),
        "45000": content.count("45000"),
        "[AUTO-SAVE]": content.count("[AUTO-SAVE]"),
        "[UNDO-LIMIT]": content.count("[UNDO-LIMIT]")
    }
    
    for feature, count in features.items():
        status = "✅" if count > 0 else "❌"
        print(f"{status} {feature}: {count} occurrence(s)")
    
    return all(count > 0 for count in features.values())

if __name__ == '__main__':
    print("=" * 70)
    print("WHITEBOARD IMPROVEMENTS VERIFICATION TEST")
    print("=" * 70)
    print()
    
    try:
        template_ok = test_template_changes()
        commands_ok = test_commands_module()
        counts_ok = test_feature_counts()
        
        print("\n" + "=" * 70)
        if template_ok and commands_ok and counts_ok:
            print("✅ ALL TESTS PASSED - All improvements successfully implemented!")
            print("=" * 70)
            print("\nImplemented Features:")
            print("  ✅ Auto-save every 45 seconds when changes detected")
            print("  ✅ Unsaved changes warning before page unload")
            print("  ✅ Undo history limit (max 50 actions per page)")
            print("  ✅ Documentation updated with accurate descriptions")
            print("  ✅ Dirty state tracking on all command executions")
            exit(0)
        else:
            print("❌ SOME TESTS FAILED - Please review the output above")
            print("=" * 70)
            exit(1)
    except FileNotFoundError as e:
        print(f"❌ Error: Could not find file - {e}")
        exit(1)
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
        exit(1)
