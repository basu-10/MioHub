"""
Test script to verify todo file editing works correctly.
Run after starting Flask server.
"""
import json

# Test data structure
frontend_sends = {'items': [
    {'id': 1, 'text': 'Task 1', 'completed': False},
    {'id': 2, 'text': 'Task 2', 'completed': True}
]}

# Simulate what backend does now
content_str = json.dumps(frontend_sends)
print("Frontend sends:", content_str)

# Backend processing
content_data = json.loads(content_str)
print("Backend receives:", content_data)

if isinstance(content_data, dict) and 'items' in content_data:
    result = content_data
    print("✓ Correctly recognized as dict with items")
elif isinstance(content_data, list):
    result = {'items': content_data}
    print("✓ Wrapped list in items object")
else:
    result = {'items': []}
    print("✗ Fallback to empty items")

print("Stored in DB:", result)
print("\nOn next page load:")
print("todoItems =", json.dumps(result['items']))
