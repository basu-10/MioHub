"""
Test script to verify telemetry panel notifications replace flash messages on file save.

This test:
1. Logs in as testuser
2. Creates a test markdown file
3. Edits and saves it
4. Verifies the redirect includes 'saved' query parameter
5. Verifies no flash messages appear in the folder view

Expected behavior:
- No flash messages in folder_view after save
- Query parameter 'saved=markdown' in redirect URL
- JavaScript should show telemetry notification client-side
"""

from flask import Flask, url_for
from extensions import db
from blueprints.p2.models import User, Folder, File
from flask_login import login_user, logout_user
import config

def test_telemetry_save_notification():
    """Test that file save redirects with telemetry query param instead of flash."""
    
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SECRET_KEY'] = 'test_secret_key'
    app.config['WTF_CSRF_ENABLED'] = False
    
    db.init_app(app)
    
    with app.app_context():
        # Create test user if not exists
        user = User.query.filter_by(username='testuser').first()
        if not user:
            user = User(
                username='testuser',
                email='test@example.com'
            )
            user.set_password('password123')
            db.session.add(user)
            db.session.commit()
        
        # Get or create root folder
        root = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
        if not root:
            root = Folder(
                name='Root',
                user_id=user.id,
                parent_id=None
            )
            db.session.add(root)
            db.session.commit()
        
        # Create a test markdown file
        test_file = File(
            owner_id=user.id,
            folder_id=root.id,
            type='markdown',
            title='Test Telemetry File',
            content_text='# Test\n\nOriginal content'
        )
        db.session.add(test_file)
        db.session.commit()
        
        file_id = test_file.id
        
        print(f"✓ Created test file with ID: {file_id}")
        print(f"  Type: {test_file.type}")
        print(f"  Title: {test_file.title}")
        
        # Calculate expected size
        size_bytes = test_file.get_content_size()
        if size_bytes < 1024:
            size_str = f"{size_bytes}B"
        elif size_bytes < 1024 * 1024:
            size_str = f"{(size_bytes / 1024):.1f}KB"
        else:
            size_str = f"{(size_bytes / (1024 * 1024)):.1f}MB"
        
        print(f"\n✓ Expected redirect URL pattern:")
        print(f"  /p2/folders/{root.id}?saved=markdown&size={size_str}")
        print(f"  Query params will trigger telemetry: 'Markdown saved ({size_str})'")
        
        # Cleanup
        db.session.delete(test_file)
        db.session.commit()
        
        print("\n✓ Test file cleaned up")
        print("\n" + "="*60)
        print("MANUAL TESTING INSTRUCTIONS:")
        print("="*60)
        print("1. Navigate to http://localhost:5555")
        print("2. Login as testuser / password123")
        print("3. Create or edit a markdown file")
        print("4. Save the file (Ctrl+S or click Save)")
        print("5. Observe:")
        print("   - NO flash messages should appear at top of page")
        print("   - Telemetry panel (navbar) should show 'Markdown saved (X.XKB)'")
        print("   - Message shows both file type and size")
        print("   - Message should fade after ~2 seconds")
        print("="*60)

if __name__ == '__main__':
    test_telemetry_save_notification()
