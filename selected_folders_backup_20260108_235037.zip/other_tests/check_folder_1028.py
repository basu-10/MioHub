"""
Check specific folder structure for folder ID 1028
"""
from flask import Flask
from extensions import db
from blueprints.p2.models import Folder
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
db.init_app(app)

def check_folder_structure(folder_id):
    """Check the structure of a specific folder"""
    with app.app_context():
        folder = Folder.query.get(folder_id)
        if not folder:
            print(f"❌ Folder {folder_id} not found!")
            return
        
        print(f"Checking folder ID {folder_id}: '{folder.name}'")
        print(f"Owner ID: {folder.user_id}")
        print(f"Parent ID: {folder.parent_id}")
        print()
        
        # Check children
        children = folder.children
        print(f"Direct children: {len(children)}")
        for child in children[:10]:  # Show first 10
            print(f"  - {child.id}: '{child.name}' (parent_id={child.parent_id})")
        if len(children) > 10:
            print(f"  ... and {len(children) - 10} more")
        print()
        
        # Count total descendants recursively
        def count_descendants(f, visited=None):
            if visited is None:
                visited = set()
            if f.id in visited:
                return 0  # Circular reference prevention
            visited.add(f.id)
            
            count = 0
            try:
                for child in f.children:
                    count += 1 + count_descendants(child, visited)
            except Exception as e:
                print(f"⚠️  Error counting descendants: {e}")
                return count
            return count
        
        try:
            total = count_descendants(folder)
            print(f"Total descendants: {total}")
        except RecursionError:
            print("❌ RecursionError while counting descendants!")
        
        # Check for duplicate children (same parent_id multiple times)
        child_ids = [c.id for c in children]
        if len(child_ids) != len(set(child_ids)):
            print("⚠️  WARNING: Duplicate children detected!")
        
        # Check if any child has wrong parent_id
        for child in children:
            if child.parent_id != folder.id:
                print(f"⚠️  Child {child.id} has parent_id={child.parent_id} but should be {folder.id}")

if __name__ == '__main__':
    check_folder_structure(1028)
