"""
Migrate all routes to use File model exclusively after data migration is complete.

This script updates:
1. folder_routes.py - Replace Note/Board queries with File queries
2. notes_route.py - Update all note operations to use File
3. whiteboard_routes.py - Update all board operations to use File  
4. models.py - Remove deprecated Note and Board classes

RUN ONLY AFTER:
- migrate_notes_boards_to_files.py has completed successfully
- drop_legacy_tables.py has been executed
- All data has been migrated and verified
"""

import os
import re

def backup_file(filepath):
    """Create a backup of the file before modifying"""
    backup_path = filepath + '.backup_before_file_migration'
    if os.path.exists(backup_path):
        print(f"  Backup already exists: {backup_path}")
        return
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    with open(backup_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"  ✓ Created backup: {backup_path}")

def update_folder_routes():
    """Update folder_routes.py to use File model"""
    filepath = 'blueprints/p2/folder_routes.py'
    print(f"\nUpdating {filepath}...")
    backup_file(filepath)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Update import statement
    content = re.sub(
        r'from blueprints\.p2\.models import Folder, Note, Board, File, db, User',
        'from blueprints.p2.models import Folder, File, db, User',
        content
    )
    
    # Remove all local Note/Board imports
    content = re.sub(r"from blueprints\.p2\.models import Note.*\n", "", content)
    content = re.sub(r"from blueprints\.p2\.models import Board.*\n", "", content)
    
    # Update view_folder function - replace Note/Board queries with File queries
    # This is the most complex replacement
    old_view_folder_pattern = r'notes = Note\.query\.filter_by\(folder_id=folder\.id\)\.all\(\)'
    new_view_folder = "notes = File.query.filter_by(folder_id=folder.id, owner_id=current_user.id, type='note').all()"
    content = re.sub(old_view_folder_pattern, new_view_folder, content)
    
    old_boards_pattern = r'boards = folder\.boards'
    new_boards = "boards = File.query.filter_by(folder_id=folder.id, owner_id=current_user.id, type='whiteboard').all()"
    content = re.sub(old_boards_pattern, new_boards, content)
    
    # Update send_to route - Note/Board to File
    old_note_send = r"original = Note\.query\.get\(item_id\)"
    new_note_send = "original = File.query.get(item_id)"
    content = re.sub(old_note_send, new_note_send, content)
    
    old_board_send = r"original = Board\.query\.get\(item_id\)"
    new_board_send = "original = File.query.get(item_id)"
    content = re.sub(old_board_send, new_board_send, content)
    
    # Update all Note.query references
    content = re.sub(r'Note\.query', 'File.query', content)
    
    # Update all Board.query references  
    content = re.sub(r'Board\.query', 'File.query', content)
    
    # Update model instantiation - Note(...) to File(...)
    content = re.sub(
        r'note = Note\(',
        "note = File(\n            owner_id=current_user.id,\n            type='note',",
        content
    )
    
    content = re.sub(
        r'board = Board\(',
        "board = File(\n            owner_id=current_user.id,\n            type='whiteboard',",
        content
    )
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  ✓ Updated {filepath}")

def update_notes_route():
    """Update notes_route.py to use File model"""
    filepath = 'blueprints/p2/notes_route.py'
    print(f"\nUpdating {filepath}...")
    backup_file(filepath)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Update imports
    content = re.sub(
        r'from \.models import Note, User, Folder, Board',
        'from .models import User, Folder, File',
        content
    )
    
    # Remove standalone Note/Board imports
    content = re.sub(r"from \.models import Note\n", "", content)
    content = re.sub(r"from \.models import Board\n", "", content)
    content = re.sub(r"from blueprints\.p2\.models import Note.*\n", "", content)
    content = re.sub(r"from blueprints\.p2\.models import Board.*\n", "", content)
    
    # Update all Note.query to File.query with type='note'
    content = re.sub(
        r'Note\.query\.filter_by\(id=note_id, user_id=current_user\.id\)',
        "File.query.filter_by(id=note_id, owner_id=current_user.id, type='note')",
        content
    )
    
    content = re.sub(
        r'Note\.query\.get_or_404\(note_id\)',
        'File.query.get_or_404(note_id)',
        content
    )
    
    content = re.sub(
        r'Note\.query\.filter_by\(user_id=current_user\.id\)',
        "File.query.filter_by(owner_id=current_user.id, type='note')",
        content
    )
    
    # Update Note( instantiation
    content = re.sub(
        r'note = Note\(',
        "note = File(\n        owner_id=current_user.id,\n        type='note',",
        content
    )
    
    content = re.sub(
        r'Note\(',
        "File(\n        owner_id=current_user.id,\n        type='note',",
        content
    )
    
    # Update field names: user_id -> owner_id, content -> content_html/content_text
    # This will need manual review as content storage depends on type
    content = re.sub(r'note\.user_id', 'note.owner_id', content)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  ✓ Updated {filepath}")

def update_whiteboard_routes():
    """Update whiteboard_routes.py to use File model"""
    filepath = 'blueprints/p2/whiteboard_routes.py'
    print(f"\nUpdating {filepath}...")
    backup_file(filepath)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Update imports
    content = re.sub(
        r'from blueprints\.p2\.models import Board, Folder, db',
        'from blueprints.p2.models import File, Folder, db',
        content
    )
    
    # Update all Board.query to File.query with type='whiteboard'
    content = re.sub(
        r'Board\.query\.get_or_404\(board_id\)',
        'File.query.get_or_404(board_id)',
        content
    )
    
    content = re.sub(
        r'Board\.query\.filter_by\(user_id=current_user\.id\)',
        "File.query.filter_by(owner_id=current_user.id, type='whiteboard')",
        content
    )
    
    # Update Board( instantiation
    content = re.sub(
        r'board = Board\(',
        "board = File(\n        owner_id=current_user.id,\n        type='whiteboard',",
        content
    )
    
    content = re.sub(
        r'Board\(',
        "File(\n        owner_id=current_user.id,\n        type='whiteboard',",
        content
    )
    
    # Update field names
    content = re.sub(r'board\.user_id', 'board.owner_id', content)
    content = re.sub(r'board\.content', 'board.content_json', content)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  ✓ Updated {filepath}")

def remove_deprecated_models():
    """Remove Note and Board class definitions from models.py"""
    filepath = 'blueprints/p2/models.py'
    print(f"\nRemoving deprecated models from {filepath}...")
    backup_file(filepath)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find and remove Note class definition
    note_class_pattern = r'class Note\(db\.Model\):.*?(?=\n\nclass |\nclass |\Z)'
    content = re.sub(note_class_pattern, '', content, flags=re.DOTALL)
    
    # Find and remove Board class definition
    board_class_pattern = r'class Board\(db\.Model\):.*?(?=\n\nclass |\nclass |\Z)'
    content = re.sub(board_class_pattern, '', content, flags=re.DOTALL)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  ✓ Removed Note and Board classes from {filepath}")

def main():
    print("="*80)
    print("MIGRATING ROUTES TO FILE MODEL")
    print("="*80)
    print("\nWARNING: This will modify route files and models.")
    print("Backups will be created automatically.")
    print("\nEnsure you have:")
    print("  1. Run migrate_notes_boards_to_files.py successfully")
    print("  2. Dropped legacy tables with drop_legacy_tables.py")
    print("  3. Verified all data migrated correctly")
    
    response = input("\nProceed with route migration? (yes/no): ").strip().lower()
    
    if response == 'yes':
        try:
            # Update routes in order
            update_folder_routes()
            update_notes_route()
            update_whiteboard_routes()
            
            # Remove deprecated models
            remove_deprecated_models()
            
            print("\n" + "="*80)
            print("MIGRATION COMPLETE")
            print("="*80)
            print("\nNext steps:")
            print("  1. Review the updated files carefully")
            print("  2. Check for any remaining Note/Board references:")
            print("     grep -r 'Note.query\\|Board.query' blueprints/p2/")
            print("  3. Test all CRUD operations")
            print("  4. Run pytest to verify functionality")
            print("  5. If any issues, restore from .backup_before_file_migration files")
            print("="*80 + "\n")
            
        except Exception as e:
            print(f"\n{'='*80}")
            print(f"ERROR: {str(e)}")
            print(f"{'='*80}\n")
            print("Restore from backups if needed.")
            raise
    else:
        print("\nMigration cancelled. No files were modified.")

if __name__ == '__main__':
    main()
