"""
Migration script to add the universal 'files' table.

This table supports future file types (markdown, PDFs, todos, diagrams)
while coexisting with legacy Note and Board models during transition.

Run with: python migrate_add_file_table.py
"""

from flask import Flask
from extensions import db
from sqlalchemy import text, inspect
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def table_exists(table_name):
    """Check if a table exists in the database."""
    inspector = inspect(db.engine)
    return table_name in inspector.get_table_names()

def create_files_table():
    """Create the files table with all necessary columns and indexes."""
    with app.app_context():
        if table_exists('files'):
            print("✓ Table 'files' already exists. Skipping creation.")
            return
        
        print("Creating 'files' table...")
        
        create_table_sql = text("""
            CREATE TABLE files (
                id INT AUTO_INCREMENT PRIMARY KEY,
                owner_id INT NOT NULL,
                folder_id INT DEFAULT NULL,
                type VARCHAR(20) NOT NULL,
                title VARCHAR(500) NOT NULL,
                
                content_text TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                content_html LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                content_json JSON DEFAULT NULL,
                content_blob LONGBLOB DEFAULT NULL,
                
                metadata_json JSON DEFAULT NULL,
                
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_modified DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                is_public TINYINT(1) NOT NULL DEFAULT 0,
                
                FOREIGN KEY (owner_id) REFERENCES user(id) ON DELETE CASCADE,
                FOREIGN KEY (folder_id) REFERENCES folder(id) ON DELETE CASCADE,
                
                INDEX idx_owner_id (owner_id),
                INDEX idx_folder_id (folder_id),
                INDEX idx_type (type),
                INDEX idx_created_at (created_at),
                INDEX idx_last_modified (last_modified)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        """)
        
        db.session.execute(create_table_sql)
        db.session.commit()
        
        print("✓ Table 'files' created successfully!")
        print("\nTable structure:")
        print("  - id (PK)")
        print("  - owner_id (FK → user.id)")
        print("  - folder_id (FK → folder.id, nullable)")
        print("  - type (indexed, for content type discrimination)")
        print("  - title")
        print("  - content_text (TEXT, for plain text/markdown)")
        print("  - content_html (LONGTEXT, for rich formatted content)")
        print("  - content_json (JSON, for structured data)")
        print("  - content_blob (LONGBLOB, for binary files)")
        print("  - metadata_json (JSON, for auxiliary info only)")
        print("  - created_at, last_modified (indexed)")
        print("  - is_public (for public sharing)")
        print("\nIndexes created on: owner_id, folder_id, type, created_at, last_modified")

if __name__ == '__main__':
    print("=" * 60)
    print("File Table Migration Script")
    print("=" * 60)
    
    create_files_table()
    
    print("\n" + "=" * 60)
    print("Migration completed!")
    print("=" * 60)
    print("\nNext steps:")
    print("1. Create file_routes.py for CRUD operations")
    print("2. Build unified file browser UI")
    print("3. Test creating File records via API")
    print("\nUsage examples:")
    print("  - Markdown: File(type='markdown', content_text='# Hello')")
    print("  - PDF: File(type='pdf', content_blob=binary_data)")
    print("  - Todo: File(type='todo', content_json={'items': [...]})")
