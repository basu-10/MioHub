"""
Test script to verify public file display functionality.

This script:
1. Creates a test file marked as public
2. Queries the public profile route logic
3. Verifies files are included in results
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import User, Folder, File
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_public_file_display():
    with app.app_context():
        # Find testuser
        user = User.query.filter_by(username='testuser').first()
        if not user:
            print("❌ testuser not found. Run init_db.py first.")
            return
        
        print(f"✓ Found user: {user.username} (ID: {user.id})")
        
        # Find or create a folder
        folder = Folder.query.filter_by(user_id=user.id).first()
        if not folder:
            folder = Folder(name='Test Folder', user_id=user.id)
            db.session.add(folder)
            db.session.commit()
            print(f"✓ Created folder: {folder.name} (ID: {folder.id})")
        else:
            print(f"✓ Found folder: {folder.name} (ID: {folder.id})")
        
        # Check for existing public files
        existing_files = File.query.filter_by(owner_id=user.id, is_public=True).all()
        print(f"\n📁 Existing public files: {len(existing_files)}")
        for f in existing_files:
            print(f"   - {f.title} ({f.type})")
        
        # Create a test public file if none exist
        if not existing_files:
            test_file = File(
                owner_id=user.id,
                folder_id=folder.id,
                type='markdown',
                title='Public Test Markdown',
                content_text='# Hello World\n\nThis is a public markdown file for testing.',
                metadata_json={'description': 'Test file for public profile display'},
                is_public=True
            )
            db.session.add(test_file)
            db.session.commit()
            print(f"\n✓ Created test file: {test_file.title} (ID: {test_file.id})")
        
        # Simulate the public profile query logic
        print("\n🔍 Testing public profile query logic...")
        
        # Get all public folders
        all_public_folders = Folder.query.filter_by(user_id=user.id, is_public=True).all()
        public_folder_ids = {f.id for f in all_public_folders}
        print(f"   Public folder IDs: {public_folder_ids}")
        
        # Query public files (excluding those in public folders)
        if public_folder_ids:
            public_files = File.query.filter(
                File.owner_id == user.id, 
                File.is_public == True, 
                ~File.folder_id.in_(list(public_folder_ids))
            ).all()
        else:
            public_files = File.query.filter_by(owner_id=user.id, is_public=True).all()
        
        print(f"\n✅ PUBLIC FILES QUERY RESULT: {len(public_files)} files")
        for f in public_files:
            print(f"   - ID: {f.id} | Type: {f.type} | Title: {f.title}")
            print(f"     is_public: {f.is_public} | folder_id: {f.folder_id}")
            if f.metadata_json and f.metadata_json.get('description'):
                print(f"     Description: {f.metadata_json.get('description')}")
        
        # Test URL generation (import after app context)
        from flask import url_for
        if public_files:
            test_file = public_files[0]
            with app.test_request_context():
                view_url = url_for('file.public_file', file_id=test_file.id)
                edit_url = url_for('file.edit_file', file_id=test_file.id)
                copy_url = f"/folders/public/copy/file/{test_file.id}"
                
                print(f"\n🔗 URL Testing:")
                print(f"   Public view: {view_url}")
                print(f"   Edit: {edit_url}")
                print(f"   Copy endpoint: {copy_url}")
        
        print("\n✅ Test completed successfully!")
        print(f"\n💡 Visit: http://localhost:5555/users/{user.id}")
        print(f"   You should see {len(public_files)} public file(s) displayed")

if __name__ == '__main__':
    test_public_file_display()
