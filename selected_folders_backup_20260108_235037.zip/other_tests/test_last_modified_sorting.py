"""
Test script to verify the last modified sorting functionality.
This script will create test data and verify that sorting works correctly.
"""
import os
import sys

# Add the current directory to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Flask and database imports
from flask import Flask
from extensions import db
from blueprints.p2.models import Folder, File, User
import config
from datetime import datetime, timedelta

def setup_app():
    """Set up Flask app and database configuration."""
    app = Flask(__name__)
    
    # Database configuration
    DB_NAME = config.DB_NAME
    DB_USER = config.DB_USER
    DB_PASSWORD = config.DB_PASSWORD
    DB_PORT = config.DB_PORT
    DB_HOST = config.DB_HOST
    
    app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+mysqlconnector://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    
    return app

def test_last_modified_sorting():
    """Test the last modified sorting functionality."""
    app = setup_app()
    
    with app.app_context():
        print("Testing last modified sorting functionality...")
        
        # Get a test user (assuming there's already a user in the database)
        user = User.query.first()
        if not user:
            print("❌ No users found in database. Please create a user first.")
            return
        
        print(f"Using test user: {user.username}")
        
        # Get or create a test folder
        test_folder = Folder.query.filter_by(user_id=user.id, name="Test Sorting Folder").first()
        if not test_folder:
            test_folder = Folder(
                name="Test Sorting Folder",
                user_id=user.id,
                created_at=datetime.utcnow(),
                last_modified=datetime.utcnow()
            )
            db.session.add(test_folder)
            db.session.commit()
            print("Created test folder")
        
        # Create test notes with different last_modified times
        base_time = datetime.utcnow()
        test_notes = []
        
        # Note 1 - oldest last_modified
        note1 = File(
            title="First Note (Oldest)",
            content_html="This is the first note content",
            type='note',
            owner_id=user.id,
            folder_id=test_folder.id,
            created_at=base_time - timedelta(days=3),
            last_modified=base_time - timedelta(days=2)
        )
        
        # Note 2 - newest last_modified
        note2 = File(
            title="Second Note (Newest)",
            content_html="This is the second note content",
            type='note',
            owner_id=user.id,
            folder_id=test_folder.id,
            created_at=base_time - timedelta(days=2),
            last_modified=base_time  # Most recent
        )
        
        # Note 3 - middle last_modified
        note3 = File(
            title="Third Note (Middle)",
            content_html="This is the third note content",
            type='note',
            owner_id=user.id,
            folder_id=test_folder.id,
            created_at=base_time - timedelta(days=1),
            last_modified=base_time - timedelta(hours=12)
        )
        
        # Clean up any existing test notes
        File.query.filter_by(folder_id=test_folder.id, type='note').delete()
        
        # Add new test notes
        db.session.add_all([note1, note2, note3])
        db.session.commit()
        print("Created test notes with different last_modified times")
        
        # Test sorting function
        from blueprints.p2.folder_routes import Folder as FolderModel
        
        def sort_items(items, sort_by, item_type):
            if sort_by == 'name':
                if item_type == 'folder':
                    return sorted(items, key=lambda x: x.name.lower())
                elif item_type in ['note', 'board', 'combined']:
                    return sorted(items, key=lambda x: (x.title or '').lower())
            elif sort_by == 'created':
                return sorted(items, key=lambda x: x.created_at or x.id)
            elif sort_by == 'modified':
                return sorted(items, key=lambda x: x.last_modified or x.created_at or x.id, reverse=True)
            elif sort_by == 'size':
                if item_type == 'folder':
                    # For folders, count total items (files + subfolders)
                    return sorted(items, key=lambda x: len(x.files) + len(x.children), reverse=True)
                elif item_type in ['note', 'board', 'combined']:
                    # For notes/boards, use content length
                    return sorted(items, key=lambda x: len(x.get_content() or ''), reverse=True)
            return items
        
        # Get notes and test sorting
        notes = File.query.filter_by(folder_id=test_folder.id, type='note').all()
        
        print(f"\n📊 Testing sorting with {len(notes)} notes:")
        
        # Test each sort option
        sort_options = ['name', 'created', 'modified', 'size']
        
        for sort_option in sort_options:
            sorted_notes = sort_items(notes, sort_option, 'note')
            print(f"\n🔤 Sorted by {sort_option}:")
            for i, note in enumerate(sorted_notes, 1):
                if sort_option == 'modified':
                    print(f"  {i}. {note.title} (Last Modified: {note.last_modified.strftime('%Y-%m-%d %H:%M:%S')})")
                elif sort_option == 'created':
                    print(f"  {i}. {note.title} (Created: {note.created_at.strftime('%Y-%m-%d %H:%M:%S')})")
                elif sort_option == 'name':
                    print(f"  {i}. {note.title}")
                elif sort_option == 'size':
                    print(f"  {i}. {note.title} (Size: {len(note.get_content() or '')} chars)")
        
        # Verify modified sorting is correct (newest first)
        modified_sorted = sort_items(notes, 'modified', 'note')
        if len(modified_sorted) >= 3:
            if (modified_sorted[0].title == "Second Note (Newest)" and 
                modified_sorted[1].title == "Third Note (Middle)" and 
                modified_sorted[2].title == "First Note (Oldest)"):
                print("\n✅ PASS: Last Modified sorting is working correctly!")
            else:
                print("\n❌ FAIL: Last Modified sorting is not working correctly!")
                print("Expected order: Second Note (Newest), Third Note (Middle), First Note (Oldest)")
                print(f"Actual order: {', '.join([n.title for n in modified_sorted])}")
        
        print("\n🔍 Testing completed!")

if __name__ == '__main__':
    test_last_modified_sorting()