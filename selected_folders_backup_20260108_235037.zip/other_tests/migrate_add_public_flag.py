#!/usr/bin/env python3
"""
Migration script to add `is_public` boolean column to the `boards` table.

This script will:
 - Connect to the configured database using the project's config and extensions
 - Inspect the `boards` table to see if `is_public` exists
 - If missing, ALTER TABLE to add `is_public` TINYINT(1) default 0 NOT NULL
 - Verify the column exists after the change

Usage: run this file from the project root inside the project's virtualenv.
Example:
  & ".\.venv\Scripts\Activate.ps1"; python migrate_add_public_flag.py
"""

import sys
import os
from datetime import datetime

# Put project root on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from extensions import db
import config


def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    return app


def check_column_exists(inspector, table_name, column_name):
    try:
        columns = inspector.get_columns(table_name)
        names = [c['name'] for c in columns]
        return column_name in names
    except Exception as e:
        print(f"Error checking columns for {table_name}: {e}")
        return None


def add_is_public_to_tables(tables_to_process=None):
    """Ensure `is_public` exists on specified tables and set existing rows to False (0).

    This function will:
    - Add the `is_public` column if missing (TINYINT(1) DEFAULT 0 NOT NULL)
    - For existing rows, set NULL values to 0
    - Ensure the column is NOT NULL with DEFAULT 0
    """
    if tables_to_process is None:
        # Include folder so entire folder trees can be marked public
        tables_to_process = ['boards', 'note', 'folder']

    try:
        inspector = db.inspect(db.engine)
        all_tables = inspector.get_table_names()

        for table_name in tables_to_process:
            column_name = 'is_public'
            print(f"\n→ Processing table: {table_name}")

            if table_name not in all_tables:
                print(f"  Table '{table_name}' does not exist - skipping")
                continue

            exists = check_column_exists(inspector, table_name, column_name)
            if exists is None:
                print(f"  Could not determine if column exists on {table_name}. Skipping.")
                continue

            with db.engine.connect() as conn:
                if not exists:
                    print(f"  Adding column '{column_name}' to '{table_name}'...")
                    # Add as TINYINT(1) with default 0; allow null temporarily to avoid issues on some MySQL setups
                    conn.execute(db.text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} TINYINT(1) DEFAULT 0"))
                    conn.commit()
                else:
                    print(f"  Column '{column_name}' already exists on '{table_name}'. Ensuring defaults and nulls fixed...")

                # Set any NULL values to 0 for existing rows
                print(f"  Setting existing NULL {column_name} values to 0 for '{table_name}'...")
                conn.execute(db.text(f"UPDATE {table_name} SET {column_name} = 0 WHERE {column_name} IS NULL"))
                conn.commit()

                # Ensure column is NOT NULL with DEFAULT 0
                try:
                    print(f"  Altering column to NOT NULL DEFAULT 0 on '{table_name}'...")
                    conn.execute(db.text(f"ALTER TABLE {table_name} MODIFY COLUMN {column_name} TINYINT(1) NOT NULL DEFAULT 0"))
                    conn.commit()
                except Exception as e:
                    print(f"  Warning: could not MODIFY column for '{table_name}' - {e}")

            # re-inspect for the next iteration
            inspector = db.inspect(db.engine)

        print("\nAll requested tables processed.")
        return True

    except Exception as e:
        print(f"Error while processing tables: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    print("""\nADD is_public MIGRATION\n""")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    app = create_app()
    with app.app_context():
        success = add_is_public_to_tables()

    print("\nMigration result:", "SUCCESS" if success else "FAILED")
    print(f"Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    return 0 if success else 1


if __name__ == '__main__':
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\nMigration interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)
