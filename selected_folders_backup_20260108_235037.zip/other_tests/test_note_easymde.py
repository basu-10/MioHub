"""
Test script to verify note file type uses EasyMDE with JSON storage.
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, Folder, User
import config
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

with app.app_context():
    # Get test user
    user = User.query.filter_by(username='testuser').first()
    if not user:
        print("❌ Test user not found. Run init_db.py first.")
        exit(1)
    
    print(f"✓ Found test user: {user.username} (ID: {user.id})")
    
    # Get user's root folder
    root_folder = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
    if not root_folder:
        print("❌ Root folder not found")
        exit(1)
    
    print(f"✓ Found root folder: {root_folder.name} (ID: {root_folder.id})")
    
    # Create a test note with markdown content
    test_note = File(
        owner_id=user.id,
        folder_id=root_folder.id,
        type='note',
        title='Test EasyMDE Note',
        is_public=False,
        metadata_json={'description': 'Testing markdown note with JSON storage'},
        content_json={
            'markdown': '# Hello World\n\nThis is a **test note** with:\n\n- Bullet points\n- More items\n\n## Code Example\n\n```python\ndef hello():\n    print("Hello, World!")\n```\n\nAnd a [link](https://example.com).',
            'created_at': '2025-11-19T12:00:00'
        }
    )
    
    try:
        db.session.add(test_note)
        db.session.commit()
        print(f"✓ Created test note with ID: {test_note.id}")
        
        # Verify the content
        saved_note = File.query.get(test_note.id)
        print(f"\n✓ Note verification:")
        print(f"  - Title: {saved_note.title}")
        print(f"  - Type: {saved_note.type}")
        print(f"  - Storage column: content_json")
        print(f"  - Has markdown: {bool(saved_note.content_json.get('markdown'))}")
        print(f"  - Content size: {saved_note.get_content_size()} bytes")
        
        # Show first 200 chars of markdown
        markdown = saved_note.content_json.get('markdown', '')
        print(f"\n  Markdown preview (first 200 chars):")
        print(f"  {markdown[:200]}...")
        
        print(f"\n✓ SUCCESS! Note file type now uses EasyMDE with JSON storage.")
        print(f"\nTo view in browser:")
        print(f"  - Edit: http://localhost:5555/p2/files/{test_note.id}/edit")
        print(f"  - View: http://localhost:5555/p2/files/{test_note.id}/view")
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Error creating note: {e}")
        exit(1)
