"""
Test script for Blocks file type implementation.

Tests:
1. Creating a new blocks document
2. Editing blocks document
3. Viewing blocks document
4. File routes handling
"""

from flask import Flask
from extensions import db
from blueprints.p2.models import File, User, Folder
from datetime import datetime
import json

def test_blocks_implementation():
    """Test the blocks file type implementation."""
    
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:mysql@localhost:3306/mioword_db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    with app.app_context():
        print("=" * 60)
        print("Testing Blocks File Type Implementation")
        print("=" * 60)
        
        # Test 1: Check if we can create a blocks file
        print("\n[Test 1] Creating a test blocks file...")
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            print("❌ Test user not found. Run init_db.py first.")
            return
        
        test_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
        if not test_folder:
            print("❌ Test folder not found.")
            return
        
        # Create a sample Editor.js content structure
        sample_content = {
            "time": int(datetime.utcnow().timestamp() * 1000),
            "blocks": [
                {
                    "type": "header",
                    "data": {
                        "text": "Welcome to Blocks Editor",
                        "level": 1
                    }
                },
                {
                    "type": "paragraph",
                    "data": {
                        "text": "This is a feature-rich block-based editor powered by Editor.js."
                    }
                },
                {
                    "type": "list",
                    "data": {
                        "style": "unordered",
                        "items": [
                            "Rich text editing",
                            "Multiple block types",
                            "Tables and checklists",
                            "Code blocks and quotes"
                        ]
                    }
                },
                {
                    "type": "checklist",
                    "data": {
                        "items": [
                            {
                                "text": "Create blocks document",
                                "checked": True
                            },
                            {
                                "text": "Add content",
                                "checked": False
                            },
                            {
                                "text": "Save and view",
                                "checked": False
                            }
                        ]
                    }
                },
                {
                    "type": "code",
                    "data": {
                        "code": "console.log('Hello from Blocks!');"
                    }
                },
                {
                    "type": "quote",
                    "data": {
                        "text": "A powerful block-based editor for modern content creation.",
                        "caption": "MioSpace Team"
                    }
                }
            ],
            "version": "2.28.0"
        }
        
        blocks_file = File(
            owner_id=test_user.id,
            folder_id=test_folder.id,
            type='blocks',
            title='Test Blocks Document',
            content_json=sample_content,
            metadata_json={'description': 'A test blocks document with various block types'},
            is_public=False
        )
        
        try:
            db.session.add(blocks_file)
            db.session.commit()
            print(f"✅ Created blocks file with ID: {blocks_file.id}")
            print(f"   Title: {blocks_file.title}")
            print(f"   Type: {blocks_file.type}")
            print(f"   Blocks count: {len(blocks_file.content_json.get('blocks', []))}")
        except Exception as e:
            db.session.rollback()
            print(f"❌ Failed to create blocks file: {e}")
            return
        
        # Test 2: Verify content retrieval
        print("\n[Test 2] Verifying content retrieval...")
        retrieved_file = File.query.filter_by(id=blocks_file.id).first()
        if retrieved_file and retrieved_file.content_json:
            content = retrieved_file.get_content()
            if isinstance(content, dict) and 'blocks' in content:
                print(f"✅ Content retrieved successfully")
                print(f"   Version: {content.get('version')}")
                print(f"   Blocks: {len(content.get('blocks', []))}")
                
                # List block types
                block_types = [block.get('type') for block in content.get('blocks', [])]
                print(f"   Block types: {', '.join(block_types)}")
            else:
                print("❌ Content format invalid")
        else:
            print("❌ Failed to retrieve file")
        
        # Test 3: Check content size calculation
        print("\n[Test 3] Testing content size calculation...")
        content_size = blocks_file.get_content_size()
        print(f"✅ Content size: {content_size} bytes ({content_size / 1024:.2f} KB)")
        
        # Test 4: Test metadata
        print("\n[Test 4] Testing metadata storage...")
        if blocks_file.metadata_json:
            print(f"✅ Metadata: {blocks_file.metadata_json}")
        else:
            print("⚠️  No metadata stored")
        
        # Test 5: Query all blocks files
        print("\n[Test 5] Querying all blocks files...")
        all_blocks = File.query.filter_by(type='blocks').all()
        print(f"✅ Found {len(all_blocks)} blocks document(s)")
        for bf in all_blocks:
            print(f"   - {bf.title} (ID: {bf.id}, Owner: {bf.owner.username})")
        
        # Test 6: Test update operation
        print("\n[Test 6] Testing update operation...")
        blocks_file.title = "Updated Blocks Document"
        blocks_file.content_json['blocks'].append({
            "type": "paragraph",
            "data": {
                "text": "This block was added via update test."
            }
        })
        from sqlalchemy.orm.attributes import flag_modified
        flag_modified(blocks_file, 'content_json')
        
        try:
            db.session.commit()
            print(f"✅ Updated blocks file")
            print(f"   New title: {blocks_file.title}")
            print(f"   New block count: {len(blocks_file.content_json.get('blocks', []))}")
        except Exception as e:
            db.session.rollback()
            print(f"❌ Update failed: {e}")
        
        # Test 7: Test deletion
        print("\n[Test 7] Testing deletion...")
        file_id = blocks_file.id
        try:
            db.session.delete(blocks_file)
            db.session.commit()
            print(f"✅ Deleted blocks file (ID: {file_id})")
            
            # Verify deletion
            check = File.query.filter_by(id=file_id).first()
            if check is None:
                print("✅ Deletion verified")
            else:
                print("❌ File still exists after deletion")
        except Exception as e:
            db.session.rollback()
            print(f"❌ Deletion failed: {e}")
        
        print("\n" + "=" * 60)
        print("Blocks Implementation Tests Complete")
        print("=" * 60)

if __name__ == '__main__':
    test_blocks_implementation()
