"""
Test script to verify public badge display and AJAX toggle functionality.
This script checks:
1. Badge container is always present in folder_view.html
2. Public badge appears correctly inside badge-container
3. AJAX toggle updates badge properly
"""

import re

def check_badge_containers():
    """Check that all item cards have badge-container"""
    
    with open('blueprints/p2/templates/p2/folder_view.html', 'r', encoding='utf-8') as f:
        content = f.read()
    
    issues = []
    
    # Pattern to find item cards
    item_card_pattern = r'<div class="card[^>]*item-card[^>]*data-type="(folder|note|board|book|file)"[^>]*data-id="[^"]*"[^>]*>'
    
    matches = list(re.finditer(item_card_pattern, content))
    print(f"Found {len(matches)} item cards")
    
    for match in matches:
        item_type = match.group(1)
        start_pos = match.end()
        
        # Check if badge-container appears within the next 300 characters
        next_section = content[start_pos:start_pos+500]
        
        # For files, badge-container should always be present
        # For folders/notes/boards/books, it should now always be present too (after our fix)
        if '<div class="badge-container">' not in next_section:
            context = content[match.start():start_pos+200]
            issues.append(f"Missing badge-container for {item_type}: {context[:150]}...")
    
    if issues:
        print("\n❌ ISSUES FOUND:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("✅ All item cards have badge-container")
        return True


def check_action_bar_ajax():
    """Check that action bar uses AJAX for public toggle"""
    
    with open('blueprints/p2/templates/p2/folder_view_action_bar_partial.html', 'r', encoding='utf-8') as f:
        content = f.read()
    
    issues = []
    
    # Check for AJAX fetch call
    if 'fetch(\'/folders/set_public\'' not in content:
        issues.append("Missing AJAX fetch call to /folders/set_public")
    
    # Check for telemetry integration
    if 'window.TelemetryPanel' not in content:
        issues.append("Missing telemetry panel integration")
    
    if 'setActive' not in content:
        issues.append("Missing setActive call for telemetry")
    
    if 'setIdle' not in content:
        issues.append("Missing setIdle call for telemetry")
    
    # Check for proper badge update logic
    if 'toggleBadgeOnCard' not in content:
        issues.append("Missing toggleBadgeOnCard function")
    
    if 'badge-container' not in content:
        issues.append("Missing badge-container handling in JS")
    
    if issues:
        print("\n❌ ACTION BAR ISSUES:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("✅ Action bar properly implements AJAX toggle with telemetry")
        return True


def main():
    print("=" * 60)
    print("Public Badge Fix Verification")
    print("=" * 60)
    
    print("\n1. Checking badge containers in folder_view.html...")
    badge_ok = check_badge_containers()
    
    print("\n2. Checking AJAX implementation in action bar...")
    ajax_ok = check_action_bar_ajax()
    
    print("\n" + "=" * 60)
    if badge_ok and ajax_ok:
        print("✅ ALL CHECKS PASSED!")
        print("\nThe public badge should now:")
        print("  - Display as a circle badge in the top-right corner")
        print("  - Toggle via AJAX without page reload")
        print("  - Show notifications in telemetry panel")
        print("  - Update instantly when clicked")
    else:
        print("❌ SOME CHECKS FAILED")
        print("Review the issues above and fix them.")
    print("=" * 60)


if __name__ == '__main__':
    main()
