#!/usr/bin/env python3
"""
Standalone migration script to add last_modified columns to all relevant tables.
This script will:
1. Check which tables need the last_modified column
2. Add the column if it doesn't exist
3. Set default values (created_at or current time) for existing entries

Tables to update:
- folder (set to created_at if available, else current time)
- note (set to created_at if available, else current time)
- boards (set to created_at if available, else current time)
- chat_sessions (uses updated_at instead of last_modified)
"""

import sys
import os
from datetime import datetime

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from extensions import db
import config

def create_app():
    """Create Flask app for migration."""
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    db.init_app(app)
    return app

def check_column_exists(inspector, table_name, column_name):
    """Check if a column exists in a table."""
    try:
        columns = inspector.get_columns(table_name)
        column_names = [col['name'] for col in columns]
        return column_name in column_names
    except Exception as e:
        print(f"⚠️  Error checking table {table_name}: {e}")
        return None

def add_last_modified_column(table_name, has_created_at=True):
    """Add last_modified column to a table and populate it with default values."""
    print(f"\n→ Processing table: {table_name}")
    
    try:
        with db.engine.connect() as conn:
            # Add the column
            print(f"  Adding last_modified column...")
            conn.execute(db.text(f"ALTER TABLE {table_name} ADD COLUMN last_modified DATETIME"))
            conn.commit()
            
            # Populate with default values
            if has_created_at:
                print(f"  Setting last_modified = created_at for existing entries...")
                conn.execute(db.text(f"UPDATE {table_name} SET last_modified = created_at WHERE last_modified IS NULL"))
            else:
                print(f"  Setting last_modified = NOW() for existing entries...")
                conn.execute(db.text(f"UPDATE {table_name} SET last_modified = NOW() WHERE last_modified IS NULL"))
            
            conn.commit()
            print(f"  ✅ {table_name} updated successfully")
            return True
    except Exception as e:
        print(f"  ❌ Error updating {table_name}: {e}")
        return False

def add_updated_at_column(table_name):
    """Add updated_at column to a table (for chat_sessions)."""
    print(f"\n→ Processing table: {table_name}")
    
    try:
        with db.engine.connect() as conn:
            # Add the column
            print(f"  Adding updated_at column...")
            conn.execute(db.text(f"ALTER TABLE {table_name} ADD COLUMN updated_at DATETIME"))
            conn.commit()
            
            # Set to created_at for existing entries
            print(f"  Setting updated_at = created_at for existing entries...")
            conn.execute(db.text(f"UPDATE {table_name} SET updated_at = created_at WHERE updated_at IS NULL"))
            
            conn.commit()
            print(f"  ✅ {table_name} updated successfully")
            return True
    except Exception as e:
        print(f"  ❌ Error updating {table_name}: {e}")
        return False

def add_last_modified_columns():
    """Add last_modified columns to all relevant tables."""
    try:
        inspector = db.inspect(db.engine)
        all_tables = inspector.get_table_names()
        
        print("=" * 60)
        print("DATABASE INFORMATION")
        print("=" * 60)
        print(f"Database: {config.DB_NAME}")
        print(f"Found {len(all_tables)} tables: {', '.join(all_tables)}")
        
        # Define tables that need last_modified column
        tables_to_check = [
            ('folder', True),      # has created_at
            ('note', True),        # has created_at
            ('boards', True),      # has created_at
        ]
        
        print("\n" + "=" * 60)
        print("CHECKING TABLES FOR MIGRATION")
        print("=" * 60)
        
        migration_needed = []
        migration_skipped = []
        migration_successful = []
        migration_failed = []
        
        # Check each table
        for table_name, has_created_at in tables_to_check:
            # Check if table exists
            if table_name not in all_tables:
                print(f"\n⚠️  Table '{table_name}' does not exist - skipping")
                migration_skipped.append(f"{table_name} (table doesn't exist)")
                continue
            
            # Check if column exists
            has_last_modified = check_column_exists(inspector, table_name, 'last_modified')
            
            if has_last_modified is None:
                print(f"\n❌ Error checking table '{table_name}' - skipping")
                migration_skipped.append(f"{table_name} (error checking)")
                continue
            
            if has_last_modified:
                print(f"\n✓ Table '{table_name}' already has last_modified column")
                migration_skipped.append(f"{table_name} (already has column)")
            else:
                print(f"\n! Table '{table_name}' needs last_modified column")
                migration_needed.append((table_name, has_created_at))
        
        # Special check for chat_sessions (uses updated_at instead of last_modified)
        if 'chat_sessions' in all_tables:
            has_updated_at = check_column_exists(inspector, 'chat_sessions', 'updated_at')
            if has_updated_at is False:
                print(f"\n! Table 'chat_sessions' needs updated_at column")
                migration_needed.append(('chat_sessions', 'updated_at'))
            else:
                print(f"\n✓ Table 'chat_sessions' already has updated_at column")
                migration_skipped.append("chat_sessions (already has updated_at)")
        
        # Perform migrations
        if migration_needed:
            print("\n" + "=" * 60)
            print(f"PERFORMING MIGRATIONS ({len(migration_needed)} tables)")
            print("=" * 60)
            
            for item in migration_needed:
                if len(item) == 2 and item[1] == 'updated_at':
                    # Special case for chat_sessions
                    success = add_updated_at_column(item[0])
                    if success:
                        migration_successful.append(f"{item[0]} (updated_at)")
                    else:
                        migration_failed.append(f"{item[0]} (updated_at)")
                else:
                    table_name, has_created_at = item
                    success = add_last_modified_column(table_name, has_created_at)
                    if success:
                        migration_successful.append(table_name)
                    else:
                        migration_failed.append(table_name)
            
            # Verify the changes
            print("\n" + "=" * 60)
            print("VERIFICATION")
            print("=" * 60)
            
            for table_name, _ in tables_to_check:
                if table_name in migration_successful or table_name in [s.split()[0] for s in migration_skipped if 'already has' in s]:
                    try:
                        with db.engine.connect() as conn:
                            result = conn.execute(db.text(f"SELECT COUNT(*) FROM {table_name}"))
                            row = result.fetchone()
                            total_count = row[0] if row else 0
                            
                            result = conn.execute(db.text(f"SELECT COUNT(*) FROM {table_name} WHERE last_modified IS NOT NULL"))
                            row = result.fetchone()
                            with_last_modified = row[0] if row else 0
                            
                            status = "✓" if total_count == with_last_modified else "⚠"
                            print(f"{status} {table_name}: {with_last_modified}/{total_count} records with last_modified")
                    except Exception as e:
                        print(f"⚠️  Error verifying {table_name}: {e}")
            
            return len(migration_failed) == 0
        else:
            print("\n" + "=" * 60)
            print("NO MIGRATION NEEDED")
            print("=" * 60)
            print("All tables already have the required columns.")
            return True
            
    except Exception as e:
        print(f"\n❌ Error during migration: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main migration function."""
    print("=" * 60)
    print("LAST_MODIFIED COLUMN MIGRATION SCRIPT")
    print("=" * 60)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    app = create_app()
    
    with app.app_context():
        success = add_last_modified_columns()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ MIGRATION COMPLETED SUCCESSFULLY!")
    else:
        print("❌ MIGRATION FAILED!")
        print("Please check the error messages above for details.")
    print("=" * 60)
    print(f"Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return 0 if success else 1

if __name__ == '__main__':
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n❌ Migration interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)