# Copilot Quick Card — MioHub (1 page)

Purpose: Single-page printable reference for AI coding agents working in this repo.

Quick commands
- Bootstrap environment: start_project.bat
- Seed DB: python init_db.py  (creates `testuser`/`admin`)
- Run dev server: python flask_app.py  (0.0.0.0:5555)
- Run tests: pytest  (unit: tests/unit/, integration: tests/integration/)

Critical patterns & gotchas
- File model (p2): use blueprints/p2/models.py: File stores content in exactly one of:
  - content_text | content_html | content_json | content_blob
  - Use file.get_content(), file.get_content_size(), and file.description (do not read metadata_json directly)
- JSON fields: after mutating (user_prefs, metadata_json, content_json), call:

```python
from sqlalchemy.orm.attributes import flag_modified
flag_modified(obj, 'field_name')
db.session.commit()
```

- Migrations: ad-hoc scripts in other_tests/migrate_*.py. ALWAYS check column existence before ALTER. Do NOT drop tables/columns.
- HTMX: uses out-of-band swaps (hx-swap-oob). Reattach listeners after swaps (see window.attachCardClickListeners).
- Image dedupe: use blueprints/p2/utils.py helpers and update User.total_data_size via utilities_main.update_user_data_size.

When adding things
- New blueprint: import it and append to bps in blueprints/__init__.py (missing registration => 404).
- New top-level route or feature: add tests (unit/integration) and update .DOCS/reference/ with concise notes.

Minimal PR checklist
- Run pytest and ensure tests pass
- Add tests for new behavior when feasible
- Add a safe migration script (if needed) in project root following other_tests examples
- Update .DOCS/reference/ and this quick-card if behavior changes

Key files to inspect
- flask_app.py, config.py, providers.py, extensions.py
- blueprints/p2/models.py, blueprints/p2/utils.py, blueprints/p2/folder_routes.py
- other_tests/migrate_*.py, tests/, .DOCS/reference/

