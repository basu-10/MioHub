---
applyTo: '*'
---
We need modular approch and testable code. Please follow the SOLID principles and ensure that each function or class has a single responsibility. Write unit tests for all new features and ensure existing tests pass before making changes.

When generating code, consider performance implications and strive for efficient algorithms and data structures. Avoid premature optimization but be mindful of scalability.

Ensure that all code changes are backward compatible unless explicitly stated otherwise. 
If breaking changes are necessary, document them clearly and provide migration instructions.

Do not delete/drop tables. Maintain a clear state and validate changes against data already created by devs posing as users.

Documentations to have:
- brief summary of what it does
- techincal summary of user action/beahiour to functions calls/logic/architectural decisions
- examples of usage
- edge cases and error handling
- any performance considerations
- DO NOT INCLUDE CODE IN DOCUMENTATION THAT IS ALREADY PRESENT IN THE CODEBASE. REFER TO THE CODE INSTEAD. DO NOT REPEAT YOURSELF.


for reference, this is ging to be the new names of the files that we show in the ui:

proprietary names:
MioNote - unchanged
miodraw - rename to MioPages
miobook - rename to  MioBlocks

graph workspace - rename to  MioThink
infinite whiteboard - rename to  MioInfinite
Timeline - rename to MioEvents
todo - rename to MioList

3rd Party names(no changes):
markdown
code 
table
blocks
diagram