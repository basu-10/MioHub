# MioHub (Flask) — GitHub Copilot Instructions

These instructions describe *how to work in this repo safely and consistently*.

---

## Quick Agent TL;DR ✅

- Purpose: be small & surgical; prefer backwards-compatible changes, add tests, and document in `.DOCS/reference/`.
- Quick commands:
  - Bootstrap: `start_project.bat`
  - Seed DB: `python init_db.py`
  - Run dev server: `python flask_app.py` (0.0.0.0:5555)
  - Tests: `pytest` (unit: `tests/unit/`, integration: `tests/integration/`)
- Critical gotchas:
  - File model: use `File` helpers and `file.description` (see `blueprints/p2/models.py`)
  - JSON fields: always call `flag_modified(obj, 'field')` before commit
  - Migrations are manual: use `other_tests/migrate_*.py` and **do NOT** drop tables
  - HTMX: re-attach JS listeners after out-of-band swaps; follow `window.attachCardClickListeners` pattern
  - Images: use dedupe helpers in `blueprints/p2/utils.py` and update `User.total_data_size` via `utilities_main.update_user_data_size`
- If adding a blueprint: import it and append to `bps` in `blueprints/__init__.py` (missing registration causes 404s)

- Printable quick-reference: `.github/copilot-quick-card.md` (one-page)

---

## Core Rules (Read First)

- Prefer small, surgical changes that match existing patterns.
- Keep code modular and testable (SOLID; single responsibility).
- Write unit tests for new behavior when feasible; don’t break existing tests.
- Be backward compatible unless explicitly told otherwise.
- **Database safety:** do not drop tables/columns; preserve existing dev/user data.

## Project Map

- App entrypoint: `flask_app.py` (registers blueprints from `blueprints/__init__.py:bps`).
- Configuration: `config.py` is the source of truth (incl. `get_database_uri()`).
- Extensions: `extensions.py` exposes SQLAlchemy `db` and `login_manager`.
- LLM routing: `providers.py` (`LLMClient` uses `config.PROVIDER` + `config.DEFAULT_CHAT_MODEL`).
- Products (blueprints):
  - `blueprints/p1/` calculator
  - `blueprints/p2/` MioWord files/folders + editors + whiteboards + graph
  - `blueprints/p3/` chat
  - `blueprints/p4/` graph product

## Local Workflow (Windows)

- Bootstrap venv + deps: `start_project.bat` (creates `.venv`, installs `requirements.txt`).
- Initialize DB + seed users: `python init_db.py`.
- Run dev server: `python flask_app.py` (host `0.0.0.0`, port `5555`).
- Run tests: `pytest`.

## Product 2 (p2) — Universal File Model (CRITICAL)

- Universal content model: `blueprints/p2/models.py:File`.
- One record stores content in exactly one of:
  - `content_text` | `content_html` | `content_json` | `content_blob`
- Auxiliary/UI metadata goes in `metadata_json`.
- File types are discriminated by `File.type`; see `VALID_FILE_TYPES`.
- Prefer `file.description` property instead of accessing `metadata_json['description']` directly.

### Storage / Quotas

- `User.user_type` (guest is capped) and `User.total_data_size` are used for quota enforcement.
- When adding/removing content or images, update tracked sizes via `utilities_main.update_user_data_size` (or the existing helper used in the touched flow).

### JSON Column Gotcha (SQLAlchemy)

When mutating JSON columns (e.g., `user_prefs`, `metadata_json`, `content_json`, `settings_json`), call:

```python
from sqlalchemy.orm.attributes import flag_modified
flag_modified(obj, 'field_name')
db.session.commit()
```

Without `flag_modified`, updates may silently not persist.

## HTMX + Dynamic HTML

- Folder view uses HTMX extensively, including out-of-band swaps (`hx-swap-oob`).
- If you inject/replace HTML, ensure JS listeners are reattached after swaps.
- Follow existing patterns in `blueprints/p2/static/js/clipboard_operations.js` and folder templates.

## Frontend Styling Constraints

- Use existing Tailwind + theme primitives; do not hard-code new colors, fonts, or shadows.
- Theme reference: `static/css/theme_colors_carbon_teal.css`.
- Don’t introduce new UI frameworks; keep changes consistent with existing templates.

## Migrations / Data Safety (CRITICAL)

- This repo uses ad-hoc migration scripts (see `other_tests/migrate_*.py`).
- **Do not drop tables or columns.**
- Always check existence before `ALTER TABLE`.
- Avoid destructive “cleanup” migrations; assume real data exists (including devs posing as users).

## Adding New Blueprints / Routes

- If you add a blueprint, you MUST import it and append it to `blueprints/__init__.py:bps`.
- Missing registration will cause 404s.

## Where To Look For Deep Reference

- Reference docs: `.DOCS/reference/` (whiteboard, HTMX, batch operations, graph, migrations).
- Migration examples: `other_tests/migrate_*.py`.
- Tests: `tests/` (unit/integration).
# MioHub (Flask) — Copilot Agent Instructions

## Big Picture
- Multi-product Flask app with blueprints under `blueprints/`: p1 (calculator), p2 (MioWord files/folders), p3 (chat), p4 (graph).
- App entrypoint: `flask_app.py` registers every blueprint listed in `blueprints/__init__.py` (`bps`).
- Database: MySQL + SQLAlchemy (`extensions.py` exposes `db`, `login_manager`).

## Local Workflow (Windows)
- Bootstrap venv + deps: `start_project.bat` (creates `.venv`, installs `requirements.txt`).
- Initialize DB + seed users: `python init_db.py` (creates `testuser/password123` and `admin/admin123` if missing).
- Run dev server: `python flask_app.py` (host `0.0.0.0`, port `5555`, large uploads enabled).
- Run tests: `pytest` (see `tests/`).

## Configuration (Important)
- Treat `config.py` as the source of truth (Python constants + `get_database_uri()`); ignore older README/YAML references.
- LLM provider routing is OpenAI-compatible and centralized in `providers.py` (`LLMClient` uses `config.PROVIDER` + `config.DEFAULT_CHAT_MODEL`).

## Product 2 Data Model (Core Convention)
- Universal content model is `blueprints/p2/models.py:File` (single record stores one of: `content_text|content_html|content_json|content_blob`; auxiliary fields go in `metadata_json`).
- File types are discriminated by `File.type`; see `VALID_FILE_TYPES` and the proprietary types (`proprietary_note`, `proprietary_whiteboard`, `proprietary_blocks`, `proprietary_infinite_whiteboard`, `proprietary_graph`).
- Prefer `file.description` (property) over reaching into `metadata_json['description']` directly.
- Storage/quotas: `User.user_type` (`guest` is capped) + `User.total_data_size`; update sizes via `utilities_main.update_user_data_size` when adding/removing content.

## JSON Column Gotcha (SQLAlchemy)
- When mutating JSON fields (e.g., `user_prefs`, `metadata_json`, `content_json`), call `flag_modified(obj, 'field')` before `db.session.commit()` (pattern used across p2/p3 routes).

## Frontend Pattern (HTMX + OOB)
- Folder view updates use HTMX out-of-band swaps (`hx-swap-oob`) in `blueprints/p2/folder_routes.py`.
- If you inject HTML dynamically, ensure JS listeners are reattached (see `blueprints/p2/static/js/clipboard_operations.js` HTMX event hooks).

## Adding New Routes/Blueprints
- If you add a blueprint, you MUST import it and append to `bps` in `blueprints/__init__.py` or routes will 404.

## Migrations / Safety
- This repo uses ad-hoc migration scripts (see `other_tests/migrate_*.py`). Avoid destructive changes: don’t drop existing tables/columns; check existence before ALTER.
# Flask Multi-Product Application - AI Coding Agent Guide

## Project Context & Philosophy

Multi-product Flask web application featuring: **Product 1 (p1)** - calculator with inline AI evaluation, **Product 2 (p2)** - MioWord document system (notes/whiteboards/files with 10+ file types), **Product 3 (p3)** - AI chatbot with session memory, **Product 4 (p4/graph)** - Graph knowledge workspace with nodes, edges, and attachments. MySQL database with SQLAlchemy ORM, structured using Flask blueprints.

**Evolution**: Started as personal note-taking → multi-user platform → added AI chat memory → file sharing with storage quotas → unified File model architecture (v2.16) → graph workspace for interconnected knowledge (Dec 2024).

**Design Principles**:

- Extensibility: Easy to add new file types and products
- User isolation: Data scoped by user_id with storage quotas
- No page reloads: HTMX for dynamic updates, batch operations for multi-select
- Modular architecture: Whiteboard split into 12 JavaScript modules (3953 lines → modular)
- Graph-based knowledge: Nodes connect files/folders/tasks with customizable relationships

**Agent Expectations**:

- Be proactive with optimization improvements (Flask/SQLAlchemy/AI integration best practices)
- Reference specific files/functions (avoid generic advice)
- Run `pytest` after updates for stability
- Plan large changes in `.DOCS/plans/` first
- Document changes in `.DOCS/reference/` and update this file
- Use Tailwind CSS only (remove Bootstrap where found)
- Theme: `static/css/theme_colors_carbon_teal.css`

## Architecture Overview

**Blueprint Structure**: Four products in `blueprints/{p1,p2,p3,p4}/` with dedicated routes, models, templates, static assets. Core landing pages in `blueprints/core/`, authentication in `blueprints/auth/`, health checks in `blueprints/health.py`.

**Products**:

- **p1**: Calculator with inline AI (evaluate expressions, explain code)
- **p2**: MioWord - Universal File system with 10+ types (markdown, todo, diagram, note, whiteboard, book, blocks, table, pdf, infinite_whiteboard)
- **p3**: AI chatbot with multi-session memory (ChatSession → ChatMessage + ChatMemory)
- **p4/graph**: Graph knowledge workspace with nodes, edges, and attachments (files/folders/URLs/tasks)

**Database**: MySQL with SQLAlchemy ORM. Models in `blueprints/{blueprint}/models.py`.

**Blueprint Registration** (`blueprints/__init__.py`):

```python
from .core import core_blueprint
from .p1 import p1_blueprint
from .p2 import p2_blueprint, notes_bp, whiteboard_bp, folder_bp, combined_bp, file_bp, infinite_whiteboard_bp, graph_bp
from .p3 import p3_blueprint
from .p4 import p4_blueprint
from .auth import auth_blueprint
from .health import health_bp

bps = [core_blueprint, p1_blueprint, p2_blueprint, notes_bp, whiteboard_bp,
       folder_bp, combined_bp, file_bp, infinite_whiteboard_bp, graph_bp,
       p3_blueprint, p4_blueprint, auth_blueprint, health_bp]
```

**CRITICAL**: All blueprints must be imported in `blueprints/__init__.py` and added to `bps` list for auto-registration in `flask_app.py`.

**Front-End Stack**:

- HTMX 1.9.10 for zero-reload updates (paste operations, dynamic content)
- Tailwind CSS via CDN (script tag, not link) + Carbon Teal theme CSS
- Specialized editors: Toast UI, EasyMDE, Monaco, Luckysheet, Editor.js
- Whiteboard: 12 modular JS files (shapes, transform, export, etc.)

## Configuration System

**CRITICAL**: Uses Python module configuration (`config.py`), NOT environment variables or YAML files (legacy references exist).

```python
# Access config values directly:
from config import DB_NAME, DB_USER, GROQ_API_KEY, PROVIDER
# Or via legacy compat:
from config import get_config
config = get_config()
db_name = config.get_db_name()
```

- **Database**: Configured via `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` in `config.py`
- **LLM Providers**: Set via `PROVIDER` constant (`groq`, `openrouter`, `fireworks`, `together`). Provider abstraction in `providers.py` (LLMClient class).
- **File Uploads**: Max 1000MB configured in `flask_app.py` for large whiteboard/note content

## Database Migrations

**Pattern**: Manual migration scripts (no Alembic). Place in project root with `migrate_*.py` naming.

```python
# Standard migration template:
from flask import Flask
from extensions import db
from sqlalchemy import text
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
db.init_app(app)

with app.app_context():
    inspector = db.inspect(db.engine)
    # Check column existence, run ALTER TABLE if needed
```

**Key migrations**:

- `migrate_add_folder_description_field.py` - Folder descriptions
- `migrate_add_note_board_descriptions.py` - Note/board descriptions
- `migrate_add_public_flag.py` - Public sharing flags
- `migrate_add_last_modified.py` - Last modified timestamps

Always check if column exists before adding. Use TEXT (not VARCHAR) for descriptions to avoid truncation (see `migrate_change_descriptions_to_text.py`).

## Product 2 (MioWord) - Core Patterns

### Folder/File Hierarchy

```python
User -> Folder (tree structure via parent_id) -> Files
```

- **Folders**: Recursive parent/child via `parent_id` self-reference
- **Files**: Universal content storage with type discriminator ('note', 'whiteboard', 'markdown', 'todo', 'diagram', 'book', 'blocks', 'table', 'pdf', etc.)

**IMPORTANT**: As of v2.16 (Dec 2024), the legacy `Note` and `Board` models have been **REMOVED**. All content is stored in the `files` table. The `note`, `boards`, and `shared_note` tables have been dropped.

### Universal File Table

**File-Only Architecture**: All content stored in unified `files` table with type discriminators.

```python
from blueprints.p2.models import File, VALID_FILE_TYPES

# Valid file type discriminators (from models.py):
# Proprietary products (with proprietary_ prefix):
#   'proprietary_note'              - MioNote (rich HTML editor)
#   'proprietary_whiteboard'        - MioDraw (canvas drawing)
#   'proprietary_blocks'            - MioBook (combined documents)
#   'proprietary_infinite_whiteboard'  - Infinite Canvas
#   'proprietary_graph'             - Graph knowledge workspace
#
# Third-party integrations (no prefix):
#   'markdown'    - Toast UI Editor
#   'code'        - Monaco Editor
#   'todo'        - SortableJS
#   'diagram'     - Monaco JSON
#   'table'       - Luckysheet
#   'blocks'      - Editor.js
#
# Binary/Upload types:
#   'pdf'         - PDF files (binary storage)
#
# Legacy aliases (backward compatibility):
#   'note'        - Legacy MioNote type
#   'whiteboard'  - Legacy MioDraw type

# Content columns (only one populated per record):
#   content_text  - Plain text, markdown source
#   content_html  - Rich formatted HTML (used for legacy 'note' type)
#   content_json  - Structured data (canvas, diagrams, todos, whiteboards, MioBook blocks)
#   content_blob  - Binary files (PDFs, images, uploads)
# metadata_json  - Auxiliary info ONLY (descriptions, UI state, file props)

# Creating a note (legacy MioNote format):
note_file = File(
    owner_id=current_user.id,
    folder_id=folder_id,
    type='note',
    title='My Note',
    content_html='<p>Rich HTML content</p>',
    metadata_json={'description': 'A sample note'}
)

# Creating a whiteboard (legacy MioDraw format):
board_file = File(
    owner_id=current_user.id,
    folder_id=folder_id,
    type='whiteboard',
    title='My Whiteboard',
    content_json={'elements': [...], 'background': 'white'},
    metadata_json={'description': 'A sample whiteboard'}
)

# Creating a markdown file:
markdown_file = File(
    owner_id=current_user.id,
    folder_id=folder_id,
    type='markdown',
    title='My Markdown Note',
    content_text='# Hello\n\nMarkdown content',
    metadata_json={'description': 'A markdown note'}
)

# Creating a MioBook (combined document with note/board blocks):
book_file = File(
    owner_id=current_user.id,
    folder_id=folder_id,
    type='book',
    title='My MioBook',
    content_json=[
        {'type': 'note', 'note_id': 123, 'title': 'Introduction'},
        {'type': 'board', 'board_id': 456, 'title': 'Diagram'}
    ],
    metadata_json={'description': 'MioBook combined document'}
)

# Helper methods:
content = file.get_content()        # Returns appropriate content based on type
size_bytes = file.get_content_size()  # For storage quota tracking

# Accessing description (via property):
description = file.description       # Reads from metadata_json['description']
```

**IMPORTANT - Description Access**: The `File` model has a `description` property that provides convenient access to `metadata_json['description']`. This property handles null safety and returns an empty string if description is not set. Always use `file.description` in templates rather than directly accessing `metadata_json['description']`.

**Routes**: `/p2/files/new/<type>`, `/p2/files/<id>/edit`, `/p2/files/<id>/view`, `/public/file/<id>`
**MioBook Routes**: `/p2/combined/new`, `/p2/combined/edit/<id>`, `/p2/combined/print_view/<id>`

**UI Integration**:

- **Context Menu**: Right-click "New File" submenu in `folder_view.html` with markdown/todo/diagram/note/table options, plus "New MioBook" for combined documents
- **FAB Menu**: Floating Action Button includes matching "New File" submenu in `folder_view_fab.html`
- Both use `window.createNewFile(fileType)` JavaScript function for unified navigation

**Edit Templates**: Feature-rich editors with UI libraries:

- `file_edit_markdown.html` - Toast UI Editor 3.x (WYSIWYG/markdown mode, live preview, autosave)
- `file_edit_todo.html` - SortableJS 1.15.0 (drag-to-reorder, native checkboxes, progress bar)
- `file_edit_note.html` - EasyMDE 2.18.0 (markdown editor with preview, autosave, stores content as JSON)
- `file_edit_diagram.html` - Monaco Editor 0.44.0 (JSON editing, canvas preview, templates)
- `file_edit_table.html` - Luckysheet (latest) (Excel-like spreadsheet, formulas, formatting, multiple sheets, CSV import/export)
- `file_edit_blocks.html` - Editor.js 2.28.0 (block-based editor with 15+ block types, auto-save, dark theme, stores content as JSON)
- `miobook_edit_v2.html` - MioBook v2.0 modular block editor (markdown, todo, code, editorjs, atrament drawing blocks)

**Legacy Note/Board Routes**: Original `/notes/*` and `/boards/*` routes remain functional, operating on File model with type filters.

### MioBlocks (MioBook v3.0) - Block-Row Architecture with Annotations

**IMPORTANT**: MioBlocks (type `'proprietary_blocks'`) features a **two-column block-row system** with main content blocks and inline annotations for contextual notes.

```python
# MioBlocks File structure (type='proprietary_blocks'):
{
    "version": "2.0",
    "blocks": [
        {
            "id": "block-uuid",
            "type": "markdown|todo|code|blocks|whiteboard|annotation",
            "title": "Block Title",
            "content": "...",        # Format depends on type
            "metadata": {"language": "python"},  # For code blocks
            "order": 0,              # Block position in document
            "splitRatio": 50,        # Main/annotation column width (0-100)
            "annotationShow": true,  # Visibility of annotation column
            "annotations": [         # Child annotation blocks
                {
                    "id": "annotation-uuid",
                    "type": "markdown|todo|code|blocks|whiteboard",
                    "title": "Annotation Title",
                    "content": "...",
                    "parentId": "block-uuid",
                    "order": 0
                }
            ]
        }
    ]
}
```

**Architecture Pattern**: Block-Row Container → Main Block Column + Annotation Column

**Block Types**:
- **Main Blocks**: markdown, todo, code, blocks, whiteboard (any can have annotations)
- **Annotation Blocks**: markdown, todo, code, blocks, whiteboard (attached to main blocks)
- All blocks use same editor handlers, just different container layouts

**Data Collection** (`miobook_core.js:collectBlocksData()`):
```javascript
// Collects data from DOM structure:
// 1. Iterate through `.block-row` elements
// 2. Extract main block from `.main-block-column .block-item`
// 3. Extract annotations from `.annotation-column .block-item`
// 4. Resolve async content (Editor.js, Monaco) for each block
// 5. Attach annotations to parent with parentId reference
// 6. Preserve splitRatio and annotationShow UI state
```

**JavaScript Modules** (`static/js/miobook/`):
- `miobook_core.js` - Document state, block-row management, auto-save, drag-and-drop (SortableJS drags entire rows)
- `markdown_handler.js` - Toast UI Editor initialization and content extraction
- `todo_handler.js` - SortableJS todo lists with add/delete/checkbox state
- `code_handler.js` - Monaco Editor with syntax highlighting and language switching
- `editorjs_handler.js` - Editor.js with 12 plugins for rich content
- `atrament_handler.js` - Atrament.js canvas drawing with draw/erase/fill modes
- `annotation_handler.js` - Annotation-specific UI (add/remove/navigation/toggle visibility)

**UI Features**:
- **Resizable Split**: Drag handle between main and annotation columns (stores `splitRatio`)
- **Annotation Toolbar**: Add button + prev/next navigation for multi-annotation blocks
- **Keyboard Shortcuts**: Ctrl+Shift+A (add annotation), Ctrl+Shift+H (toggle visibility), Escape (close menu)
- **Mobile Responsive**: Annotations stack vertically on <1024px, FAB toggle button
- **Lazy Initialization**: Heavy editors (markdown/code/blocks) use progressive loading with `data-init-state`
- **Overflow Menus**: Block control buttons collapse into "..." menu on narrow containers

**Template**: `file_edit_proprietary_blocks.html` (1706 lines, uses Jinja2 to render saved block structure)

**Routes**: 
- Editor: `/p2/files/<id>/edit` (type='proprietary_blocks')
- Save: `POST /combined/edit/<id>` or `/combined/new`
- Print: `/p2/combined/print_view/<id>`

**Export/Import Compatibility**: 
- Saves as version 2.0 JSON structure
- Backward compatible: Can load legacy v1.0 format (flat blocks array)
- Annotation migration: Old `type='annotation'` with `parentId` → nested `annotations` array

**Theme**: Graphite-Teal-Dirty Yellow (custom Tailwind colors inline in template)

See `.DOCS/reference/MIOBOOK_V2_ARCHITECTURE.md` for detailed implementation.

### Image Deduplication System

All user-uploaded images use SHA256 hash-based deduplication:

```python
from blueprints.p2.utils import save_data_uri_images_for_user, copy_images_to_user

# Saving images from editor (converts data URIs):
updated_content, bytes_added = save_data_uri_images_for_user(content, user_id)

# Copying between users (deduplicates via hash):
mapping, bytes_added = copy_images_to_user(image_filenames, receiver_id)
```

**Filename format**: `{user_id}_{sha256_hash}.webp` - prevents duplicates, automatically converts to WebP.

### Send To / Copy Operations

Product 2 supports copying items between users with folder structures intact. Key function:

```python
from blueprints.p2.utils import calculate_copy_size_for_item
total_bytes, details = calculate_copy_size_for_item('folder', folder_obj, recipient_id)
```

- Checks recipient's existing images by hash to avoid double-charging storage
- Updates `User.total_data_size` column for storage quotas
- Supports `user_type` enforcement: `guest` users have 50MB limit

### User Preferences (JSON Column)

```python
current_user.user_prefs = {
    "theme": "flatly",
    "isPinned": False,
    "display": {
        "columns": 3,
        "view_mode": "grid",  # or "list"
        "card_size": "normal",
        "show_previews": True
    },
    "pinned_users": [123, 456]  # user IDs
}

# CRITICAL: Flag modified for SQLAlchemy to detect JSON changes
from sqlalchemy.orm.attributes import flag_modified
flag_modified(current_user, 'user_prefs')
db.session.commit()
```

### Public Sharing System

Notes, boards, and folders have `is_public` boolean flags:

```python
# Making item public:
POST /folders/set_public
    item_type: 'note' | 'board' | 'folder'
    item_id: 123
    public: '1' | '0'

# Viewing public items:
GET /public/note/<id>
GET /public/board/<id>
GET /public/folder/<id>  # Shows public descendants only
```

Public folders expose entire subtrees - children inherit visibility context (not db flag).

## Product 4 (Graph) - Knowledge Graph System

**Graph Workspace**: Visual knowledge graph with nodes, edges, and attachments. Each graph is stored as a File with type `'proprietary_graph'` and linked to dedicated graph tables.

### Graph Data Model

```python
# Four-table system for graph workspaces:
GraphWorkspace -> GraphNode (micro-workspaces with position/size/style)
               -> GraphEdge (directed relationships between nodes)
               -> GraphNodeAttachment (links to files/folders/URLs/tasks)

# Creating a graph workspace:
graph_file = File(
    owner_id=current_user.id,
    folder_id=folder_id,
    type='proprietary_graph',
    title='My Knowledge Graph',
    content_json={},  # Graph structure stored here
    metadata_json={'description': 'Visual knowledge map'}
)
db.session.add(graph_file)
db.session.commit()

graph_workspace = GraphWorkspace(
    file_id=graph_file.id,
    owner_id=current_user.id,
    folder_id=folder_id,
    settings_json={'canvas': {'zoom': 1.0, 'panX': 0, 'panY': 0}},
    metadata_json={}
)
db.session.add(graph_workspace)
db.session.commit()
```

**Key Models** (`blueprints/p2/models.py`):

- **GraphWorkspace**: Metadata for graph file, canvas settings
- **GraphNode**: Nodes with title, summary, position_json `{x, y}`, size_json `{w, h}`, style_json (colors, badges)
- **GraphEdge**: Directed edges between nodes with label and edge_type
- **GraphNodeAttachment**: Links nodes to files/folders/URLs/tasks via `attachment_type` field

**Routes** (`blueprints/p2/graph_routes.py`):

```python
GET  /graph/<file_id>                     # View graph interface
GET  /graph/<file_id>/data                # Fetch nodes/edges/attachments
POST /graph/<file_id>/nodes               # Create node
PATCH /graph/<file_id>/nodes/<node_id>    # Update node position/size/style
DELETE /graph/<file_id>/nodes/<node_id>   # Delete node
POST /graph/<file_id>/edges               # Create edge
PUT  /graph/<file_id>/edges/<edge_id>     # Update edge label/type
DELETE /graph/<file_id>/edges/<edge_id>   # Delete edge
POST /graph/<file_id>/attachments         # Attach file/folder/URL/task to node
DELETE /graph/<file_id>/attachments/<id>  # Remove attachment
POST /graph/<file_id>/refresh-attachments # Refresh attachment metadata
GET  /graph/<file_id>/export/jsonl        # Export graph as JSONL
```

**Graph Service** (`blueprints/p2/graph_service.py`): Business logic for graph operations, validation, and data transformations.

**Integration**: Graph workspaces appear in folder views alongside other files. Right-click "New Graph" creates a graph file with associated GraphWorkspace record.

## Development Workflows

### Starting the Application

```powershell
# First run: initialize database
python init_db.py

# Start development server
python flask_app.py
# Runs on http://0.0.0.0:5555 with debug=True
```

**Default test users** (created by `init_db.py`):

- `testuser` / `password123` (guest user with 50MB quota, `user_type='guest'`)
- `admin` / `admin123` (admin user with unlimited quota, `user_type='admin'`)

**Storage Quotas**: `guest` users have 50MB limit, `user` and `admin` types are uncapped. Enforced via `User.total_data_size` column tracked during image uploads and file operations.

### Running Tests

```powershell
# Run all tests with pytest
pytest

# Run only unit tests (no database/Flask context required)
pytest tests/unit/

# Run only integration tests (require database and app context)
pytest tests/integration/

# Run with coverage report
pytest --cov=blueprints --cov-report=html

# Utility scripts for manual testing and diagnostics
python tests/utilities/test_db_connection.py
python tests/utilities/test_config.py
python scripts/check_templates.py
```

**Test Organization**:

- `tests/unit/` - Isolated component tests (calculators, parsers, validators)
- `tests/integration/` - Tests requiring database/Flask app (user operations, file copying)
- `tests/utilities/` - Standalone diagnostic scripts (DB connection, config validation)
- `tests/conftest.py` - Pytest fixtures (`app`, `db`, `client`, `dummy_user`)

**Pytest Fixtures** (available in all tests):

- `app` - Flask application instance with context
- `db` - Database session with automatic rollback
- `client` - Flask test client for HTTP requests
- `dummy_user` - Mock user object for unit tests

### Database Inspection

```python
# Quick schema check pattern (useful for migrations):
from extensions import db
from sqlalchemy import inspect

with app.app_context():
    inspector = inspect(db.engine)
    columns = [col['name'] for col in inspector.get_columns('table_name')]
    # Check before adding: if 'new_column' not in columns: ...
```

## AI Integration Patterns

### Inline AI (Product 1 Calculator)

```javascript
// Client sends selected text:
POST /p2/api/ai_inline
    { "action": "explain|eval", "text": "..." }

// Server responds with formatted result:
{ "combined": "ORIGINAL_TEXT\n\n— AI —\nRESULT" }
```

Uses delimiter `\n\n— AI —\n` from `config.AI_DELIMITER`. Max input: 8000 chars (`config.MAX_INPUT_CHARS`).

### Chatbot (Product 3)

Session-based conversations with persistent memory:

```python
# Session management:
ChatSession -> ChatMessage (ordered conversation)
               ChatMemory (user-curated facts)

# Provider switching (runtime):
POST /p3/set_model
    { "provider": "groq", "model": "llama-3.1-8b-instant" }
```

Uses `providers.LLMClient` for OpenAI-compatible API abstraction. Provider constants in `config.py`: `groq`, `openrouter`, `fireworks`, `together`.

## Front-End Patterns

### JavaScript Module Pattern

**CRITICAL**: Project uses modular JavaScript architecture with handler pattern for complex components.

**Pattern**: Separate concerns into focused modules that communicate via `window` globals and event listeners.

```javascript
// Module pattern example (MioBook blocks):
class BlockHandler {
    constructor() {
        this.instances = new Map();  // Track instances by block ID
    }
    
    async initialize(blockElement) {
        const blockId = blockElement.dataset.blockId;
        // Initialize library (Toast UI, Monaco, etc.)
        this.instances.set(blockId, instance);
    }
    
    async getContent(blockId) {
        // Extract content from library instance
        return this.instances.get(blockId)?.getValue();
    }
}

// Expose globally for core module
window.MarkdownHandler = new BlockHandler();
```

**Examples in Codebase**:

1. **MioBook** (`static/js/miobook/`):
   - 6 modular handlers: core, markdown, todo, code, editorjs, atrament
   - Core coordinates all handlers via `window.MarkdownHandler?.initialize()`
   - Each handler manages its own library instances (Toast UI, Monaco, Atrament)

2. **Whiteboard** (`blueprints/p2/static/js/`):
   - 12 modular files: shapes, textboxes, commands, settings, layers, render, images, pages, transform, events, text, export
   - Main file provides fallback wrappers: `function getBounds(o) { return window.getBounds ? window.getBounds(o) : {...}; }`
   - Modules loaded before main script to define `window` globals

3. **Infinite Whiteboard** (`static/js/infinite_whiteboard/`):
   - Context-sensitive toolbar system with `infinite_whiteboard_toolbars.js`
   - Separate modules for different concerns (layers, export, etc.)

**Benefits**: Reduces file size, improves maintainability, enables code reuse, easier testing.

**When to Use**: Components >1000 lines, multiple third-party libraries, complex state management.

### HTMX Integration (Zero-Reload Updates)

**Key Pattern**: Backend routes check for `htmx=true` query param and return HTML partials instead of JSON.

```python
# Backend route pattern:
@folder_bp.route('/folders/duplicate_note/<int:note_id>')
def duplicate_note(note_id):
    # ... duplicate logic ...
    if request.args.get('htmx') == 'true':
        return jsonify({
            'success': True,
            'new_item_html': render_template('p2/partials/note_card.html', note=new_note),
            'new_item_id': new_note.id,
            'item_type': 'note'
        })
    return jsonify({'success': True, 'new_id': new_note.id})
```

```javascript
// Frontend inserts HTML dynamically:
fetch(`/folders/duplicate_note/${id}?htmx=true`)
  .then((r) => r.json())
  .then((data) => {
    container.insertAdjacentHTML("afterbegin", data.new_item_html);
    // CRITICAL: Re-attach event listeners to new content
    window.attachCardClickListeners(newItem.querySelector(".item-body"));
  });
```

**Event Listener Pattern**: Always re-attach listeners to HTMX-inserted content:

```javascript
// Global listener for HTMX swaps
document.body.addEventListener("htmx:afterSwap", function (event) {
  const itemBodies = event.detail.target.querySelectorAll(".item-body");
  itemBodies.forEach(window.attachCardClickListeners);
});
```

### Batch Operations Bar (Unified Selection Model)

**CRITICAL**: As of v2.16, ALL selection operations use batch mode (even single items).

```javascript
// Selection state:
window.batchSelected = []; // Array of {type, id, card}
window.selected = null; // DEPRECATED: kept for backward compatibility

// Single-click adds to batch (no floating action bar):
function handleCardClick(e, type, id, card) {
  const item = { type, id, card };
  const exists = window.batchSelected.find(
    (s) => s.type === type && s.id === id
  );
  if (exists) removeBatchItem(item);
  else addBatchItem(item);
}
```

Operations (cut/copy/paste/delete) work on `window.batchSelected` array, whether 1 or 100 items selected.

## CSS and Theming Architecture

### Carbon Teal Theme (Global P2 Styling)

**CRITICAL**: All p2 blueprint templates use centralized theming via `static/css/theme_colors_carbon_teal.css`.

**Standard Template Pattern**:

```html
<head>
  <title>Page Title</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons"
    rel="stylesheet"
  />
  <script src="https://cdn.tailwindcss.com"></script>
  <link
    rel="stylesheet"
    href="{{ url_for('static', filename='css/theme_colors_carbon_teal.css') }}"
  />
</head>
```

**Key Features**:

- **CSS Custom Properties**: All p2 pages share the same color palette (`--bg`, `--card`, `--accent`, `--muted`, etc.)
- **Dual Naming Convention**: Generic names (`--bg`) for page-level, prefixed names (`--ct-bg`) for modal/component isolation
- **Summernote Modal Theming**: Automatic dark theme for rich text editor modals
- **Tailwind Integration**: Uses Tailwind CDN script tag (not link tag) for latest features
- **Override Flexibility**: Pages can add custom styles without breaking global theme

**Exceptions (Templates Without Theme CSS)**:

- `miobook_print_view.html` - Print-specific white background
- `edit_image.html` - TOAST UI Image Editor has its own design system

**Color Variables**:

```css
--bg: #0a0a0b           /* Near-black background */
--card: #121516          /* Card/panel background */
--accent: #14b8a6        /* Teal accent color */
--accent-strong: #0d9488 /* Darker teal for hover */
--white: #ECFFFF         /* Primary text (off-white) */
--muted: #9aa8ad         /* Secondary/muted text */
```

**When Creating New P2 Templates**: Always include the theme CSS file unless the page has special requirements (print, embedded third-party UI, etc.). See `.DOCS/reference/CSS_STANDARDIZATION_SUMMARY.md` for full documentation.

## Whiteboard Architecture (MioDraw)

**IMPORTANT**: The whiteboard component (`whiteboard_component_v4.html`) uses a **modular architecture** with 11 JavaScript modules. As of v2.16, the main file has been reduced from 5900 to 3953 lines through systematic refactoring (33% reduction).

### Whiteboard Modules (Load Order)

```html
<!-- Whiteboard Modules - MUST load before main script -->
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_shapes.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_textboxes.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_commands.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_settings.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_layers.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_render.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_images.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_pages.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_transform.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_events.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_text.js') }}"></script>
<script src="{{ url_for('p2_bp.static', filename='js/whiteboard_export.js') }}"></script>
```

**Module Responsibilities:**

1. **whiteboard_shapes.js** (~550 lines) - Shape drawing with 29 shapes organized into 4 categories: Drawing Tools (line, arrow, doubleArrow), Flowchart (process, decision, inputOutput, document, manualInput, storedData, display, merge, connector), Basic Shapes (rectangle, roundedRectangle, circle, ellipse, triangle, pentagon, hexagon, star), Tech/Cloud Icons (cloud, ai, robot, iot, user, server, database, envelope, tower)
2. **whiteboard_textboxes.js** (~200 lines) - Text box creation with shape backgrounds, uses same shapes as shapes module, provides prompt-based text input, supports all 29 shape types from shapes module
3. **whiteboard_commands.js** (~150 lines) - Undo/redo system with command pattern
4. **whiteboard_settings.js** (~100 lines) - User preferences (text wrapping, layout, tool memory)
5. **whiteboard_layers.js** (~120 lines) - Z-order management (bring to front, send to back, layer panel)
6. **whiteboard_render.js** (~200 lines) - Canvas rendering pipeline and selection visualization
7. **whiteboard_images.js** (~250 lines) - Image upload, crop modal, paste handling
8. **whiteboard_pages.js** (~180 lines) - Multi-page navigation and management
9. **whiteboard_transform.js** (~450 lines) - Selection, rotation, resize with 8 handles + Shift constraint
10. **whiteboard_events.js** (~80 lines) - Event coordinate conversion and context menu positioning
11. **whiteboard_text.js** (~320 lines) - Text wrapping, multi-page text distribution, text editor
12. **whiteboard_export.js** (~430 lines) - AJAX save, JSON export/import, PNG export, multi-page PDF generation

**Fallback Pattern:** Main file contains fallback wrappers for all module functions:

```javascript
function getBounds(o) {
  return window.getBounds ? window.getBounds(o) : { x: 0, y: 0, w: 0, h: 0 };
}
```

**Key Functions (Transform Module):**

- `getHandleAt()` / `getMultiHandleAt()` - Hit-testing for resize/multi-select handles
- `performResize()` - Complex resize with aspect ratio constraints (Shift key)
- `performRotation()` - Rotate images/text/strokes around center point
- `getBounds()` - Calculate bounding boxes (handles images, text wrapping, stroke paths)
- `isPointOnObject()` / `pickTopMost()` - Selection hit-testing with z-order

**Key Functions (Text Module):**

- `autoWrapTextByWords()` - Wrap text by maximum words per line
- `splitTextByLines()` - Split text into page chunks by line count
- `addTextAcrossPages()` - Multi-page text distribution with user confirmation
- `openTextEditor()` / `closeTextEditor()` - Text editing modal overlay

**Key Functions (Export Module):**

- `saveToServer()` - AJAX save with 120s timeout, loading overlay, HTTP 413 detection, form action updates
- `exportJSON()` - Blob creation with optional undo history (multi-page version 3 format)
- `importJSON()` / `handleImportFile()` - JSON parsing for multi-page and legacy single-page formats
- `exportPNG()` - Current page to PNG download
- `printToPDF()` - Async multi-page PDF with jsPDF (renders each page sequentially with 100ms delays)

**Dependencies:**

- Modules communicate via `window` globals
- Transform module uses `userPrefs`, `originalPositions` Map, `autoWrapTextByWords()`
- Shapes module provides `createShapePath()`, `isShapeTool()`, `isPointOnShape()`
- Text module uses `addObject()`, `createNewPage()`, `saveCurrentPageState()`, `loadPageState()`
- Export module uses `pages`, `currentPageIndex`, `nextPageId`, `nextObjectId`, `showSaveSuccess()`

**Documentation:**

- Phase 3 (Transform/Events): `.DOCS/reference/WHITEBOARD_PHASE3_TRANSFORM_EVENTS.md`
- Phase 4 (Text Handling): `.DOCS/reference/WHITEBOARD_PHASE4_TEXT.md`
- Phase 5 (Export/Import): `.DOCS/reference/WHITEBOARD_PHASE5_EXPORT.md`

## UI/UX Features

### TelemetryPanel (Oscilloscope Display)

Real-time system diagnostics panel with animated waveforms:

```html
<!-- Include in navbar -->
{% include 'p2/telemetry_panel_partial.html' %}
<link
  rel="stylesheet"
  href="{{ url_for('static', filename='css/telemetry_panel.css') }}"
/>
<script src="{{ url_for('static', filename='js/telemetry_panel.js') }}"></script>
```

**Key Features**:

- Oscilloscope-style waveform animation (Canvas API)
- Rotating metrics: user type, storage, images, last transfer
- Activity detection: waveform amplitude/frequency increase during send/copy operations
- Expandable modal with detailed metrics grid

**API Integration**:

```python
GET /p2/api/telemetry_data
# Returns: user_type, storage_used, storage_total, storage_remaining,
#          total_images, last_sender, last_transfer_time
```

**Activity Hooks**:

```javascript
// Trigger active state during operations
window.TelemetryPanel.setActive("Copying folder to testuser222...");
// Return to idle when complete (message optional)
window.TelemetryPanel.setIdle("Transfer complete");
```

`setIdle(message)` can show error text (for example `window.TelemetryPanel.setIdle('Send failed: guest limit')`) so we no longer rely on flash alerts. The send-to modal now closes immediately after a pinned username is clicked and progress is surfaced exclusively through the telemetry widget.

Performance: GPU-accelerated, <5% CPU idle, 60fps animation. See `.DOCS/reference/TELEMETRY_PANEL_README.md`.

### Picture Asset Viewer Modal with Image Editor

- `p2/assets.html` now opens previews inside an overlay instead of spawning new tabs, keeping users inside the workspace while browsing uploads.
- Modal navigation supports keyboard arrows plus on-screen controls and shows `current / total` to give orientation within large galleries.
- Footer actions include **Edit picture** (opens TOAST UI image editor) and **Download** (downloads high-res source); the usage list shows all note/board references so users can gauge impact before deleting.
- `window.refreshAssetGalleryData()` keeps the modal index list up to date after uploads or deletions.

**Integrated Image Editor**:

- **Route**: `GET /edit_image/<filename>` - Opens TOAST UI Image Editor interface with ownership verification
- **Save Route**: `POST /save_image/<filename>` - Saves edited image as WebP, updates storage quota
- **Features**: Comprehensive editing (crop, filters, draw, text, shapes, rotation, masking)
- **Quota Management**: Tracks size delta, enforces storage limits, auto-converts to WebP
- **CDN Libraries**: Uses fabric.js, tui-color-picker, tui-image-editor from CDN (no local install)

See `.DOCS/reference/ASSET_VIEWER_MODAL_v2.md` for full implementation details.

### Whiteboard Text Boxes Dropdown

The Text Boxes dropdown provides quick creation of text boxes with predefined shape backgrounds in MioDraw.

**Location**: Toolbar, next to Shapes dropdown
**Icon**: `fa-comment-alt` (chat bubble)
**Module**: `whiteboard_textboxes.js`

**Features**:

- **29 Shape Options**: Same shapes as Shapes dropdown (Drawing Tools, Flowchart, Basic Shapes, Tech/Cloud Icons)
- **Click-to-Place**: Select shape, then click anywhere on canvas to place
- **Default Text**: Creates with "Sample Text" placeholder
- **Double-Click Edit**: Double-click text to open editor and customize content
- **Dual Objects**: Creates both shape (background) and text (foreground) as separate objects
- **Color Integration**: Uses current toolbar color for both stroke and text
- **Undo/Redo Support**: Single undo command removes/restores both objects
- **Auto-Close**: Dropdown closes after shape selection
- **Mutual Exclusion**: Opening Text Boxes closes Shapes dropdown and vice versa
- **Escape to Cancel**: Press Escape to exit placement mode

**Usage Pattern**:

```javascript
// Click Text Boxes button → Select shape → Click on canvas → Text box placed with "Sample Text"
promptCreateTextBox("process"); // Activates placement mode for process box
placeTextBox(x, y, "process"); // Places process box at coordinates
```

**Default Dimensions**: 150x80px with 10px padding, font size from toolbar (default 16px)

See `.DOCS/reference/WHITEBOARD_TEXTBOXES_DROPDOWN.md` for full implementation details.

### Dual-Arrow Sidebar Toggle System

The left sidebar uses a **dual-arrow toggle system** inspired by VS Code/JetBrains IDEs:

- **Two Independent Toggle Buttons**: Folders (folder icon) and Social (people icon)
- **Direct Navigation**: Click any arrow to open sidebar to that specific tab
- **Tab Switching**: Click the other arrow when open to instantly switch tabs
- **Toggle Behavior**: Click the active arrow to close the sidebar
- **Visual Feedback**: Active button has teal gradient background with white edge indicator
- **State Persistence**: Remembers which tab was active via localStorage

**Implementation Files**:

- `folder_view_left_sidebar_partial.html` - Main dual-arrow HTML/CSS/JS
- `folder_view.html` - Event listener integration

**Key Functions**:

```javascript
openFolderBrowserTab(tabName); // Opens to specific tab or closes if active
updateToggleButtonStates(activeTab); // Updates visual active state
closeFolderBrowser(); // Closes sidebar completely
```

See `.DOCS/reference/DUAL_ARROW_SIDEBAR_TOGGLE.md` for detailed documentation.

### Context-Sensitive Toolbars (Infinite Whiteboard)

The Infinite Whiteboard features a **modular, context-sensitive toolbar system** that dynamically displays relevant tools based on selection type:

- **Main Toolbar**: Drawing tools, color/size, undo/redo, "New at Layer" input - always visible
- **Image Toolbar**: Appears when single image selected - Flip H/V, Rotate, Duplicate, Layer controls (4), Reset, Delete (11 buttons total)
- **Stroke Toolbar**: Appears when stroke(s) selected - Duplicate, Layer controls (4), Delete (6 buttons total)
- **Multi-Selection Toolbar**: Appears for mixed/multiple selections - Duplicate, Layer controls (4), Delete (6 buttons total)

**Key Design**: Layer manipulation buttons (Front/Back/Up/Down) are **NOT** in main toolbar - they only appear in context toolbars when objects are selected.

**Module**: `infinite_whiteboard_toolbars.js` - Manages toolbar visibility with `updateForSelection()` decision logic

**Unified Operations**:
- `duplicateSelection()` - Works for images, strokes, or mixed selections
- `deleteSelection()` - Works for any selection type

See `.DOCS/reference/INFINITE_WHITEBOARD_CONTEXT_TOOLBARS.md` for full documentation and `.DOCS/reference/INFINITE_WHITEBOARD_TOOLBARS_FLOW.txt` for visual flow diagram.

### Unified Copy/Paste Behavior (v2.16+)

**CRITICAL**: All cut/copy/paste operations now use the **batch operations bar** exclusively. The floating action bar is deprecated.

**Selection Model**:

- **Single-click**: Adds item to batch selection (shows batch operations bar in sticky header)
- **Ctrl+click**: Toggles item in batch selection
- **Shift+click**: Range selection
- **Double-click**: Opens item

**Batch Operations Bar** (in sticky header):

- Cut/Copy/Paste/Delete buttons work for 1 or more items
- Always visible when items selected OR clipboard has data
- Count badge shows number of selected items
- Checkboxes appear on selected items

**Code Pattern**:

```javascript
// All operations use window.batchSelected array
window.batchSelected = []; // Array of {type, id, card}
window.selected = null; // DEPRECATED: kept for compatibility

// Single click now adds to batch
const item = { type, id, card };
const existsInBatch = window.batchSelected.find(
  (s) => s.type === item.type && s.id === item.id
);
if (existsInBatch) removeBatchItem(item);
else addBatchItem(item);
```

**Keyboard Shortcuts**: Ctrl+C/X/V, Delete, Ctrl+A, Escape - all work through batch selection.

**HTMX Integration**: Dynamic content (pasted items) automatically gets event listeners attached via `htmx:afterSwap` events. The `window.attachCardClickListeners()` function is globally exposed for manual attachment when needed.

See `.DOCS/reference/UNIFIED_COPY_PASTE_BEHAVIOR.md` and `.DOCS/reference/HTMX_CLIPBOARD_FIX.md` for full implementation details.

## Common Pitfalls

1. **JSON Column Updates**: Always use `flag_modified(obj, 'column_name')` after modifying JSON columns or changes won't persist.

   ```python
   from sqlalchemy.orm.attributes import flag_modified
   user.user_prefs['theme'] = 'dark'
   flag_modified(user, 'user_prefs')
   db.session.commit()
   ```

2. **LONGTEXT Character Set**: Content columns must use `LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci` to support emoji/unicode in large documents.

3. **Image References**: Always use `/static/uploads/images/{filename}` URLs. System handles deduplication transparently via `utils.py` functions (`save_data_uri_images_for_user`, `copy_images_to_user`).

4. **Migration Order**: Check column existence before adding. TEXT columns preferred over VARCHAR for descriptions to avoid truncation on large content.

5. **Blueprint Registration**: All blueprints must be imported in `blueprints/__init__.py` and added to `bps` list. Missing import = 404 errors on routes.

6. **HTMX Event Listeners**: Dynamic content needs event listeners re-attached. Use `window.attachCardClickListeners()` or listen for `htmx:afterSwap` events.

7. **Storage Quota Tracking**: Always update `User.total_data_size` when adding/removing images or file content. Use `calculate_copy_size_for_item()` for accurate byte counts.

## Key Files Reference

### Essential Files
- `flask_app.py` - App initialization, blueprint registration, session config
- `config.py` - All configuration constants (DB, API keys, LLM settings)
- `extensions.py` - Shared SQLAlchemy `db` and `login_manager` instances
- `providers.py` - LLM provider abstraction (Groq, OpenRouter, etc.)
- `blueprints/p2/utils.py` - Image handling, AI inline helpers, file operations
- `blueprints/p2/models.py` - Core data models (User, Folder, File)
- `blueprints/p2/folder_routes.py` - Folder operations (create, move, copy, send-to)
- `init_db.py` - Database initialization with test users

### Documentation Structure (`.DOCS/reference/`)

**130+ reference documents** organized into 11 subdirectories for easy discovery:

**Directory Organization**:
- **`migrations/`** - Database schema changes, Note/Board to File migration, JSON mappings
- **`whiteboard/`** - MioDraw documentation (12 modules, 29 shapes, multi-page, export/import)
- **`infinite-whiteboard/`** - Infinite canvas with context toolbars, layers, transformations
- **`miobook/`** - MioBook v2.0 modular blocks (markdown, todo, code, editorjs, atrament)
- **`file-types/`** - Individual file type implementations (Toast UI, Monaco, Luckysheet, Editor.js)
- **`batch-operations/`** - Multi-select, cut/copy/paste, clipboard, keyboard shortcuts
- **`ui-ux/`** - Telemetry panel, asset viewer, dual-arrow sidebar, CSS theming, HTMX patterns
- **`backup-export/`** - ZIP backup, JSONL export, image deduplication workflows
- **`configuration/`** - Python module config (not .env), provider abstraction
- **`quick-reference/`** - Fast lookup guides (HTMX, config constants, shape categories)
- **`features/`** - Folder operations, public sharing, file pinning, graph workspace, tutorials

**How to Use**:
```
Need whiteboard info? → .DOCS/reference/whiteboard/
Adding file type? → .DOCS/reference/file-types/FILE_TYPE_DISCRIMINATORS.md
HTMX integration? → .DOCS/reference/ui-ux/HTMX_QUICK_REFERENCE.md
Database migration? → .DOCS/reference/migrations/
MioBook blocks? → .DOCS/reference/miobook/MIOBOOK_V2_ARCHITECTURE.md
```

**Index**: See `.DOCS/reference/README.md` for complete directory structure and usage guidelines.

**Pattern**: Most docs include code examples, visual diagrams, and "CRITICAL" callouts for gotchas.

## Deployment Notes

Originally deployed on PythonAnywhere. Current setup: local Windows development with MySQL.

**Connection pooling** configured in `flask_app.py`:

```python
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
    'pool_timeout': 20,
    'max_overflow': 0
}
```

**Session lifetime**: 30 days via `app.permanent_session_lifetime`.
