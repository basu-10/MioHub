"""
Regression coverage for the whiteboard (Atrament) block sizing logic.
Ensures the handler keeps canvas dimensions in sync with its container to
prevent cursor misalignment or dead drawing zones.
"""
from pathlib import Path


def test_atrament_handler_uses_parent_dimensions():
    repo_root = Path(__file__).resolve().parents[2]
    js_path = repo_root / "static" / "js" / "miobook" / "atrament_handler.js"
    content = js_path.read_text(encoding="utf-8")

    # Basic guardrails to ensure responsive sizing stays in place
    assert "#sizeCanvas" in content
    assert "getBoundingClientRect" in content
    assert "canvas.style.width" in content
    assert "canvas.width = targetWidth" in content
    assert "canvas.height = targetHeight" in content
