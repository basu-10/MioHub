import config
from providers import LLMClient


def test_llmclient_summarizer_uses_openrouter():
    client = LLMClient(use_summarizer=True)

    assert client.provider == "openrouter"
    assert client.model == config.SUMMARIZATION_MODEL
    assert client.url.endswith("/chat/completions")
    assert "Authorization" in client.headers


def test_llmclient_chat_accepts_overrides(monkeypatch):
    captured = {}

    def fake_post(url, json, headers, timeout):
        captured["url"] = url
        captured["payload"] = json
        captured["headers"] = headers
        captured["timeout"] = timeout

        class DummyResponse:
            def raise_for_status(self):
                return None

            def json(self):
                return {"choices": [{"message": {"content": "ok"}}]}

        return DummyResponse()

    monkeypatch.setattr("providers.requests.post", fake_post)

    client = LLMClient(provider="openrouter", model="custom-model")
    response = client.chat(
        messages=[{"role": "user", "content": "hi"}],
        temperature=0.4,
        max_tokens=64,
        timeout=10,
    )

    assert response == "ok"
    assert captured["payload"]["model"] == "custom-model"
    assert captured["payload"]["temperature"] == 0.4
    assert captured["payload"]["max_tokens"] == 64
    assert captured["timeout"] == 10
