import pytest

from blueprints.p2.models import File
from blueprints.p3.chat_attachment_service import (
    convert_docx_to_note_html,
    build_summary_title,
    count_words,
    compute_text_hash,
)
from blueprints.p3.routes import build_attachment_open_url


def test_convert_docx_to_note_html(tmp_path):
    pytest.importorskip("docx")
    from docx import Document

    doc = Document()
    doc.add_paragraph("Hello world")
    doc.add_paragraph("Second line")
    sample_path = tmp_path / "sample.docx"
    doc.save(sample_path)

    html_content = convert_docx_to_note_html(str(sample_path))

    assert "<p>Hello world</p>" in html_content
    assert "<p>Second line</p>" in html_content


def test_build_attachment_open_url_prefers_note_editor(app):
    with app.test_request_context():
        note_file = File(id=42, type="proprietary_note")
        assert build_attachment_open_url(note_file).endswith("/edit_note/42")


def test_build_attachment_open_url_falls_back_to_view(app):
    with app.test_request_context():
        pdf_file = File(id=99, type="pdf")
        assert build_attachment_open_url(pdf_file).endswith("/p2/files/99/view")


def test_build_summary_title_uses_double_underscore_suffix():
    assert build_summary_title("report.pdf") == "report.pdf__summary.md"
    assert build_summary_title("notes") == "notes__summary.md"


def test_count_words_handles_empty_and_text():
    assert count_words("") == 0
    assert count_words("one two three") == 3
    assert count_words(" spaced   words ") == 2


def test_compute_text_hash_changes_with_content():
    h1 = compute_text_hash("alpha")
    h2 = compute_text_hash("alpha")
    h3 = compute_text_hash("beta")
    assert h1 == h2
    assert h1 != h3
