from pathlib import Path

from PyPDF2 import PdfWriter

from blueprints.p2 import pdf_utils


def _make_pdf(path: Path):
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    with path.open('wb') as fp:
        writer.write(fp)


def test_save_pdf_dedup(monkeypatch, tmp_path):
    pdf_dir = tmp_path / "pdfs"
    monkeypatch.setattr(pdf_utils, "PDF_UPLOAD_FOLDER", str(pdf_dir))

    src_pdf = tmp_path / "source.pdf"
    _make_pdf(src_pdf)

    name1, bytes_added1, stored_size1, page_count1, file_hash1 = pdf_utils.save_pdf_for_user(src_pdf, user_id=42)
    name2, bytes_added2, stored_size2, page_count2, file_hash2 = pdf_utils.save_pdf_for_user(src_pdf, user_id=42)

    stored_path = pdf_dir / name1

    assert stored_path.exists()
    assert name1 == name2
    assert file_hash1 == file_hash2
    assert bytes_added1 == stored_size1
    assert bytes_added2 == 0  # dedup hit
    assert stored_size1 == stored_size2
    assert page_count1 == page_count2
