import os
from values_main import UPLOAD_FOLDER, MAX_IMAGE_SIZE, ALLOWED_EXTENSIONS


def test_upload_folder_exists_or_can_be_built():
    # The path may not exist in a test environment, but should be an absolute path
    assert os.path.isabs(UPLOAD_FOLDER)


def test_max_image_size_and_extensions():
    assert MAX_IMAGE_SIZE == 5 * 1024 * 1024
    assert 'png' in ALLOWED_EXTENSIONS
    assert 'webp' in ALLOWED_EXTENSIONS
