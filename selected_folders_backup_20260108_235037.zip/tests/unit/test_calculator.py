import pytest
from calculator import Calculator


def test_sanitize_removes_bad_chars():
    c = Calculator("2 + 2; import os")
    assert c.sanitize() == "2+2importos" or c.sanitize() == "2+2importos"  # allow letters but not spaces


def test_basic_evaluate():
    c = Calculator("2+2")
    assert c.evaluate() == "4"


def test_power_operator_and_rounding():
    c = Calculator("2^3")
    assert c.evaluate() == "8"

    c2 = Calculator("5.0")
    assert c2.evaluate() == "5"


def test_custom_functions_and_delimiter():
    # profit(cp, sp) with custom pipe delimiter
    c = Calculator("profit(10|20)")
    assert c.evaluate() == "1"

    c2 = Calculator("tax(100|15)")
    assert c2.evaluate() == "15"

    c3 = Calculator("markup(100|15)")
    assert c3.evaluate() == "115"


def test_math_functions():
    assert Calculator("sqrt(16)").evaluate() == "4"
    assert Calculator("ln(e)").evaluate() == "1"


def test_unsafe_eval_returns_error():
    # Attempt to evaluate something that should fail (division by zero)
    assert Calculator("1/0").evaluate() == "Error"
    # Unknown identifiers should error
    assert Calculator("__import__('os').system('echo nope')").evaluate() == "Error"
