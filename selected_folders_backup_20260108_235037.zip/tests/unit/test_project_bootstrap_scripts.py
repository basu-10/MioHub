import pytest

import project_reset
import project_update


def test_quote_mysql_identifier_escapes_backticks():
    assert project_reset._quote_mysql_identifier("simple") == "`simple`"
    assert project_reset._quote_mysql_identifier("a`b") == "`a``b`"


def test_build_drop_table_statements_chunks_and_quotes():
    tables = ["t1", "t2", "t3"]
    stmts = project_reset.build_drop_table_statements(tables, chunk_size=2)
    assert stmts == ["DROP TABLE IF EXISTS `t1`, `t2`;", "DROP TABLE IF EXISTS `t3`;"]


def test_build_drop_table_statements_rejects_bad_chunk_size():
    with pytest.raises(ValueError):
        project_reset.build_drop_table_statements(["t"], chunk_size=0)


def test_format_bytes():
    assert project_reset._format_bytes(None) == "?"
    assert project_reset._format_bytes(0) == "0 B"
    assert project_reset._format_bytes(1023) == "1023 B"
    assert project_reset._format_bytes(1024) == "1.00 KB"


def test_pick_unique_username_prefers_preferred_when_available():
    assert project_update.pick_unique_username({"a", "b"}, "c") == "c"


def test_pick_unique_username_suffixes_when_taken():
    assert project_update.pick_unique_username({"defaultuser"}, "defaultuser") == "defaultuser2"
    assert (
        project_update.pick_unique_username({"defaultuser", "defaultuser2"}, "defaultuser")
        == "defaultuser3"
    )
