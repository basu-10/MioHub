from flask import url_for

from blueprints.p3.routes import build_attachment_open_url


class _DummyFile:
    def __init__(self, file_id, file_type):
        self.id = file_id
        self.type = file_type


def test_build_attachment_open_url_for_code_file(app):
    with app.test_request_context():
        dummy_file = _DummyFile(42, 'code')
        assert build_attachment_open_url(dummy_file) == url_for('file.view_file', file_id=42)


def test_build_attachment_open_url_for_note_file(app):
    with app.test_request_context():
        dummy_file = _DummyFile(7, 'note')
        assert build_attachment_open_url(dummy_file) == url_for('notes.edit_note', note_id=7)


def test_build_attachment_open_url_none_file(app):
    with app.test_request_context():
        assert build_attachment_open_url(None) is None
