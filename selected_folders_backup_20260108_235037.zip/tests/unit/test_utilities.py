import os
import tempfile
import types

import pytest

import utilities_main as utils


class DummyFolder:
    def __init__(self, name, parent=None):
        self.name = name
        self.parent = parent

    def __repr__(self):
        return f"DummyFolder({self.name})"


def test_build_folder_breadcrumb_chain():
    root = DummyFolder("root")
    child = DummyFolder("child", parent=root)
    grandchild = DummyFolder("grandchild", parent=child)

    chain = utils.build_folder_breadcrumb(grandchild)
    assert chain == [root, child, grandchild]


def test_calculate_content_size_and_empty():
    assert utils.calculate_content_size("abc") == len("abc".encode("utf-8"))
    assert utils.calculate_content_size("") == 0
    assert utils.calculate_content_size(None) == 0


def test_calculate_image_size(tmp_path):
    f = tmp_path / "img.bin"
    data = b"HELLO"
    f.write_bytes(data)
    size = utils.calculate_image_size(str(f))
    assert size == len(data)

    # Non-existent file
    assert utils.calculate_image_size(str(f) + "-no") == 0


def test_check_guest_limit_blocks_and_allows(monkeypatch):
    messages = []

    # patch flash so we can observe messages
    monkeypatch.setattr(utils, 'flash', lambda *args, **kwargs: messages.append(args), raising=True)

    class User:
        def __init__(self, user_type, total_data_size):
            self.user_type = user_type
            self.total_data_size = total_data_size

    # Guest user over limit
    guest = User('guest', 50 * 1024 * 1024)
    # additional size 1 byte pushes over
    res = utils.check_guest_limit(guest, 1)
    assert res is False
    assert messages, "Expected a flash message when over limit"

    messages.clear()

    # Guest user below limit
    guest2 = User('guest', 1024)
    res2 = utils.check_guest_limit(guest2, 1024)
    assert res2 is True
    assert not messages

    # Non-guest user unaffected
    user = User('regular', 100)
    assert utils.check_guest_limit(user, 50) is True


def test_update_user_data_size_and_commit(dummy_db, monkeypatch):
    class User:
        def __init__(self, total_data_size=None):
            self.total_data_size = total_data_size

    user = User(total_data_size=100)
    # Ensure the db fixture patched utilities_main.db
    utils.update_user_data_size(user, 200)
    assert user.total_data_size == 300
    assert dummy_db.committed is True
