"""
Unit tests for table parsing functionality.
Tests separator detection for various table formats (tab, pipe, comma, etc.).
"""
import pytest


def detect_table_separator(text):
    """Detect the most likely separator for table data."""
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    
    separators = ['\t', '|', ',', ';', '  ']
    best_separator = None
    max_columns = 0
    
    for sep in separators:
        column_counts = []
        for line in lines[:min(3, len(lines))]:
            cols = [col.strip() for col in line.split(sep) if col.strip()]
            if len(cols) > 1:
                column_counts.append(len(cols))
        
        if column_counts and len(set(column_counts)) <= 1:
            avg_cols = sum(column_counts) / len(column_counts)
            if avg_cols > max_columns:
                max_columns = avg_cols
                best_separator = sep
    
    return best_separator, max_columns


def test_tab_separated():
    """Test detection of tab-separated tables."""
    input_text = 'Name\tAge\tCity\nJohn\t25\tNew York\nJane\t30\tBoston'
    separator, cols = detect_table_separator(input_text)
    assert separator == '\t'
    assert cols == 3


def test_pipe_separated():
    """Test detection of pipe-separated tables."""
    input_text = 'Product | Price | Stock\nLaptop | $1200 | 5\nMouse | $25 | 50'
    separator, cols = detect_table_separator(input_text)
    assert separator == '|'
    assert cols == 3


def test_comma_separated():
    """Test detection of comma-separated tables."""
    input_text = 'Item,Quantity,Total\nApples,10,$5.00\nBananas,5,$2.50'
    separator, cols = detect_table_separator(input_text)
    assert separator == ','
    assert cols == 3


def test_double_space_separated():
    """Test detection of double-space-separated tables."""
    input_text = 'First  Last  Score\nAlice  Smith  95\nBob  Jones  87'
    separator, cols = detect_table_separator(input_text)
    assert separator == '  '
    assert cols == 3
