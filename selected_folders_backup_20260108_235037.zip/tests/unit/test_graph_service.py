import json
from blueprints.p2.models import File, GraphNode, GraphEdge, GraphNodeAttachment
from blueprints.p2.graph_service import ensure_workspace, serialize_graph, rebuild_content_snapshot, ALLOWED_ATTACHMENT_TYPES


def test_graph_serialization_roundtrip(db):
    # Setup user + folder
    from blueprints.p2.models import User, Folder

    user = User.query.filter_by(username='graph_user').first()
    if not user:
        user = User(username='graph_user')
        db.session.add(user)
        db.session.flush()

    folder = Folder.query.filter_by(name='root', user_id=user.id, parent_id=None).first()
    if not folder:
        folder = Folder(name='root', user_id=user.id)
        db.session.add(folder)
        db.session.flush()

    graph_file = File(
        owner_id=user.id,
        folder_id=folder.id,
        type='proprietary_graph',
        title='Graph Demo',
        content_json={"nodes": [], "edges": [], "settings": {}, "metadata": {}},
    )
    db.session.add(graph_file)
    db.session.flush()

    workspace = ensure_workspace(graph_file, user.id, folder.id)

    node_a = GraphNode(graph_id=workspace.id, title='A', position_json={"x": 1, "y": 2})
    node_b = GraphNode(graph_id=workspace.id, title='B', position_json={"x": 3, "y": 4})
    db.session.add_all([node_a, node_b])
    db.session.flush()

    edge = GraphEdge(graph_id=workspace.id, source_node_id=node_a.id, target_node_id=node_b.id, label='flows')
    db.session.add(edge)
    db.session.flush()

    attachment = GraphNodeAttachment(node_id=node_a.id, attachment_type='file', file_id=graph_file.id)
    db.session.add(attachment)
    db.session.flush()

    delta = rebuild_content_snapshot(graph_file)
    db.session.commit()

    assert delta >= 0
    snapshot = serialize_graph(workspace)
    assert snapshot['nodes'] and snapshot['edges']
    assert snapshot['nodes'][0]['attachments']
    # Ensure content_json mirrors snapshot
    assert json.dumps(graph_file.content_json, sort_keys=True) == json.dumps(snapshot, sort_keys=True)
