import os
import sys
import ast
import fnmatch
import pytest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

# Exclude common directories that aren't source code
EXCLUDE_DIRS = {
    '.venv', '__pycache__', 'database_backups', 'node_modules', 'tests', 'test', 'static', 'templates', '.git', '.DOCS', '.pytest_cache', '.github', 'images'
}

EXCLUDE_FILES = {
    # these are integration/test helper files or items that intentionally may not be valid Python
}


def iter_python_files(root=ROOT):
    """Yield python file paths in the workspace, excluding os-ignored directories."""
    for dirpath, dirnames, filenames in os.walk(root):
        # Remove excluded directories from walking
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]

        for f in filenames:
            if fnmatch.fnmatch(f, '*.py'):
                full = os.path.join(dirpath, f)
                # skip this test module itself to avoid self-compilation race
                if os.path.abspath(full) == os.path.abspath(__file__):
                    continue
                if os.path.basename(full) in EXCLUDE_FILES:
                    continue
                yield full


@pytest.mark.parametrize('path', list(iter_python_files()))
def test_file_compiles(path):
    """Every python file in the repo (excluding virtualenv and helpers) should compile.

    This avoids accidental syntax errors in committed files. We compile without
    importing to avoid side effects.
    """
    rel = os.path.relpath(path, ROOT)
    with open(path, 'rb') as fh:
        source = fh.read()

    # Try parsing with AST; compile would also work but ast.parse gives better error
    try:
        ast.parse(source, filename=rel)
    except SyntaxError as exc:
        pytest.fail(f"SyntaxError in {rel}: {exc}")
