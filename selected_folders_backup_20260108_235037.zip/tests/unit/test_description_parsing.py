"""Unit tests for description parsing helper (multi-description + plain text)."""

from blueprints.p2.utils import parse_description_field


def test_dict_numeric_keys():
    descriptions, readable, failed = parse_description_field('{"1":"First","2":"Second","10":"Tenth"}')
    assert descriptions == [("1", "First"), ("2", "Second"), ("10", "Tenth")]
    assert "First" in readable and "Tenth" in readable
    assert failed is False


def test_dict_string_keys():
    descriptions, readable, failed = parse_description_field('{"a":"Alpha","b":"Beta"}')
    assert descriptions == [("a", "Alpha"), ("b", "Beta")]
    assert "Alpha" in readable and "Beta" in readable
    assert failed is False


def test_list_values():
    descriptions, readable, failed = parse_description_field('["One", "Two"]')
    assert descriptions == [("1", "One"), ("2", "Two")]
    assert "One" in readable and "Two" in readable
    assert failed is False


def test_plain_string_passthrough():
    descriptions, readable, failed = parse_description_field("Saved from Chrome extension")
    assert descriptions is None
    assert readable == "Saved from Chrome extension"
    assert failed is False


def test_json_string_literal_passthrough():
    descriptions, readable, failed = parse_description_field('"Single value"')
    assert descriptions is None
    assert readable == "Single value"
    assert failed is False


def test_invalid_json_falls_back_to_text():
    descriptions, readable, failed = parse_description_field('{not:json}')
    assert descriptions is None
    assert readable == '{not:json}'
    assert failed is False


def test_non_string_type_marks_failure():
    descriptions, readable, failed = parse_description_field(12345)
    assert descriptions is None
    assert readable == ''
    assert failed is True
