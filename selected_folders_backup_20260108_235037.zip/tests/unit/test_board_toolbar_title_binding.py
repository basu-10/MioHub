from flask import render_template
from blueprints.p2.models import File


def test_board_toolbar_prefills_title_and_description(app):
    """Ensure toolbar inputs use the file context values rather than defaults."""
    with app.test_request_context('/'):
        file_obj = File(title="Custom Board", metadata_json={"description": "Sketch notes"})
        html = render_template('p2/board_toolbar_partial.html', file=file_obj)

    assert 'id="board-title"' in html
    assert 'value="Custom Board"' in html
    assert 'value="Sketch notes"' in html
