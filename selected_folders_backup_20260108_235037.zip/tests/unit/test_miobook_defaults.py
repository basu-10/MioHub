import re

from blueprints.p2.file_route_proprietary_blocks import (
    extract_miobook_submission,
    generate_default_miobook_title,
)


class DummyForm(dict):
    def get(self, key, default=None, type=None):
        value = super().get(key, default)
        if type and value is not None:
            try:
                return type(value)
            except Exception:
                return default
        return value


class DummyRequest:
    def __init__(self, is_json=False, json_payload=None, form=None):
        self.is_json = is_json
        self._json_payload = json_payload or {}
        self.form = form or DummyForm()

    def get_json(self, silent=False):
        return self._json_payload


def test_generate_default_miobook_title_matches_convention():
    title = generate_default_miobook_title()
    assert re.match(r"^MioBook \d{4}-\d{2}-\d{2} \d{2}:\d{2}$", title)


def test_extract_miobook_submission_prefers_json_payload():
    req = DummyRequest(
        is_json=True,
        json_payload={"title": " Custom Title ", "folder_id": "42", "content_json": "{}"},
    )

    title, folder_id, content_json_raw = extract_miobook_submission(req)

    assert title == "Custom Title"
    assert folder_id == 42
    assert content_json_raw == "{}"


def test_extract_miobook_submission_falls_back_to_form_data():
    form = DummyForm(title=" Form Title ", folder_id="7", content_json='{"blocks": []}')
    req = DummyRequest(is_json=False, form=form)

    title, folder_id, content_json_raw = extract_miobook_submission(req)

    assert title == "Form Title"
    assert folder_id == 7
    assert content_json_raw == '{"blocks": []}'
