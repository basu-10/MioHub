"""
Unit tests for template display logic in folder views.
Tests conditions for showing descriptions and previews.
"""
import pytest
from types import SimpleNamespace


def should_show_descriptions(note, display_prefs):
    """Replicate folder_view.html logic for description display."""
    if getattr(note, 'descriptions', None) and display_prefs.get('show_previews'):
        return True
    if getattr(note, 'description', None) and display_prefs.get('show_previews') and getattr(note, 'description_parse_failed', False):
        return True
    return False


def test_no_description_shown_when_empty():
    """Empty JSON should not show description section."""
    note = SimpleNamespace(descriptions=None, description='["", "   "]', description_parse_failed=False)
    display_prefs = {'show_previews': True}
    assert not should_show_descriptions(note, display_prefs)


def test_no_description_shown_when_none():
    """Missing description should not show section."""
    note = SimpleNamespace(descriptions=None, description=None, description_parse_failed=False)
    display_prefs = {'show_previews': True}
    assert not should_show_descriptions(note, display_prefs)


def test_show_warning_for_invalid_json():
    """Invalid JSON should show warning."""
    note = SimpleNamespace(descriptions=None, description='Not JSON content', description_parse_failed=True)
    display_prefs = {'show_previews': True}
    assert should_show_descriptions(note, display_prefs)


def test_show_description_for_valid_list():
    """Valid parsed descriptions should be shown."""
    note = SimpleNamespace(descriptions=[('1', 'One'), ('2', 'Two')], description='["One","Two"]', description_parse_failed=False)
    display_prefs = {'show_previews': True}
    assert should_show_descriptions(note, display_prefs)
