"""
Pytest configuration and fixtures for the Flask multi-product application.
Provides app context, database setup, and common test utilities.
"""
import pytest
import os
import sys
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from flask_app import app as flask_app
from extensions import db as _db
from blueprints.p2.models import User, Folder


# Unit test fixtures (for isolated testing)
class DummyUser:
    def __init__(self, user_type='regular', total_data_size=0):
        self.user_type = user_type
        self.total_data_size = total_data_size


@pytest.fixture
def dummy_user():
    """Dummy user for unit tests without database."""
    return DummyUser()


class DummyDB:
    def __init__(self):
        self.session = self
        self.committed = False

    def commit(self):
        self.committed = True


@pytest.fixture
def dummy_db(monkeypatch):
    """Dummy database for unit tests without real DB."""
    db = DummyDB()
    monkeypatch.setattr('utilities_main.db', db, raising=False)
    return db


@pytest.fixture(autouse=True)
def no_external_flash(monkeypatch):
    """Replace the real Flask `flash` with a no-op to avoid test pollution."""
    monkeypatch.setattr('utilities_main.flash', lambda *args, **kwargs: None, raising=False)
    return lambda *args, **kwargs: None


# Integration test fixtures (with real Flask app and database)
@pytest.fixture(scope='session')
def app():
    """Create Flask application for testing."""
    flask_app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': flask_app.config.get('SQLALCHEMY_DATABASE_URI'),
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-key',
        'SQLALCHEMY_EXPIRE_ON_COMMIT': False,
        'LOGIN_DISABLED': True,  # Allow routes to run in tests without full login flow
    })
    
    yield flask_app


@pytest.fixture(scope='function')
def db(app):
    """Provide database session with rollback after each test.
    
    IMPORTANT: Does NOT clear existing data. Tests run against the current
    database state to allow testing with data created by devs posing as users.
    Each test transaction is rolled back to prevent test changes from persisting.
    """
    with app.app_context():
        # Do NOT drop/create tables - preserve existing data
        yield _db
        _db.session.rollback()
        _db.session.remove()


@pytest.fixture(scope='function')
def client(app):
    """Provide Flask test client."""
    return app.test_client()


@pytest.fixture(scope='function')
def runner(app):
    """Provide Flask CLI test runner."""
    return app.test_cli_runner()
