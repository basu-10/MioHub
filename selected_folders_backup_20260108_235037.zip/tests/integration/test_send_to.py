"""
Integration tests for send-to/copy functionality between users.
Tests copying notes and folders with proper data isolation and storage quota tracking.
"""
import pytest
from flask_login import login_user
from blueprints.p2.models import User, Folder, File, db
from blueprints.p2.folder_ops import copy_file_to_user, copy_folder_recursive, copy_folder_to_user


@pytest.mark.integration
def test_copy_note_and_folder_to_user(app, db):
    """Test copying notes and folders between users maintains data integrity."""
    # Get or create test users
    sender = User.query.filter_by(username='sender_test').first()
    if not sender:
        sender = User(username='sender_test', email='sender@test.local')
        db.session.add(sender)
        db.session.flush()
    
    receiver = User.query.filter_by(username='receiver_test').first()
    if not receiver:
        receiver = User(username='receiver_test', email='receiver@test.local')
        db.session.add(receiver)
        db.session.flush()
    
    db.session.commit()

    # Create roots
    root_sender = Folder(name='root', user_id=sender.id)
    root_receiver = Folder(name='root', user_id=receiver.id)
    db.session.add_all([root_sender, root_receiver])
    db.session.commit()

    # Create a folder with a note and a board for sender
    gift_folder = Folder(name='Gift', user_id=sender.id, parent_id=root_sender.id)
    db.session.add(gift_folder)
    db.session.commit()

    note = File(title='Hello', content_html='This is a note', owner_id=sender.id, folder_id=gift_folder.id, type='proprietary_note')
    board = File(title='A Board', content_json={}, owner_id=sender.id, folder_id=gift_folder.id, type='proprietary_whiteboard')
    db.session.add_all([note, board])
    db.session.commit()

    # Copy note directly to receiver
    new_note, bytes_added = copy_file_to_user(note.id, receiver.id, sender_username=sender.username)
    assert new_note is not None
    assert new_note.owner_id == receiver.id
    assert new_note.folder_id is not None
    assert new_note.title == note.title

    # Copy folder to receiver
    cloned, bytes_added = copy_folder_to_user(gift_folder.id, receiver.id, sender_username=sender.username)
    assert cloned is not None
    assert cloned.user_id == receiver.id
    assert cloned.name == gift_folder.name
    # check that files exist inside the cloned folder with preserved titles
    found_files = File.query.filter_by(folder_id=cloned.id).all()
    cloned_titles = {f.title for f in found_files}
    assert note.title in cloned_titles
    assert board.title in cloned_titles


@pytest.mark.integration
def test_public_copy_folder_preserves_titles(app, db):
    """Public/external copies should keep original titles instead of appending a copy suffix."""
    # Setup sender and receiver (re-use if they already exist)
    sender = User.query.filter_by(username='public_sender').first()
    if not sender:
        sender = User(username='public_sender', email='public_sender@test.local')
        db.session.add(sender)
        db.session.flush()

    receiver = User.query.filter_by(username='public_receiver').first()
    if not receiver:
        receiver = User(username='public_receiver', email='public_receiver@test.local')
        db.session.add(receiver)
        db.session.flush()

    db.session.commit()

    sender_root = Folder.query.filter_by(user_id=sender.id, parent_id=None).first()
    if not sender_root:
        sender_root = Folder(name='root', user_id=sender.id)
        db.session.add(sender_root)

    receiver_root = Folder.query.filter_by(user_id=receiver.id, parent_id=None).first()
    if not receiver_root:
        receiver_root = Folder(name='root', user_id=receiver.id)
        db.session.add(receiver_root)

    db.session.commit()

    shared_folder = Folder(name='Shared Folder', user_id=sender.id, parent_id=sender_root.id)
    db.session.add(shared_folder)
    db.session.flush()

    shared_file = File(title='Original Doc', content_text='hi', owner_id=sender.id, folder_id=shared_folder.id, type='markdown')
    db.session.add(shared_file)
    db.session.commit()

    with app.test_request_context():
        login_user(receiver, force=True)
        cloned = copy_folder_recursive(shared_folder.id, receiver_root.id, allow_external=True)

    assert cloned is not None
    assert cloned.user_id == receiver.id
    assert cloned.name == shared_folder.name
    cloned_files = File.query.filter_by(folder_id=cloned.id).all()
    assert any(f.title == shared_file.title for f in cloned_files)
