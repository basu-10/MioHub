import pytest

from blueprints.p2.models import User, Folder, db
from blueprints.p2 import folder_ops


class _DummyUser:
    def __init__(self, user_id):
        self.id = user_id


def test_root_uniqueness_enforced(db, app):
    with app.app_context():
        user = User(username='u_root', password_hash='x')
        db.session.add(user)
        db.session.commit()

        first_root = Folder(name='root', user_id=user.id, parent_id=None, is_root=True)
        db.session.add(first_root)
        db.session.commit()

        dup_root = Folder(name='root-copy', user_id=user.id, parent_id=None, is_root=True)
        db.session.add(dup_root)

        with pytest.raises(Exception):
            db.session.commit()
        db.session.rollback()


def test_root_deletion_blocked(db, app, monkeypatch):
    with app.app_context():
        user = User(username='deleter', password_hash='x')
        db.session.add(user)
        db.session.commit()

        root = Folder(name='root', user_id=user.id, parent_id=None, is_root=True)
        child = Folder(name='child', user_id=user.id, parent_id=root.id)
        db.session.add_all([root, child])
        db.session.commit()

        monkeypatch.setattr('blueprints.p2.folder_ops.current_user', _DummyUser(user.id), raising=False)

        # Deleting the root should be blocked
        assert folder_ops.delete_folder(root.id) is False

        # Non-root deletion still works
        assert folder_ops.delete_folder(child.id) is True


def test_create_folder_returns_existing_root(db, app, monkeypatch):
    with app.app_context():
        user = User(username='creator', password_hash='x')
        db.session.add(user)
        db.session.commit()

        existing_root = Folder(name='root', user_id=user.id, parent_id=None, is_root=True)
        db.session.add(existing_root)
        db.session.commit()

        monkeypatch.setattr('blueprints.p2.folder_ops.current_user', _DummyUser(user.id), raising=False)

        # Requesting another root returns the already-existing one
        returned = folder_ops.create_folder('root', is_root=True)
        assert returned.id == existing_root.id

        # Creating a normal folder under root remains allowed
        normal = folder_ops.create_folder('child', parent_id=existing_root.id)
        assert normal.parent_id == existing_root.id
