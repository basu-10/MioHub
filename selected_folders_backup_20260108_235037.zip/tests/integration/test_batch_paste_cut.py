import json

import pytest

from blueprints.p2.models import User, Folder, File


@pytest.mark.integration
def test_batch_cut_returns_html_and_moves_file(client, db, app, monkeypatch):
    with app.app_context():
        user = User(username='batchcut_user', password_hash='x')
        db.session.add(user)
        db.session.commit()

        source = Folder(name='source', user_id=user.id)
        target = Folder(name='target', user_id=user.id)
        db.session.add_all([source, target])
        db.session.commit()

        file_obj = File(owner_id=user.id, folder_id=source.id, type='markdown', title='Doc', content_text='hi')
        db.session.add(file_obj)
        db.session.commit()

        monkeypatch.setattr('blueprints.p2.folder_routes.current_user', user, raising=False)
        monkeypatch.setattr('blueprints.p2.folder_ops.current_user', user, raising=False)

        response = client.post(
            '/folders/batch_paste',
            data={
                'items': json.dumps([{'type': 'markdown', 'id': file_obj.id}]),
                'action': 'cut',
                'target_folder': str(target.id),
                'htmx': 'true'
            }
        )

        assert response.status_code == 200
        data = response.get_json()
        assert data['success'] is True
        assert data['success_count'] == 1
        assert len(data.get('new_items_html', [])) == 1

        moved = File.query.get(file_obj.id)
        assert moved.folder_id == target.id