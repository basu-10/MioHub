"""Ensure chat session folders show deduplicated attachments saved elsewhere."""
from werkzeug.security import generate_password_hash

from blueprints.p2.models import User, Folder, File
from blueprints.p3.models import ChatSession, ChatAttachment
from blueprints.p3.chat_attachment_service import get_or_create_session_folder


def test_session_folder_shows_deduped_attachments(client, app, db):
    username = 'test_chat_folder_attachments'
    password = 'password123'

    with app.app_context():
        user = User.query.filter_by(username=username).first()
        if user is None:
            user = User(username=username, email=f"{username}@example.com")
            user.password_hash = generate_password_hash(password)
            db.session.add(user)
            db.session.flush()

        chat_session = ChatSession(user_id=user.id, title='Attachment visibility')
        db.session.add(chat_session)
        db.session.flush()

        session_folder = get_or_create_session_folder(chat_session.id, user.id)

        root = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
        if not root:
            root = Folder(name='root', user_id=user.id)
            db.session.add(root)
            db.session.flush()

        other_folder = Folder(name='other-assets', user_id=user.id, parent_id=root.id)
        db.session.add(other_folder)
        db.session.flush()

        file_content = 'Example content for attachment'
        file_record = File(
            owner_id=user.id,
            folder_id=other_folder.id,
            type='code',
            title='Critical response.txt',
            content_text=file_content,
            metadata_json={'original_filename': 'Critical response.txt'}
        )
        db.session.add(file_record)
        db.session.flush()

        attachment = ChatAttachment(
            session_id=chat_session.id,
            file_id=file_record.id,
            original_filename=file_record.title,
            file_type='txt',
            file_size=len(file_content),
            file_hash='hash-chat-folder',
            summary_status='pending'
        )
        db.session.add(attachment)
        db.session.commit()

        session_folder_id = session_folder.id
        user_id = user.id
        chat_session_id = chat_session.id
        file_record_id = file_record.id
        attachment_id = attachment.id
        other_folder_id = other_folder.id

    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(user_id)
        sess['_fresh'] = True

    resp = client.get(f'/folders/{session_folder_id}')
    assert resp.status_code == 200
    assert b'Critical response.txt' in resp.data

    with app.app_context():
        db.session.query(ChatAttachment).filter_by(id=attachment_id).delete()
        db.session.query(File).filter_by(id=file_record_id).delete()
        db.session.query(ChatSession).filter_by(id=chat_session_id).delete()
        db.session.query(Folder).filter(Folder.id.in_([other_folder_id, session_folder_id])).delete()
        db.session.commit()
