"""
Test login redirect behavior - user should be redirected to originally requested page after login
"""
import pytest
from flask import url_for
from blueprints.p2.models import User
from werkzeug.security import generate_password_hash


def test_login_redirects_to_next_parameter(client, app):
    """Test that after login, user is redirected to the 'next' URL parameter"""
    
    with app.app_context():
        # Create a test user
        test_user = User(
            username='redirect_test_user',
            password_hash=generate_password_hash('testpass123'),
            user_type='user'
        )
        from extensions import db
        db.session.add(test_user)
        db.session.commit()
        
        try:
            # Try to access a protected route - should redirect to login with next parameter
            target_url = '/dashboard'
            response = client.get(target_url, follow_redirects=False)
            
            # Should redirect to login page
            assert response.status_code == 302
            assert '/login' in response.location
            
            # Now login with the next parameter
            login_url_with_next = f'/login?next={target_url}'
            response = client.post(
                login_url_with_next,
                data={
                    'username': 'redirect_test_user',
                    'password': 'testpass123'
                },
                follow_redirects=False
            )
            
            # Should redirect to the originally requested URL
            assert response.status_code == 302
            assert target_url in response.location or response.location == f'http://localhost{target_url}'
            
        finally:
            # Cleanup
            db.session.delete(test_user)
            db.session.commit()


def test_login_without_next_redirects_to_dashboard(client, app):
    """Test that login without 'next' parameter redirects to default dashboard"""
    
    with app.app_context():
        # Create a test user
        test_user = User(
            username='dashboard_test_user',
            password_hash=generate_password_hash('testpass123'),
            user_type='user'
        )
        from extensions import db
        db.session.add(test_user)
        db.session.commit()
        
        try:
            # Login without next parameter
            response = client.post(
                '/login',
                data={
                    'username': 'dashboard_test_user',
                    'password': 'testpass123'
                },
                follow_redirects=False
            )
            
            # Should redirect to dashboard
            assert response.status_code == 302
            assert '/dashboard' in response.location or 'dashboard' in response.location
            
        finally:
            # Cleanup
            db.session.delete(test_user)
            db.session.commit()


def test_login_rejects_external_redirects(client, app):
    """Test that login does not redirect to external URLs (security check)"""
    
    with app.app_context():
        # Create a test user
        test_user = User(
            username='security_test_user',
            password_hash=generate_password_hash('testpass123'),
            user_type='user'
        )
        from extensions import db
        db.session.add(test_user)
        db.session.commit()
        
        try:
            # Try to login with malicious external next parameter
            response = client.post(
                '/login?next=https://evil.com/steal-data',
                data={
                    'username': 'security_test_user',
                    'password': 'testpass123'
                },
                follow_redirects=False
            )
            
            # Should NOT redirect to external URL, should go to dashboard instead
            assert response.status_code == 302
            assert 'evil.com' not in response.location
            assert '/dashboard' in response.location or 'dashboard' in response.location
            
        finally:
            # Cleanup
            db.session.delete(test_user)
            db.session.commit()
