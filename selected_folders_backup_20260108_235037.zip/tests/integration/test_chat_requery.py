import pytest
from datetime import datetime, timedelta

from extensions import db as _db, login_manager
from blueprints.p2.models import User
from blueprints.p3.models import ChatSession, ChatMessage


@pytest.mark.integration
def test_requery_replaces_previous_reply(app, db, client, monkeypatch):
    previous_login_disabled = app.config.get('LOGIN_DISABLED', False)
    app.config['LOGIN_DISABLED'] = False
    login_manager._login_disabled = False

    try:
        with app.app_context():
            user = User(username='requery_user', user_type='user')
            _db.session.add(user)
            _db.session.commit()

            session = ChatSession(user_id=user.id, title='Original chat')
            _db.session.add(session)
            _db.session.commit()

            user_msg = ChatMessage(
                session_id=session.id,
                model='test-model',
                role='user',
                content='old question'
            )
            old_ai = ChatMessage(
                session_id=session.id,
                model='test-model',
                role='assistant',
                content='old answer',
                created_at=datetime.utcnow() + timedelta(seconds=1)
            )
            _db.session.add_all([user_msg, old_ai])
            _db.session.commit()

            session_id = session.id
            user_id = user.id
            user_message_id = user_msg.id

        with client.session_transaction() as sess:
            sess['_user_id'] = str(user_id)
            sess['current_chat_session_id'] = session_id

        monkeypatch.setattr('blueprints.p3.routes._generate_ai_reply', lambda msg, memory, model: 'new reply')

        resp = client.post('/chat/requery', json={
            'message_id': user_message_id,
            'message': 'updated question',
            'memory': ['m1']
        })

        assert resp.status_code == 200
        data = resp.get_json()
        assert data['reply'] == 'new reply'
        assert data['assistant_message_id']

        with app.app_context():
            messages = ChatMessage.query.filter_by(session_id=session_id).order_by(ChatMessage.created_at.asc()).all()
            assert len(messages) == 2
            user_message = next(m for m in messages if m.role == 'user')
            assistant_message = next(m for m in messages if m.role == 'assistant')
            assert user_message.content == 'updated question'
            assert assistant_message.content == 'new reply'
            assert assistant_message.id == data['assistant_message_id']
    finally:
        app.config['LOGIN_DISABLED'] = previous_login_disabled
        login_manager._login_disabled = previous_login_disabled


@pytest.mark.integration
def test_report_message_succeeds(app, db, client):
    previous_login_disabled = app.config.get('LOGIN_DISABLED', False)
    app.config['LOGIN_DISABLED'] = False
    login_manager._login_disabled = False

    try:
        with app.app_context():
            user = User(username='report_user', user_type='user')
            _db.session.add(user)
            _db.session.commit()

            session = ChatSession(user_id=user.id, title='Report chat')
            _db.session.add(session)
            _db.session.commit()

            message = ChatMessage(
                session_id=session.id,
                model='test-model',
                role='assistant',
                content='bad answer'
            )
            _db.session.add(message)
            _db.session.commit()

            session_id = session.id
            user_id = user.id
            message_id = message.id

        with client.session_transaction() as sess:
            sess['_user_id'] = str(user_id)
            sess['current_chat_session_id'] = session_id

        resp = client.post('/chat/report', json={'message_id': message_id, 'reason': 'inaccurate response'})

        assert resp.status_code == 200
        assert resp.get_json()['status'] == 'ok'
    finally:
        app.config['LOGIN_DISABLED'] = previous_login_disabled
        login_manager._login_disabled = previous_login_disabled
