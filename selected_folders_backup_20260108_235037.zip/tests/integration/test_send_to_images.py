"""
Integration tests for image deduplication and copy functionality.
Tests hash-based image deduplication when copying between users.
"""
import pytest
from pathlib import Path
from types import SimpleNamespace

from blueprints.p2.utils import copy_images_to_user, calculate_copy_size_for_item
from values_main import UPLOAD_FOLDER


@pytest.mark.integration
def test_copy_images_to_user(tmp_path):
    """Test copying images between users with hash-based deduplication."""
    test_upload_dir = Path(UPLOAD_FOLDER)
    test_upload_dir.mkdir(parents=True, exist_ok=True)

    # Create a sample image file
    sample_file = test_upload_dir / "test_image_send.jpg"
    with open(sample_file, 'wb') as f:
        f.write(b"A" * 1024 * 10)  # 10KB file

    receiver_id = 99999

    # Copy image to receiver
    filename = sample_file.name
    mapping, added_bytes = copy_images_to_user([filename], receiver_id)

    # Mapping should include the original filename and added_bytes should be non-zero
    assert filename in mapping
    assert added_bytes >= 1024 * 10
    
    # Clean up created files
    for new_fn in mapping.values():
        new_path = test_upload_dir / new_fn
        if new_path.exists():
            new_path.unlink()
    if sample_file.exists():
        sample_file.unlink()


@pytest.mark.integration
def test_calculate_copy_size_for_note_with_image(tmp_path):
    """Test calculating storage size for notes containing images."""
    test_upload_dir = Path(UPLOAD_FOLDER)
    test_upload_dir.mkdir(parents=True, exist_ok=True)
    
    sample_file = test_upload_dir / "calc_test_image.jpg"
    data = b"B" * 2048
    with open(sample_file, 'wb') as f:
        f.write(data)
    
    # Create fake note with image
    content = f'<p>Hi</p><img src="/static/uploads/images/{sample_file.name}" />'
    note = SimpleNamespace(content=content, description=None)
    
    receiver_id = 99998
    total, breakdown = calculate_copy_size_for_item('note', note, receiver_id)
    
    assert breakdown['image_bytes'] >= 2048
    assert total >= breakdown['image_bytes']
    
    # Cleanup
    if sample_file.exists():
        sample_file.unlink()


@pytest.mark.integration
def test_copy_images_to_user_idempotent(tmp_path):
    """Test that copying the same image twice doesn't double-count storage."""
    test_upload_dir = Path(UPLOAD_FOLDER)
    test_upload_dir.mkdir(parents=True, exist_ok=True)
    
    sample_file = test_upload_dir / "idempotent_image.jpg"
    data = b"C" * 4096
    with open(sample_file, 'wb') as f:
        f.write(data)
    
    receiver_id = 99997
    orig = sample_file.name
    
    # First copy
    mapping1, added1 = copy_images_to_user([orig], receiver_id)
    # Second copy (should be deduplicated)
    mapping2, added2 = copy_images_to_user([orig], receiver_id)
    
    # Should map to same file and add 0 bytes on second copy
    assert mapping1[orig] == mapping2[orig]
    assert added2 == 0
    
    # Cleanup
    for fn in mapping1.values():
        p = test_upload_dir / fn
        if p.exists():
            p.unlink()
    if sample_file.exists():
        sample_file.unlink()
