import json
from datetime import datetime
from werkzeug.security import generate_password_hash

from blueprints.p2.models import User, Folder, File
from blueprints.p2.graph_service import ensure_workspace


def _seed_graph(db):
    user = User.query.filter_by(username='owner_graph').first()
    if not user:
        user = User(username='owner_graph')
        db.session.add(user)
        db.session.flush()

    folder = Folder.query.filter_by(name='root', user_id=user.id, parent_id=None).first()
    if not folder:
        folder = Folder(name='root', user_id=user.id)
        db.session.add(folder)
        db.session.flush()

    graph_file = File(
        owner_id=user.id,
        folder_id=folder.id,
        type='proprietary_graph',
        title=f'Shared Graph {datetime.utcnow().isoformat()}',
        content_json={"nodes": [], "edges": [], "settings": {}, "metadata": {}},
        is_public=True,
    )
    db.session.add(graph_file)
    db.session.flush()
    ensure_workspace(graph_file, user.id, folder.id)
    db.session.commit()
    return graph_file


def test_public_graph_data_access(db, client):
    graph_file = _seed_graph(db)
    resp = client.get(f"/graph/{graph_file.id}/data")
    assert resp.status_code == 200
    payload = resp.get_json()
    assert payload['ok'] is True
    assert payload['graph']['file_id'] == graph_file.id


def test_private_graph_requires_auth(db, client):
    graph_file = _seed_graph(db)
    # flip to private
    graph_file.is_public = False
    db.session.commit()

    resp = client.get(f"/graph/{graph_file.id}/data")
    assert resp.status_code == 403


def test_graph_creation_redirects_to_workspace(client, app, db):
    username = 'graph_creator'
    password = 'password123'

    with app.app_context():
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User(username=username, email='graph@test.com')
            user.password_hash = generate_password_hash(password)
            db.session.add(user)
            db.session.flush()
            root = Folder(name='root', user_id=user.id)
            db.session.add(root)
            db.session.commit()
            root_folder_id = root.id
        else:
            user.password_hash = generate_password_hash(password)
            if not Folder.query.filter_by(user_id=user.id, parent_id=None).first():
                db.session.add(Folder(name='root', user_id=user.id))
            db.session.commit()
            root = Folder.query.filter_by(user_id=user.id, parent_id=None).first()
            root_folder_id = root.id

        user_id = user.id

    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(user_id)
        sess['_fresh'] = True
        sess['current_folder_id'] = root_folder_id

    payload = {
        'title': 'Graph Redirect',
        'description': 'Ensure redirect to workspace',
        'content': json.dumps({"nodes": [], "edges": [], "settings": {}, "metadata": {}})
    }

    response = client.post('/p2/files/new/proprietary_graph', data=payload, follow_redirects=False)

    assert response.status_code == 302
    location = response.headers.get('Location', '')

    with app.app_context():
        graph_file = File.query.filter_by(owner_id=user_id, title='Graph Redirect', type='proprietary_graph').order_by(File.id.desc()).first()
        assert graph_file is not None
        expected_path = f"/graph/{graph_file.id}"
        assert expected_path in location
        assert graph_file.graph_workspace is not None
