import json
import uuid

import pytest

from blueprints.p2.models import File, Folder, Notification, User, db


@pytest.mark.integration
def test_batch_delete_folder_uses_file_model_sizes(app, client):
    with app.app_context():
        username = f"batch_delete_folder_{uuid.uuid4().hex[:8]}"
        user = User(username=username, email=f"{username}@example.com", password_hash="x")
        db.session.add(user)
        db.session.commit()

        root = Folder(name="batch-delete-root", user_id=user.id, parent_id=None, is_root=True)
        child = Folder(name="child-folder", user_id=user.id, parent_id=root.id)
        db.session.add_all([root, child])
        db.session.commit()

        note = File(
            owner_id=user.id,
            folder_id=child.id,
            type="proprietary_note",
            title="Folder Note",
            content_html="<p>hello</p>",
        )
        board = File(
            owner_id=user.id,
            folder_id=child.id,
            type="proprietary_whiteboard",
            title="Folder Board",
            content_json={"shapes": []},
        )
        db.session.add_all([note, board])
        db.session.commit()

        with client.session_transaction() as sess:
            sess["_user_id"] = str(user.id)
            sess["_fresh"] = True

        try:
            resp = client.post(
                "/folders/batch_delete",
                data={"items": json.dumps([{"type": "folder", "id": child.id}])},
            )

            assert resp.status_code == 200
            data = resp.get_json()
            assert data["success"] is True
            assert data.get("failed_count") == 0

            assert Folder.query.get(child.id) is None
            assert File.query.get(note.id) is None
            assert File.query.get(board.id) is None
        finally:
            Notification.query.filter_by(user_id=user.id).delete()

            leftover_child = Folder.query.get(child.id)
            if leftover_child:
                db.session.delete(leftover_child)

            leftover_note = File.query.get(note.id)
            leftover_board = File.query.get(board.id)
            for obj in (leftover_note, leftover_board):
                if obj:
                    db.session.delete(obj)

            db.session.delete(root)
            db.session.delete(user)
            db.session.commit()
