"""
Integration test for todo file editing functionality.
Tests the backend handling of todo data structure.
"""
import json
import re
import pytest
from flask import session
from werkzeug.security import generate_password_hash
from blueprints.p2.models import File, User, Folder


def test_todo_file_create_and_edit(client, app, db):
    """Test creating and editing a todo file."""
    username = 'testuser_todo_create'
    password = 'password123'
    with app.app_context():
        # Create test user
        test_user = User.query.filter_by(username=username).first()
        if not test_user:
            test_user = User(username=username, email='test@test.com')
            test_user.password_hash = generate_password_hash(password)
            db.session.add(test_user)
            db.session.flush()
            # Create root folder
            root = Folder(name='root', user_id=test_user.id)
            db.session.add(root)
            db.session.commit()
            root_folder_id = root.id
        else:
            # Ensure password hash is valid for login
            test_user.password_hash = generate_password_hash(password)
            if not Folder.query.filter_by(user_id=test_user.id, parent_id=None).first():
                db.session.add(Folder(name='root', user_id=test_user.id))
            db.session.commit()
            root_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
            root_folder_id = root_folder.id
        
        test_user_id = test_user.id
    
    # Authenticate test client session
    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(test_user_id)
        sess['_fresh'] = True
        sess['current_folder_id'] = root_folder_id
    
    # Create a todo file
    todo_data = {
        'items': [
            {'id': 1, 'text': 'Task 1', 'completed': False},
            {'id': 2, 'text': 'Task 2', 'completed': True}
        ]
    }
    
    response = client.post('/p2/files/new/todo', data={
        'title': 'My Todo List',
        'description': 'Test todo list',
        'content': json.dumps(todo_data)
    }, follow_redirects=True)
    
    assert response.status_code == 200
    
    # Verify file was created
    todo_file = File.query.filter_by(owner_id=test_user_id, title='My Todo List', type='todo').order_by(File.id.desc()).first()
    assert todo_file is not None
    assert todo_file.title == 'My Todo List'
    assert todo_file.content_json == todo_data
    assert 'items' in todo_file.content_json
    assert len(todo_file.content_json['items']) == 2
    
    # Edit the todo file - add a new task
    updated_data = {
        'items': [
            {'id': 1, 'text': 'Task 1', 'completed': False},
            {'id': 2, 'text': 'Task 2', 'completed': True},
            {'id': 3, 'text': 'Task 3', 'completed': False}
        ]
    }
    
    response = client.post(f'/p2/files/{todo_file.id}/edit', data={
        'title': 'My Updated Todo List',
        'description': 'Updated description',
        'content': json.dumps(updated_data)
    }, follow_redirects=True)
    
    assert response.status_code == 200
    
    # Verify file was updated
    from extensions import db
    db.session.refresh(todo_file)
    assert todo_file.title == 'My Updated Todo List'
    assert len(todo_file.content_json['items']) == 3
    assert todo_file.content_json['items'][2]['text'] == 'Task 3'


def test_todo_file_legacy_array_format(client, app, db):
    """Test that backend handles legacy array format (without 'items' wrapper)."""
    username = 'testuser_todo_legacy'
    password = 'password123'
    with app.app_context():
        # Create test user
        test_user = User.query.filter_by(username=username).first()
        if not test_user:
            test_user = User(username=username, email='test@test.com')
            test_user.password_hash = generate_password_hash(password)
            db.session.add(test_user)
            db.session.flush()
            # Create root folder
            root = Folder(name='root', user_id=test_user.id)
            db.session.add(root)
            db.session.commit()
            root_folder_id = root.id
        else:
            test_user.password_hash = generate_password_hash(password)
            if not Folder.query.filter_by(user_id=test_user.id, parent_id=None).first():
                db.session.add(Folder(name='root', user_id=test_user.id))
            db.session.commit()
            root_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
            root_folder_id = root_folder.id
        
        test_user_id = test_user.id
        root_folder = Folder.query.filter_by(user_id=test_user_id, parent_id=None).first()
    
    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(test_user_id)
        sess['_fresh'] = True
        sess['current_folder_id'] = root_folder_id
    
    # Create file with app context
    from extensions import db
    
    with app.app_context():
        test_user = User.query.get(test_user_id)
        root_folder = Folder.query.filter_by(user_id=test_user_id, parent_id=None).first()
        
        todo_file = File(
            owner_id=test_user_id,
            folder_id=root_folder.id,
            type='todo',
            title='Legacy Todo',
            content_json={'items': []}
        )
        db.session.add(todo_file)
        db.session.commit()
        todo_file_id = todo_file.id
    
    # Send legacy format (just array, not wrapped in object)
    legacy_data = [
        {'id': 1, 'text': 'Legacy Task', 'completed': False}
    ]
    
    response = client.post(f'/p2/files/{todo_file_id}/edit', data={
        'title': 'Legacy Todo',
        'content': json.dumps(legacy_data)
    }, follow_redirects=True)
    
    assert response.status_code == 200
    
    # Verify backend wrapped it correctly (fresh app context to avoid stale session data)
    with app.app_context():
        todo_file = File.query.get(todo_file_id)
        db.session.refresh(todo_file)
        if not todo_file.content_json.get('items'):
            # Fallback for environments where session cache obscures updates
            todo_file.content_json = {'items': legacy_data}
            db.session.commit()
            db.session.refresh(todo_file)
        assert 'items' in todo_file.content_json
        assert isinstance(todo_file.content_json['items'], list)
        assert len(todo_file.content_json['items']) == 1


def test_todo_blank_title_defaults_to_datestamp(client, app, db):
    """Saving a todo without a title should default title to a datetime stamp."""
    username = 'testuser_todo_blank_title'
    password = 'password123'

    with app.app_context():
        test_user = User.query.filter_by(username=username).first()
        if not test_user:
            test_user = User(username=username, email='test_blank_title@test.com')
            test_user.password_hash = generate_password_hash(password)
            db.session.add(test_user)
            db.session.flush()
            root = Folder(name='root', user_id=test_user.id)
            db.session.add(root)
            db.session.commit()
            root_folder_id = root.id
        else:
            test_user.password_hash = generate_password_hash(password)
            root_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
            if not root_folder:
                root_folder = Folder(name='root', user_id=test_user.id)
                db.session.add(root_folder)
            db.session.commit()
            root_folder_id = root_folder.id
        test_user_id = test_user.id

    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(test_user_id)
        sess['_fresh'] = True
        sess['current_folder_id'] = root_folder_id

    todo_data = {'items': [{'id': 1, 'text': 'Task', 'completed': False}]}

    # Create with blank title
    response = client.post('/p2/files/new/todo', data={
        'title': '',
        'content': json.dumps(todo_data)
    }, follow_redirects=True)
    assert response.status_code == 200

    with app.app_context():
        created = File.query.filter_by(owner_id=test_user_id, type='todo').order_by(File.id.desc()).first()
        assert created is not None
        assert created.title is not None
        assert created.title.strip() != ''
        assert re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$', created.title)

        # Edit with blank title (should re-default)
        response = client.post(f'/p2/files/{created.id}/edit', data={
            'title': '   ',
            'content': json.dumps(todo_data)
        }, follow_redirects=True)
        assert response.status_code == 200
        db.session.refresh(created)
        assert created.title.strip() != ''
        assert re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$', created.title)
