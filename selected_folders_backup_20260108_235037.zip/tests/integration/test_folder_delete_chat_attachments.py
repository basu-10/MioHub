import uuid
from flask_login import login_user, logout_user

from blueprints.p2.folder_ops import delete_folder
from blueprints.p2.models import User, Folder, File, db
from blueprints.p3.models import ChatSession, ChatAttachment


def test_delete_folder_removes_chat_attachments(app, db):
    """Ensure folder deletion removes chat attachments referencing its files."""
    with app.app_context():
        username = f"test_user_{uuid.uuid4().hex[:8]}"
        user = User(username=username, email=f"{username}@example.com", user_type='user')
        db.session.add(user)
        db.session.commit()

        root = Folder(name='root', user_id=user.id, is_root=True)
        db.session.add(root)
        db.session.commit()

        target_folder = Folder(name='to_delete', user_id=user.id, parent_id=root.id)
        db.session.add(target_folder)
        db.session.commit()

        file_in_target = File(
            owner_id=user.id,
            folder_id=target_folder.id,
            type='markdown',
            title='doc',
            content_text='hi',
        )
        db.session.add(file_in_target)
        db.session.commit()

        file_outside = File(
            owner_id=user.id,
            folder_id=root.id,
            type='markdown',
            title='other',
            content_text='ok',
        )
        db.session.add(file_outside)
        db.session.commit()

        chat_session = ChatSession(user_id=user.id, title='chat', session_folder_id=root.id)
        db.session.add(chat_session)
        db.session.commit()

        attach_in_target = ChatAttachment(
            session_id=chat_session.id,
            file_id=file_in_target.id,
            original_filename='doc.md',
            file_type='md',
            file_size=2,
            file_hash='hash1',
        )
        attach_summary_ref = ChatAttachment(
            session_id=chat_session.id,
            file_id=file_outside.id,
            summary_file_id=file_in_target.id,
            original_filename='other.md',
            file_type='md',
            file_size=2,
            file_hash='hash2',
        )
        db.session.add_all([attach_in_target, attach_summary_ref])
        db.session.commit()

        with app.test_request_context():
            login_user(user)
            assert delete_folder(target_folder.id) is True
            logout_user()

        # Attachment for deleted file is removed
        assert ChatAttachment.query.get(attach_in_target.id) is None

        # Attachments that only reference the deleted file in summary are retained but cleared
        remaining = ChatAttachment.query.get(attach_summary_ref.id)
        assert remaining is not None
        assert remaining.summary_file_id is None

        # Cleanup any temporary objects to avoid polluting shared test DB
        db.session.delete(remaining)
        db.session.delete(file_outside)
        db.session.delete(chat_session)
        db.session.delete(root)
        db.session.delete(user)
        db.session.commit()
