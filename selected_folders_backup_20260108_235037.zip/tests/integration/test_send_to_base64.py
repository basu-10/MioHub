"""
Integration tests for copying notes with base64 embedded images.
Tests conversion of data URIs to file-based storage during copy operations.
"""
import pytest
from pathlib import Path
import os

from blueprints.p2.models import User, Folder, File, db
from blueprints.p2.folder_ops import copy_file_to_user
from values_main import UPLOAD_FOLDER


@pytest.mark.integration
def test_copy_note_base64_image(app, tmp_path, monkeypatch):
    """Test that base64 images are converted to files when copying notes."""
    with app.app_context():
        # Get or create test users
        sender = User.query.filter_by(username='base_sender').first()
        if not sender:
            sender = User(username='base_sender', email='base_sender@test.local')
            db.session.add(sender)
            db.session.flush()
        
        receiver = User.query.filter_by(username='base_receiver').first()
        if not receiver:
            receiver = User(username='base_receiver', email='base_receiver@test.local')
            db.session.add(receiver)
            db.session.flush()
        
        db.session.commit()

        root_sender = Folder(name='root', user_id=sender.id)
        root_receiver = Folder(name='root', user_id=receiver.id)
        db.session.add_all([root_sender, root_receiver])
        db.session.commit()

        # Create a note with a base64 image (small 1x1 PNG)
        b64_png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVQI12NgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII='
        content = f'<p>Hi</p><img src="data:image/png;base64,{b64_png}" />'
        note = File(title='Base64 Image Note', content_html=content, owner_id=sender.id, folder_id=root_sender.id, type='note')
        db.session.add(note)
        db.session.commit()

        # Ensure upload folder exists
        Path(UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)

        # Copy the note to receiver
        new_note, bytes_added = copy_file_to_user(note.id, receiver.id, sender_username=sender.username)
        assert new_note is not None
        assert '/static/uploads/images/' in (new_note.content_html or '')

        # Check that the file exists in upload folder (receiver prefixed file)
        files = [f for f in os.listdir(UPLOAD_FOLDER) if f.startswith(f'{receiver.id}_')]
        assert len(files) >= 1
        
        # Cleanup
        for f in files:
            os.remove(os.path.join(UPLOAD_FOLDER, f))
