import pytest
from datetime import datetime, timedelta

from blueprints.p2.models import User, Folder, File, db


@pytest.mark.integration
def test_recent_items_pagination(client, app):
    with app.app_context():
        user = User(username='recents_user_pagination', password_hash='x')
        db.session.add(user)
        db.session.commit()

        root = Folder(name='recents-root', user_id=user.id, parent_id=None, is_root=True)
        db.session.add(root)
        db.session.commit()

        base_time = datetime.utcnow()
        files = []
        for idx in range(7):
            file_obj = File(
                owner_id=user.id,
                folder_id=root.id,
                type='markdown',
                title=f'Recent {idx}',
                content_text='content',
                last_modified=base_time - timedelta(minutes=idx)
            )
            db.session.add(file_obj)
            files.append(file_obj)
        db.session.commit()

        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['_fresh'] = True

        try:
            resp = client.get('/folders/recent-items', query_string={'offset': 0, 'limit': 5})
            assert resp.status_code == 200
            body = resp.get_data(as_text=True)
            assert 'Recent 0' in body
            assert 'Recent 4' in body
            assert 'Recent 5' not in body
            assert 'Show more' in body
            assert 'recently-modified-load-more' in body

            resp2 = client.get('/folders/recent-items', query_string={'offset': 5, 'limit': 5})
            assert resp2.status_code == 200
            body2 = resp2.get_data(as_text=True)
            assert 'Recent 5' in body2
            assert 'Recent 6' in body2
            assert 'Show more' not in body2
            assert 'You are up to date.' in body2
        finally:
            for file_obj in files:
                db.session.delete(file_obj)
            db.session.delete(root)
            db.session.delete(user)
            db.session.commit()
