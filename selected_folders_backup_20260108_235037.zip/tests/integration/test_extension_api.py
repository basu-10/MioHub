from datetime import datetime, timedelta
from uuid import uuid4

from blueprints.p2.models import File, Folder, User


def _create_guest_user(app, db, total_size=0):
    token = f"token-{uuid4().hex}"
    username = f"ext-user-{uuid4().hex[:8]}"
    with app.app_context():
        user = User(
            username=username,
            user_type='guest',
            total_data_size=total_size,
            api_token=token,
            api_token_expires=datetime.utcnow() + timedelta(days=1),
        )
        db.session.add(user)
        db.session.commit()
        return user.id, token


def _cleanup_user(app, db, user_id):
    with app.app_context():
        File.query.filter_by(owner_id=user_id).delete()
        Folder.query.filter_by(user_id=user_id).delete()
        user = User.query.get(user_id)
        if user:
            db.session.delete(user)
        db.session.commit()


def test_save_text_creates_web_clippings_and_updates_quota(app, client, db):
    user_id, token = _create_guest_user(app, db, total_size=0)

    response = client.post(
        '/api/extension/save-content',
        headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        },
        json={
            'type': 'text',
            'content': 'Hello from extension',
            'title': 'Test Clip',
            'url': 'https://example.com',
            'page_title': 'Example Domain',
        },
    )

    data = response.get_json()
    assert response.status_code == 200
    assert data['success'] is True

    with app.app_context():
        folder = Folder.query.filter_by(user_id=user_id, name='Web Clippings').first()
        assert folder is not None

        saved_file = File.query.filter_by(id=data['file']['id'], owner_id=user_id).first()
        assert saved_file is not None

        user = User.query.get(user_id)
        assert user.total_data_size > 0

    _cleanup_user(app, db, user_id)


def test_guest_quota_blocks_save_when_over_limit(app, client, db):
    guest_cap = 50 * 1024 * 1024
    user_id, token = _create_guest_user(app, db, total_size=guest_cap - 10)

    response = client.post(
        '/api/extension/save-content',
        headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        },
        json={
            'type': 'text',
            'content': 'a' * 200,
            'title': 'Over quota check',
            'url': 'https://example.com/over',
            'page_title': 'Example Domain',
        },
    )

    data = response.get_json()
    assert response.status_code == 403
    assert data['success'] is False
    assert 'quota' in (data.get('error', '').lower())

    with app.app_context():
        files = File.query.filter_by(owner_id=user_id).all()
        assert len(files) == 0

    _cleanup_user(app, db, user_id)
