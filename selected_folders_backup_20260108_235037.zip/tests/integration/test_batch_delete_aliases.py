import json
import uuid
import pytest

from blueprints.p2.models import User, Folder, File, Notification, db


@pytest.mark.integration
def test_batch_delete_accepts_legacy_note_and_board_aliases(app, client):
    with app.app_context():
        username = f"batch_delete_alias_user_{uuid.uuid4().hex[:8]}"
        user = User(username=username, email=f"{username}@example.com", password_hash='x')
        db.session.add(user)
        db.session.commit()

        root = Folder(name='batch-delete-root', user_id=user.id, parent_id=None, is_root=True)
        db.session.add(root)
        db.session.commit()

        note = File(
            owner_id=user.id,
            folder_id=root.id,
            type='proprietary_note',
            title='Legacy Note',
            content_html='<p>hello</p>',
        )
        board = File(
            owner_id=user.id,
            folder_id=root.id,
            type='proprietary_whiteboard',
            title='Legacy Board',
            content_json={'shapes': []},
        )
        db.session.add_all([note, board])
        db.session.commit()

        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['_fresh'] = True

        try:
            resp = client.post(
                '/folders/batch_delete',
                data={
                    'items': json.dumps([
                        {'type': 'note', 'id': note.id},
                        {'type': 'board', 'id': board.id},
                    ])
                },
            )

            assert resp.status_code == 200
            data = resp.get_json()
            assert data['success'] is True
            assert data['failed_count'] == 0

            assert File.query.get(note.id) is None
            assert File.query.get(board.id) is None
        finally:
            # Clean up any remaining artifacts to keep shared test DB tidy
            remaining_note = File.query.get(note.id)
            remaining_board = File.query.get(board.id)
            if remaining_note:
                db.session.delete(remaining_note)
            if remaining_board:
                db.session.delete(remaining_board)

            Notification.query.filter_by(user_id=user.id).delete()
            db.session.delete(root)
            db.session.delete(user)
            db.session.commit()
