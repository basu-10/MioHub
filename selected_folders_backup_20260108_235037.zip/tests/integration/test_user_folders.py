"""
Integration test for user folder initialization.
Tests that users are created with root folders and login works correctly.
"""
import pytest
from blueprints.p2.models import User, Folder, db
from werkzeug.security import generate_password_hash


@pytest.mark.integration
def test_user_has_root_folder_on_creation(app):
    """Test that new users are created with a root folder."""
    with app.app_context():
        # Create a new user
        new_user = User(
            username='test_folder_user',
            email='folder_test@example.com',
            password_hash=generate_password_hash('testpass'),
            security_answer='blue'
        )
        db.session.add(new_user)
        db.session.commit()
        
        # Create root folder (this should happen in registration flow)
        root_folder = Folder(name='root', user_id=new_user.id)
        db.session.add(root_folder)
        db.session.commit()
        
        # Verify user has folder
        user = User.query.filter_by(username='test_folder_user').first()
        assert user is not None
        assert len(user.folders) >= 1
        assert any(f.name == 'root' for f in user.folders)
        
        # Cleanup
        db.session.delete(user)
        db.session.commit()


@pytest.mark.integration
def test_all_users_have_folders(app):
    """Test that all existing users have at least one folder."""
    with app.app_context():
        users = User.query.all()
        users_without_folders = [u for u in users if not u.folders]
        
        # All users should have folders after proper initialization
        assert len(users_without_folders) == 0, \
            f"Found {len(users_without_folders)} users without folders"
