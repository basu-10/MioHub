"""Integration tests for folder targeting overrides when creating new files.

Graph Workspace creates files in the same folder as the graph file by passing
?folder_id=... to creation endpoints. The backend should validate ownership and
persist the folder into session so the subsequent POST saves in the right folder.
"""

import pytest
from werkzeug.security import generate_password_hash

from blueprints.p2.models import File, User, Folder


def _ensure_user_with_root(db, username: str, password: str):
    test_user = User.query.filter_by(username=username).first()
    if not test_user:
        test_user = User(username=username, email=f"{username}@test.com")
        test_user.password_hash = generate_password_hash(password)
        db.session.add(test_user)
        db.session.flush()

    # Ensure a root folder exists
    root_folder = Folder.query.filter_by(user_id=test_user.id, parent_id=None).first()
    if not root_folder:
        root_folder = Folder(name='root', user_id=test_user.id)
        db.session.add(root_folder)
        db.session.flush()

    db.session.commit()
    return test_user, root_folder


def test_new_file_folder_override_via_query_param(client, app, db):
    username = 'testuser_folder_override'
    password = 'password123'

    with app.app_context():
        test_user, root = _ensure_user_with_root(db, username, password)

        # Create an additional folder owned by the user
        target_folder = Folder(name='target', user_id=test_user.id, parent_id=root.id)
        db.session.add(target_folder)
        db.session.commit()

        user_id = test_user.id
        root_id = root.id
        target_id = target_folder.id

    # Authenticate test client session
    client.post('/login', data={'username': username, 'password': password})
    with client.session_transaction() as sess:
        sess['_user_id'] = str(user_id)
        sess['_fresh'] = True
        sess['current_folder_id'] = root_id

    # Step 1: GET with folder_id override should update session current_folder_id
    resp = client.get(f'/p2/files/new/markdown?folder_id={target_id}')
    assert resp.status_code == 200

    with client.session_transaction() as sess:
        assert sess.get('current_folder_id') == target_id

    # Step 2: POST without folder_id should now save in the overridden folder
    resp = client.post(
        '/p2/files/new/markdown',
        data={'title': 'Graph Created Markdown', 'content': '# hello'},
        follow_redirects=True,
    )
    assert resp.status_code == 200

    with app.app_context():
        created = (
            File.query.filter_by(owner_id=user_id, type='markdown', title='Graph Created Markdown')
            .order_by(File.id.desc())
            .first()
        )
        assert created is not None
        assert created.folder_id == target_id
