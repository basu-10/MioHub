"""
Test Chat Attachments Service Layer (Phase 3)
Tests service functions and API route logic
"""
import sys
import os
import pytest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from flask import Flask
from extensions import db
from blueprints.p3.models import ChatSession, ChatAttachment
from blueprints.p2.models import User, Folder, File
from blueprints.p3.chat_attachment_service import (
    get_or_create_session_folder,
    check_duplicate_attachment,
)
import config


def test_imports():
    """Test that all imports work correctly"""
    print("=" * 60)
    print("TEST: Import Verification")
    print("=" * 60)
    
    try:
        from blueprints.p3.chat_attachment_service import (
            get_or_create_session_folder,
            check_duplicate_attachment,
            create_attachment_from_upload,
            create_summary_for_attachment
        )
        print("✓ All service functions imported successfully")
        
        from blueprints.p3.routes import (
            upload_attachment,
            summarize_attachment,
            toggle_attachment_active,
            delete_attachment,
            list_attachments,
            allowed_file
        )
        print("✓ All API route functions imported successfully")
        
        from blueprints.p3.models import ChatAttachment
        print("✓ ChatAttachment model imported successfully")
        
        return True
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False


def test_allowed_file():
    """Test file extension validation"""
    print("\n" + "=" * 60)
    print("TEST: File Extension Validation")
    print("=" * 60)
    
    from blueprints.p3.routes import allowed_file
    
    test_cases = [
        ('document.pdf', True),
        ('spreadsheet.xlsx', True),
        ('image.png', True),
        ('script.py', True),
        ('config.yaml', True),
        ('malicious.exe', False),
        ('virus.bat', False),
        ('file.sh', False),
    ]
    
    passed = 0
    for filename, expected in test_cases:
        result = allowed_file(filename)
        status = "✓" if result == expected else "✗"
        print(f"{status} {filename:25s} → {result:5} (expected: {expected})")
        if result == expected:
            passed += 1
    
    print(f"\n{passed}/{len(test_cases)} tests passed")
    return passed == len(test_cases)


def test_folder_service_with_db():
    """Test folder creation service (requires database)"""
    print("\n" + "=" * 60)
    print("TEST: Session Folder Service (Database Integration)")
    print("=" * 60)
    
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    with app.app_context():
        # Check if we have a test user and session
        user = User.query.filter_by(username='testuser').first()
        
        if not user:
            print("⚠️  Test user 'testuser' not found, skipping database test")
            return True
        
        # Check if user has any chat sessions
        session = ChatSession.query.filter_by(user_id=user.id).first()
        
        if not session:
            print("⚠️  No chat sessions found for testuser, skipping database test")
            return True
        
        try:
            # Test get_or_create_session_folder
            folder = get_or_create_session_folder(session.id, user.id)
            
            if folder:
                print(f"✓ Session folder created/retrieved: {folder.name}")
                print(f"  Owner (user_id): {folder.user_id}")
                print(f"  Parent: {folder.parent_id}")
                print(f"  Description: {folder.description[:50]}...")
                
                # Verify folder is linked to session
                session_check = ChatSession.query.get(session.id)
                if session_check.session_folder_id == folder.id:
                    print(f"✓ Session folder properly linked (session.session_folder_id = {folder.id})")
                else:
                    print(f"✗ Session folder not linked correctly")
                    return False
                
                # Test idempotency (calling again should return same folder)
                folder2 = get_or_create_session_folder(session.id, user.id)
                if folder2.id == folder.id:
                    print(f"✓ Idempotent: calling again returns same folder")
                else:
                    print(f"✗ Not idempotent: got different folder on second call")
                    return False
                
                return True
            else:
                print("✗ Failed to create session folder")
                return False
                
        except Exception as e:
            print(f"✗ Database test error: {e}")
            import traceback
            traceback.print_exc()
            return False


def test_attachment_model():
    """Test ChatAttachment model helper methods"""
    print("\n" + "=" * 60)
    print("TEST: ChatAttachment Model Helpers")
    print("=" * 60)
    
    attachment = ChatAttachment()
    attachment.original_filename = "very_long_filename_that_exceeds_thirty_characters_limit.pdf"
    
    display_name = attachment.get_display_name()
    if len(display_name) <= 30 and display_name.endswith('...'):
        print(f"✓ get_display_name() truncates long filenames: {display_name}")
    else:
        print(f"✗ get_display_name() failed to truncate: {display_name}")
        return False
    
    # Test short filename
    attachment.original_filename = "short.pdf"
    display_name = attachment.get_display_name()
    if display_name == "short.pdf":
        print(f"✓ get_display_name() preserves short filenames: {display_name}")
    else:
        print(f"✗ get_display_name() failed for short filename: {display_name}")
        return False
    
    # Test icon mapping
    test_icons = [
        ('pdf', 'fa-file-pdf'),
        ('docx', 'fa-file-word'),
        ('xlsx', 'fa-file-excel'),
        ('py', 'fa-file-code'),
        ('image', 'fa-file-image'),
        ('unknown', 'fa-file'),
    ]
    
    for file_type, expected_icon in test_icons:
        attachment.file_type = file_type
        icon = attachment.get_file_icon()
        status = "✓" if icon == expected_icon else "✗"
        print(f"{status} get_file_icon('{file_type}') → {icon} (expected: {expected_icon})")
        if icon != expected_icon:
            return False
    
    return True


def test_text_attachment_summary_uses_content_text(db, monkeypatch):
    """Ensure text-based attachments summarize without needing a file path."""
    from blueprints.p3.chat_attachment_service import create_summary_for_attachment, get_or_create_session_folder
    from providers import LLMClient

    user = User.query.first()
    if not user:
        pytest.skip("No users available for integration test")

    # Prevent commits from persisting test data
    monkeypatch.setattr(db.session, 'commit', lambda: db.session.flush())
    monkeypatch.setattr(LLMClient, 'chat', lambda self, messages, **kwargs: "stub summary")

    session = ChatSession(user_id=user.id, title='Test session for summary')
    db.session.add(session)
    db.session.flush()

    folder = get_or_create_session_folder(session.id, user.id)

    root = Folder.query.filter_by(user_id=user.id, is_root=True).first() or Folder.query.filter_by(user_id=user.id, parent_id=None).first()
    assert folder.parent_id == Folder.query.filter_by(user_id=user.id, name='MioChat').first().id
    assert Folder.query.filter_by(user_id=user.id, name='MioChat').first().parent_id == root.id

    file_record = File(
        owner_id=user.id,
        folder_id=folder.id,
        type='code',
        title='sample.txt',
        content_text='hello world',
        metadata_json={'original_filename': 'sample.txt'}
    )
    db.session.add(file_record)
    db.session.flush()

    attachment = ChatAttachment(
        session_id=session.id,
        file_id=file_record.id,
        original_filename='sample.txt',
        file_type='txt',
        file_size=len('hello world'),
        file_hash='hash123',
        summary_status='pending'
    )
    db.session.add(attachment)
    db.session.flush()

    summary_file = create_summary_for_attachment(attachment.id)

    assert summary_file.content_text == "stub summary"
    assert attachment.summary_status == 'completed'
    assert summary_file.folder_id == folder.id


def main():
    """Run all tests"""
    print("\n")
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 8 + "CHAT ATTACHMENTS SERVICE TEST SUITE" + " " * 14 + "║")
    print("║" + " " * 15 + "Phase 3: Backend Services" + " " * 17 + "║")
    print("╚" + "=" * 58 + "╝")
    print()
    
    results = []
    
    try:
        results.append(("Import Verification", test_imports()))
        results.append(("File Extension Validation", test_allowed_file()))
        results.append(("ChatAttachment Model Helpers", test_attachment_model()))
        results.append(("Session Folder Service", test_folder_service_with_db()))
        
        print("\n" + "=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        
        for test_name, passed in results:
            status = "✅ PASS" if passed else "❌ FAIL"
            print(f"{status:8s} {test_name}")
        
        all_passed = all(result[1] for result in results)
        
        if all_passed:
            print("\n" + "=" * 60)
            print("✅ ALL TESTS PASSED")
            print("=" * 60)
            print()
            print("Phase 3 Backend Services successfully implemented!")
            print()
            print("Next steps:")
            print("1. Test with actual file uploads via API")
            print("2. Implement Phase 4: Frontend UI")
            print("3. Test summarization with real documents")
            print()
        else:
            print("\n❌ SOME TESTS FAILED")
            print("Please review errors above.")
        
    except Exception as e:
        print(f"\n❌ TEST SUITE FAILED: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
