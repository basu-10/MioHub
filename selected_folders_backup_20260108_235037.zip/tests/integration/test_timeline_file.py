"""
Test timeline file type integration.
Verifies that timeline files can be created, exported, imported, sent, made public, and pinned.
"""
import pytest
import json
from blueprints.p2.models import File, Folder, User


def test_timeline_in_valid_file_types():
    """Test that timeline is in VALID_FILE_TYPES."""
    from blueprints.p2.models import VALID_FILE_TYPES
    assert 'timeline' in VALID_FILE_TYPES, "Timeline should be in VALID_FILE_TYPES"


def test_create_timeline_file(app, db):
    """Test creating a timeline file."""
    with app.app_context():
        # Create test user and folder
        user = User(username='timeline_test_user', email='timeline@test.com')
        db.session.add(user)
        db.session.flush()
        
        folder = Folder(name='Test Folder', user_id=user.id, is_root=True)
        db.session.add(folder)
        db.session.flush()
        
        # Create timeline file
        timeline_data = [
            {
                'id': 'timeline-1',
                'name': 'Project Timeline',
                'description': 'Main project milestones',
                'events': [
                    {'id': 'event-1', 'title': 'Kickoff', 'date': '2024-01-01', 'description': 'Project start'}
                ]
            }
        ]
        
        timeline_file = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='timeline',
            title='My Timeline',
            content_json=timeline_data,
            metadata_json={'description': 'Test timeline'}
        )
        db.session.add(timeline_file)
        db.session.commit()
        
        # Verify file was created
        saved_file = File.query.filter_by(id=timeline_file.id).first()
        assert saved_file is not None
        assert saved_file.type == 'timeline'
        assert saved_file.title == 'My Timeline'
        assert isinstance(saved_file.content_json, list)
        assert len(saved_file.content_json) == 1
        assert saved_file.content_json[0]['name'] == 'Project Timeline'


def test_timeline_export(app, db):
    """Test that timeline files can be exported via JSONL."""
    with app.app_context():
        # Create test user and folder
        user = User(username='timeline_export_user', email='export@test.com')
        db.session.add(user)
        db.session.flush()
        
        folder = Folder(name='Export Folder', user_id=user.id, is_root=True)
        db.session.add(folder)
        db.session.flush()
        
        # Create timeline file
        timeline_data = [{'id': 'tl-1', 'name': 'Test', 'events': []}]
        timeline_file = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='timeline',
            title='Export Test Timeline',
            content_json=timeline_data
        )
        db.session.add(timeline_file)
        db.session.commit()
        
        # Test export functionality by checking VALID_FILE_TYPES usage in routes.py
        # The export_item_jsonl route checks: elif item_type in VALID_FILE_TYPES or item_type == 'file':
        from blueprints.p2.models import VALID_FILE_TYPES
        assert 'timeline' in VALID_FILE_TYPES
        
        # Verify export data structure
        export_data = {
            'type': timeline_file.type,
            'id': timeline_file.id,
            'title': timeline_file.title,
            'content_json': timeline_file.content_json
        }
        assert export_data['type'] == 'timeline'
        assert export_data['content_json'] == timeline_data


def test_timeline_send_to_user(app, db):
    """Test that timeline files can be sent to other users."""
    with app.app_context():
        # Create sender and receiver users
        sender = User(username='sender', email='sender@test.com')
        db.session.add(sender)
        
        receiver = User(username='receiver', email='receiver@test.com')
        db.session.add(receiver)
        db.session.flush()
        
        # Create folders
        sender_folder = Folder(name='Sender Folder', user_id=sender.id, is_root=True)
        db.session.add(sender_folder)
        
        receiver_folder = Folder(name='Receiver Folder', user_id=receiver.id, is_root=True)
        db.session.add(receiver_folder)
        db.session.flush()
        
        # Create timeline file for sender
        timeline_data = [{'id': 'tl-1', 'name': 'Shared Timeline', 'events': []}]
        timeline_file = File(
            owner_id=sender.id,
            folder_id=sender_folder.id,
            type='timeline',
            title='Shared Timeline',
            content_json=timeline_data
        )
        db.session.add(timeline_file)
        db.session.commit()
        
        # Verify timeline is in file_type_aliases (indirectly via copy_file_to_user)
        from blueprints.p2.folder_routes import copy_file_to_user
        
        # Copy the file (this tests the send functionality)
        result = copy_file_to_user(timeline_file.id, receiver.id, sender_username='sender')
        assert result is not None
        new_file, bytes_copied = result
        
        assert new_file is not None
        assert new_file.type == 'timeline'
        assert new_file.owner_id == receiver.id
        assert new_file.title == 'Shared Timeline'
        assert new_file.content_json == timeline_data


def test_timeline_public_flag(app, db):
    """Test that timeline files can be made public."""
    with app.app_context():
        user = User(username='public_test', email='public@test.com')
        db.session.add(user)
        db.session.flush()
        
        folder = Folder(name='Public Folder', user_id=user.id, is_root=True)
        db.session.add(folder)
        db.session.flush()
        
        # Create timeline file
        timeline_file = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='timeline',
            title='Public Timeline',
            content_json=[],
            is_public=False
        )
        db.session.add(timeline_file)
        db.session.commit()
        
        # Make it public
        timeline_file.is_public = True
        db.session.commit()
        
        # Verify
        public_file = File.query.filter_by(id=timeline_file.id).first()
        assert public_file.is_public is True


def test_timeline_pin(app, db):
    """Test that timeline files can be pinned."""
    from sqlalchemy.orm.attributes import flag_modified
    
    with app.app_context():
        user = User(username='pin_test', email='pin@test.com')
        db.session.add(user)
        db.session.flush()
        
        folder = Folder(name='Pin Folder', user_id=user.id, is_root=True)
        db.session.add(folder)
        db.session.flush()
        
        # Create timeline file
        timeline_file = File(
            owner_id=user.id,
            folder_id=folder.id,
            type='timeline',
            title='Pinned Timeline',
            content_json=[],
            metadata_json={}
        )
        db.session.add(timeline_file)
        db.session.commit()
        
        # Pin the file
        timeline_file.metadata_json['is_pinned'] = True
        flag_modified(timeline_file, 'metadata_json')
        db.session.commit()
        
        # Verify
        pinned_file = File.query.filter_by(id=timeline_file.id).first()
        assert pinned_file.metadata_json.get('is_pinned') is True
        
        # Unpin
        pinned_file.metadata_json['is_pinned'] = False
        flag_modified(pinned_file, 'metadata_json')
        db.session.commit()
        
        # Verify unpinned
        unpinned_file = File.query.filter_by(id=timeline_file.id).first()
        assert unpinned_file.metadata_json.get('is_pinned') is False
