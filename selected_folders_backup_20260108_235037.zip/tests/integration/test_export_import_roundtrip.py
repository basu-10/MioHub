"""
Integration tests for Export/Import ZIP backup functionality.

Tests verify that:
1. All file types are exported correctly in JSONL format
2. Directory structure is preserved in export
3. Import can restore exports 1:1
4. Graph workspaces with nodes/edges are exported and imported
5. Images are deduplicated and preserved
"""

import pytest
import json
import zipfile
import io
from datetime import datetime
from blueprints.p2.models import File, Folder, GraphWorkspace, GraphNode, GraphEdge, User
from blueprints.p2.notes_route import export_folder_to_jsonl, import_jsonl_to_folder
from extensions import db


@pytest.fixture
def test_user(app):
    """Create a test user for export/import tests."""
    with app.app_context():
        # Try to find existing user first
        user = User.query.filter_by(username='export_test_user').first()
        
        if user:
            # Clean up any existing test data
            File.query.filter_by(owner_id=user.id).delete()
            Folder.query.filter_by(user_id=user.id).delete()
            db.session.commit()
            yield user
        else:
            # Create new user
            user = User(
                username='export_test_user',
                email='export@test.com',
                user_type='admin',
                total_data_size=0
            )
            user.password_hash = 'test_hash'
            db.session.add(user)
            db.session.commit()
            yield user
            # Don't delete - leave for future test runs


@pytest.fixture
def test_folder_with_all_types(app, test_user):
    """Create a folder with all file types for comprehensive testing."""
    with app.app_context():
        # Create root folder
        root = Folder(
            name='Test Export Root',
            description='Root folder for export tests',
            user_id=test_user.id,
            is_root=True,
            is_public=False
        )
        db.session.add(root)
        db.session.flush()
        
        # Create subfolder
        subfolder = Folder(
            name='Subfolder',
            description='Nested folder',
            user_id=test_user.id,
            parent_id=root.id,
            is_public=True
        )
        db.session.add(subfolder)
        db.session.flush()
        
        # Test data for each file type
        file_types_data = [
            # Text-based types
            ('markdown', 'content_text', '# Hello World\n\nMarkdown content', {'language': 'markdown'}),
            ('code', 'content_text', 'def hello():\n    print("world")', {'language': 'python'}),
            ('proprietary_note', 'content_html', '<p>Rich <b>HTML</b> content</p>', {'description': 'A test note'}),
            
            # JSON-based types
            ('proprietary_whiteboard', 'content_json', {'elements': [{'type': 'rect', 'x': 10, 'y': 10}]}, {}),
            ('diagram', 'content_json', {'nodes': [], 'edges': []}, {}),
            ('todo', 'content_json', {'items': [{'text': 'Task 1', 'done': False}]}, {}),
            ('table', 'content_json', {'sheets': [{'data': [[1, 2], [3, 4]]}]}, {}),
            ('proprietary_blocks', 'content_json', {'blocks': [{'type': 'paragraph', 'data': {'text': 'Block content'}}]}, {}),
            ('proprietary_infinite_whiteboard', 'content_json', {'objects': [], 'camera': {'x': 0, 'y': 0}}, {}),
            
            # Binary type
            ('pdf', 'content_blob', b'%PDF-1.4 fake pdf content', {'mime_type': 'application/pdf'}),
        ]
        
        created_files = []
        
        # Create files in root folder
        for file_type, content_field, content_value, metadata in file_types_data[:5]:
            file = File(
                title=f'Test {file_type}',
                type=file_type,
                folder_id=root.id,
                owner_id=test_user.id,
                is_public=(file_type == 'markdown'),
                metadata_json=metadata
            )
            setattr(file, content_field, content_value)
            db.session.add(file)
            created_files.append(file)
        
        # Create files in subfolder
        for file_type, content_field, content_value, metadata in file_types_data[5:]:
            file = File(
                title=f'Test {file_type} in subfolder',
                type=file_type,
                folder_id=subfolder.id,
                owner_id=test_user.id,
                metadata_json=metadata
            )
            setattr(file, content_field, content_value)
            db.session.add(file)
            created_files.append(file)
        
        db.session.flush()
        
        # Create a proprietary_graph file with workspace
        graph_file = File(
            title='Test Graph',
            type='proprietary_graph',
            folder_id=root.id,
            owner_id=test_user.id,
            content_json={'version': '1.0', 'settings': {}}
        )
        db.session.add(graph_file)
        db.session.flush()
        
        # Create graph workspace
        workspace = GraphWorkspace(
            file_id=graph_file.id,
            owner_id=test_user.id,
            folder_id=root.id,
            settings_json={'theme': 'dark'},
            metadata_json={'description': 'Test graph'}
        )
        db.session.add(workspace)
        db.session.flush()
        
        # Create graph nodes
        node1 = GraphNode(
            graph_id=workspace.id,
            title='Node 1',
            summary='First node',
            position_json={'x': 100, 'y': 100},
            size_json={'w': 200, 'h': 150}
        )
        node2 = GraphNode(
            graph_id=workspace.id,
            title='Node 2',
            summary='Second node',
            position_json={'x': 400, 'y': 100},
            size_json={'w': 200, 'h': 150}
        )
        db.session.add(node1)
        db.session.add(node2)
        db.session.flush()
        
        # Create graph edge
        edge = GraphEdge(
            graph_id=workspace.id,
            source_node_id=node1.id,
            target_node_id=node2.id,
            label='connects to',
            edge_type='directed'
        )
        db.session.add(edge)
        
        db.session.commit()
        
        yield root
        
        # Cleanup
        db.session.delete(root)
        db.session.commit()


def test_export_folder_to_jsonl(app, test_folder_with_all_types, test_user):
    """Test that export_folder_to_jsonl creates correct JSONL format."""
    with app.app_context():
        image_set = set()
        jsonl_lines = []
        
        # Export folder
        export_folder_to_jsonl(test_folder_with_all_types, image_set, jsonl_lines)
        
        # Parse JSONL lines
        records = [json.loads(line) for line in jsonl_lines]
        
        # Verify structure
        folders = [r for r in records if r['record_type'] == 'folder']
        files = [r for r in records if r['record_type'] == 'file']
        workspaces = [r for r in records if r['record_type'] == 'graph_workspace']
        nodes = [r for r in records if r['record_type'] == 'graph_node']
        edges = [r for r in records if r['record_type'] == 'graph_edge']
        
        # Assertions
        assert len(folders) == 2, "Should have root and subfolder"
        assert len(files) == 11, "Should have 10 regular files + 1 graph file"
        assert len(workspaces) == 1, "Should have 1 graph workspace"
        assert len(nodes) == 2, "Should have 2 graph nodes"
        assert len(edges) == 1, "Should have 1 graph edge"
        
        # Verify folder structure
        root_folder = next(r for r in folders if r['name'] == 'Test Export Root')
        assert root_folder['path'] == 'Test Export Root'
        assert root_folder['is_root'] == True
        
        subfolder = next(r for r in folders if r['name'] == 'Subfolder')
        assert 'Subfolder' in subfolder['path']
        assert subfolder['is_public'] == True
        
        # Verify file types
        file_types = {f['type'] for f in files}
        expected_types = {
            'markdown', 'code', 'proprietary_note', 'proprietary_whiteboard',
            'diagram', 'todo', 'table', 'proprietary_blocks',
            'proprietary_infinite_whiteboard', 'pdf', 'proprietary_graph'
        }
        assert file_types == expected_types, f"Missing file types: {expected_types - file_types}"
        
        # Verify content fields
        markdown_file = next(f for f in files if f['type'] == 'markdown')
        assert 'content_text' in markdown_file
        assert '# Hello World' in markdown_file['content_text']
        
        note_file = next(f for f in files if f['type'] == 'proprietary_note')
        assert 'content_html' in note_file
        assert '<b>HTML</b>' in note_file['content_html']
        
        whiteboard_file = next(f for f in files if f['type'] == 'proprietary_whiteboard')
        assert 'content_json' in whiteboard_file
        assert isinstance(whiteboard_file['content_json'], dict)
        
        pdf_file = next(f for f in files if f['type'] == 'pdf')
        assert 'content_blob_base64' in pdf_file
        
        # Verify graph workspace structure
        workspace = workspaces[0]
        assert 'settings_json' in workspace
        assert workspace['settings_json']['theme'] == 'dark'
        
        # Verify nodes
        node_titles = {n['title'] for n in nodes}
        assert node_titles == {'Node 1', 'Node 2'}
        
        # Verify edge
        edge = edges[0]
        assert edge['label'] == 'connects to'
        assert edge['edge_type'] == 'directed'


def test_import_jsonl_to_folder(app, test_user):
    """Test that import_jsonl_to_folder correctly restores data."""
    with app.app_context():
        # Create sample JSONL data
        jsonl_lines = [
            # Folder
            json.dumps({
                "record_type": "folder",
                "id": 999,
                "name": "Import Test",
                "path": "Import Test",
                "parent_id": None,
                "description": "Test import",
                "is_public": False,
                "is_root": False,
                "created_at": "2025-01-01T00:00:00",
                "last_modified": "2025-01-02T00:00:00"
            }),
            # File
            json.dumps({
                "record_type": "file",
                "id": 888,
                "type": "markdown",
                "title": "Imported Markdown",
                "folder_path": "Import Test",
                "folder_id": 999,
                "is_public": True,
                "is_pinned": False,
                "content_text": "# Imported content",
                "metadata_json": {"language": "markdown"},
                "created_at": "2025-01-01T00:00:00",
                "last_modified": "2025-01-02T00:00:00"
            })
        ]
        
        # Create target folder
        target_folder = Folder(
            name='Target',
            user_id=test_user.id,
            is_root=True
        )
        db.session.add(target_folder)
        db.session.commit()
        
        # Import
        stats = import_jsonl_to_folder(jsonl_lines, target_folder, test_user.id)
        db.session.commit()
        
        # Verify stats
        assert stats['folders'] == 1
        assert stats['files'] == 1
        assert len(stats['errors']) == 0
        
        # Verify folder was created
        imported_folder = Folder.query.filter_by(
            name='Import Test',
            user_id=test_user.id
        ).first()
        assert imported_folder is not None
        assert imported_folder.description == 'Test import'
        
        # Verify file was created
        imported_file = File.query.filter_by(
            title='Imported Markdown',
            owner_id=test_user.id
        ).first()
        assert imported_file is not None
        assert imported_file.type == 'markdown'
        assert imported_file.content_text == '# Imported content'
        assert imported_file.is_public == True
        
        # Cleanup
        db.session.delete(imported_folder)
        db.session.delete(target_folder)
        db.session.commit()


def test_roundtrip_export_import(app, test_folder_with_all_types, test_user):
    """Test complete roundtrip: export then import should preserve all data."""
    with app.app_context():
        # Export
        image_set = set()
        jsonl_lines = []
        export_folder_to_jsonl(test_folder_with_all_types, image_set, jsonl_lines)
        
        # Create new target folder for import
        import_target = Folder(
            name='Import Target',
            user_id=test_user.id,
            is_root=False,
            parent_id=None
        )
        db.session.add(import_target)
        db.session.commit()
        
        # Import
        stats = import_jsonl_to_folder(jsonl_lines, import_target, test_user.id)
        db.session.commit()
        
        # Verify import stats
        assert stats['folders'] == 2, f"Expected 2 folders, got {stats['folders']}"
        assert stats['files'] == 11, f"Expected 11 files, got {stats['files']}"
        assert stats['graph_items'] >= 4, f"Expected at least 4 graph items (workspace+2 nodes+1 edge), got {stats['graph_items']}"
        
        # Verify all file types were imported
        imported_files = File.query.filter_by(owner_id=test_user.id).all()
        # Filter out original files
        new_files = [f for f in imported_files if f.folder_id != test_folder_with_all_types.id]
        
        imported_types = {f.type for f in new_files}
        expected_types = {
            'markdown', 'code', 'proprietary_note', 'proprietary_whiteboard',
            'diagram', 'todo', 'table', 'proprietary_blocks',
            'proprietary_infinite_whiteboard', 'pdf', 'proprietary_graph'
        }
        
        missing_types = expected_types - imported_types
        assert len(missing_types) == 0, f"Missing file types after import: {missing_types}"
        
        # Verify graph workspace was imported
        graph_file = next((f for f in new_files if f.type == 'proprietary_graph'), None)
        assert graph_file is not None, "Graph file not imported"
        
        # Verify workspace relationship
        assert hasattr(graph_file, 'graph_workspace'), "Graph workspace not linked"
        workspace = graph_file.graph_workspace
        assert workspace is not None, "Graph workspace is None"
        assert workspace.settings_json.get('theme') == 'dark'
        
        # Verify nodes
        assert len(workspace.nodes) == 2, f"Expected 2 nodes, got {len(workspace.nodes)}"
        node_titles = {n.title for n in workspace.nodes}
        assert node_titles == {'Node 1', 'Node 2'}
        
        # Verify edges
        assert len(workspace.edges) == 1, f"Expected 1 edge, got {len(workspace.edges)}"
        edge = workspace.edges[0]
        assert edge.label == 'connects to'
        
        # Cleanup
        db.session.delete(import_target)
        db.session.commit()


def test_export_preserves_timestamps(app, test_folder_with_all_types):
    """Test that export preserves created_at and last_modified timestamps."""
    with app.app_context():
        image_set = set()
        jsonl_lines = []
        export_folder_to_jsonl(test_folder_with_all_types, image_set, jsonl_lines)
        
        records = [json.loads(line) for line in jsonl_lines]
        folders = [r for r in records if r['record_type'] == 'folder']
        files = [r for r in records if r['record_type'] == 'file']
        
        # Verify timestamps are present
        for folder in folders:
            assert 'created_at' in folder
            assert folder['created_at'] is not None
        
        for file in files:
            assert 'created_at' in file
            assert file['created_at'] is not None


def test_import_handles_errors_gracefully(app, test_user):
    """Test that import handles malformed data gracefully."""
    with app.app_context():
        # Create JSONL with invalid references
        jsonl_lines = [
            json.dumps({
                "record_type": "file",
                "id": 777,
                "type": "markdown",
                "title": "Orphan File",
                "folder_path": "NonExistent/Path",
                "content_text": "# Test"
            })
        ]
        
        target_folder = Folder(
            name='Error Test Target',
            user_id=test_user.id,
            is_root=True
        )
        db.session.add(target_folder)
        db.session.commit()
        
        # Import should not crash
        stats = import_jsonl_to_folder(jsonl_lines, target_folder, test_user.id)
        
        # File should be created in target folder (fallback behavior)
        assert stats['files'] >= 0  # May succeed or fail depending on error handling
        
        # Cleanup
        db.session.delete(target_folder)
        db.session.commit()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
