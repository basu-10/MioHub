"""
Test script for ZIP backup functionality
Tests the ZIP creation and extraction functions without full database backup
"""
import zipfile
import shutil
from pathlib import Path
from datetime import datetime
import json

def test_zip_functionality():
    """Test ZIP creation and extraction"""
    print("="*60)
    print("Testing ZIP Backup Functionality")
    print("="*60)
    
    # Create test directory structure
    test_dir = Path("test_backup_structure")
    if test_dir.exists():
        shutil.rmtree(test_dir)
    
    test_dir.mkdir(exist_ok=True)
    (test_dir / "json").mkdir(exist_ok=True)
    (test_dir / "csv").mkdir(exist_ok=True)
    
    print(f"\n✓ Created test directory: {test_dir}")
    
    # Create test files
    sql_file = test_dir / "test_backup.sql"
    sql_file.write_text("-- Test SQL backup\nCREATE TABLE test (id INT);\n")
    
    json_file = test_dir / "json" / "complete_backup.json"
    json_file.write_text(json.dumps({
        "backup_info": {
            "database": "test_db",
            "timestamp": datetime.now().isoformat()
        },
        "tables": {}
    }, indent=2))
    
    csv_file = test_dir / "csv" / "test.csv"
    csv_file.write_text("id,name\n1,test\n")
    
    readme_file = test_dir / "README.md"
    readme_file.write_text("# Test Backup")
    
    metadata_file = test_dir / "backup_metadata.json"
    metadata_file.write_text(json.dumps({
        "backup_info": {
            "database": "test_db",
            "timestamp": datetime.now().isoformat()
        },
        "statistics": {
            "_total": {
                "total_tables": 1,
                "total_rows": 1
            }
        }
    }, indent=2))
    
    print(f"✓ Created test files")
    
    # Create ZIP file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"test_backup_{timestamp}.zip"
    zip_path = Path("database_backups") / zip_filename
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"\n✓ Creating ZIP archive: {zip_filename}")
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for file_path in test_dir.rglob('*'):
            if file_path.is_file():
                arcname = file_path.relative_to(test_dir.parent)
                zipf.write(file_path, arcname)
                print(f"  Added: {arcname}")
    
    # Get sizes
    original_size = sum(f.stat().st_size for f in test_dir.rglob('*') if f.is_file())
    zip_size = zip_path.stat().st_size
    compression_ratio = (1 - zip_size / original_size) * 100 if original_size > 0 else 0
    
    print(f"\n✓ ZIP archive created successfully!")
    print(f"  Original size: {original_size / 1024:.2f} KB")
    print(f"  Compressed size: {zip_size / 1024:.2f} KB")
    print(f"  Compression: {compression_ratio:.1f}%")
    print(f"  Location: {zip_path.absolute()}")
    
    # Test extraction
    print(f"\n✓ Testing ZIP extraction...")
    extract_dir = Path("database_backups") / f"test_extract_{timestamp}"
    extract_dir.mkdir(parents=True, exist_ok=True)
    
    with zipfile.ZipFile(zip_path, 'r') as zipf:
        zipf.extractall(extract_dir)
        print(f"  Extracted {len(zipf.namelist())} files")
    
    # Verify extracted files
    extracted_test_dir = extract_dir / "test_backup_structure"
    if extracted_test_dir.exists():
        print(f"✓ Extraction successful!")
        print(f"  Directory: {extracted_test_dir}")
        
        # Check files exist
        checks = [
            ("SQL file", extracted_test_dir / "test_backup.sql"),
            ("JSON file", extracted_test_dir / "json" / "complete_backup.json"),
            ("CSV file", extracted_test_dir / "csv" / "test.csv"),
            ("README", extracted_test_dir / "README.md"),
            ("Metadata", extracted_test_dir / "backup_metadata.json")
        ]
        
        all_good = True
        for name, path in checks:
            if path.exists():
                print(f"  ✓ {name} exists")
            else:
                print(f"  ✗ {name} missing")
                all_good = False
        
        if all_good:
            print(f"\n✓ All files verified successfully!")
    else:
        print(f"✗ Extraction directory not found")
    
    # Cleanup
    print(f"\n✓ Cleaning up test files...")
    shutil.rmtree(test_dir)
    shutil.rmtree(extract_dir)
    # Keep the ZIP file for reference
    
    print(f"\n" + "="*60)
    print("✓ TEST COMPLETED SUCCESSFULLY")
    print("="*60)
    print(f"Sample ZIP backup created: {zip_path}")
    print(f"You can safely delete this file or use it for testing.")
    print("="*60)

if __name__ == "__main__":
    try:
        test_zip_functionality()
    except Exception as e:
        print(f"\n✗ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
