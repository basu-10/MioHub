#!/usr/bin/env python3
"""
Test script to demonstrate image deduplication functionality
"""

import hashlib
import os
from PIL import Image
import io

def get_image_hash(filepath):
    """Generate SHA256 hash of image file content."""
    with open(filepath, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def create_test_image(color='red', size=(100, 100)):
    """Create a simple test image with specified color"""
    img = Image.new('RGB', size, color)
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    return buffer.getvalue()

def test_deduplication():
    """Test that identical images produce the same hash"""
    
    # Create test directory
    test_dir = 'test_images'
    os.makedirs(test_dir, exist_ok=True)
    
    # Create two identical red images
    red_data = create_test_image('red')
    
    # Save as different files
    with open(os.path.join(test_dir, 'red1.png'), 'wb') as f:
        f.write(red_data)
    
    with open(os.path.join(test_dir, 'red2.png'), 'wb') as f:
        f.write(red_data)
    
    # Create a different blue image
    blue_data = create_test_image('blue')
    with open(os.path.join(test_dir, 'blue1.png'), 'wb') as f:
        f.write(blue_data)
    
    # Test hashes
    red1_hash = get_image_hash(os.path.join(test_dir, 'red1.png'))
    red2_hash = get_image_hash(os.path.join(test_dir, 'red2.png'))
    blue1_hash = get_image_hash(os.path.join(test_dir, 'blue1.png'))
    
    print("=== Image Deduplication Test ===")
    print(f"Red image 1 hash: {red1_hash}")
    print(f"Red image 2 hash: {red2_hash}")
    print(f"Blue image hash:  {blue1_hash}")
    print()
    
    if red1_hash == red2_hash:
        print("✅ SUCCESS: Identical images produce the same hash")
    else:
        print("❌ FAIL: Identical images should have the same hash")
    
    if red1_hash != blue1_hash:
        print("✅ SUCCESS: Different images produce different hashes")
    else:
        print("❌ FAIL: Different images should have different hashes")
    
    # Simulate filename generation
    user_id = 25
    red_filename = f"{user_id}_{red1_hash}.webp"
    blue_filename = f"{user_id}_{blue1_hash}.webp"
    
    print()
    print("Generated filenames:")
    print(f"Red images would be saved as: {red_filename}")
    print(f"Blue image would be saved as: {blue_filename}")
    print()
    
    # Show storage savings
    red_size = len(red_data)
    blue_size = len(blue_data)
    
    print("Storage comparison:")
    print(f"Without deduplication: 2 red images + 1 blue = {red_size * 2 + blue_size} bytes")
    print(f"With deduplication:    1 red image  + 1 blue = {red_size + blue_size} bytes")
    print(f"Space saved: {red_size} bytes ({red_size / (red_size * 2 + blue_size) * 100:.1f}%)")
    
    # Cleanup
    import shutil
    shutil.rmtree(test_dir)
    
    print("\n=== Test completed ===")

if __name__ == "__main__":
    test_deduplication()