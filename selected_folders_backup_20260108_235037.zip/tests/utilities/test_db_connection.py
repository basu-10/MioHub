#!/usr/bin/env python3
"""
Test database connection to diagnose MySQL connectivity issues
"""

import os
import config
import mysql.connector
from mysql.connector import Error

# Get database credentials
DB_NAME = config.DB_NAME
DB_USER = config.DB_USER
DB_PASSWORD = config.DB_PASSWORD
DB_PORT = config.DB_PORT
DB_HOST = config.DB_HOST

def test_mysql_connection():
    """Test basic MySQL connection"""
    try:
        print(f"Testing connection to MySQL...")
        print(f"Host: {DB_HOST}")
        print(f"Port: {DB_PORT}")
        print(f"Database: {DB_NAME}")
        print(f"User: {DB_USER}")
        print("-" * 50)
        
        # Test basic connection
        connection = mysql.connector.connect(
            host=DB_HOST,
            port=int(DB_PORT),
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            autocommit=True,
            charset='utf8mb4',
            collation='utf8mb4_unicode_ci'
        )
        
        if connection.is_connected():
            db_info = connection.get_server_info()
            print(f"✅ Successfully connected to MySQL Server version {db_info}")
            
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE();")
            record = cursor.fetchone()
            print(f"✅ Connected to database: {record[0]}")
            
            # Test table access
            cursor.execute("SHOW TABLES;")
            tables = cursor.fetchall()
            print(f"✅ Found {len(tables)} tables in database")
            
            # Test user table specifically
            cursor.execute("SELECT COUNT(*) FROM user;")
            user_count = cursor.fetchone()[0]
            print(f"✅ Found {user_count} users in user table")
            
            return True
            
    except Error as e:
        print(f"❌ Error connecting to MySQL: {e}")
        return False
    finally:
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()
            print("🔒 MySQL connection closed")

def test_sqlalchemy_connection():
    """Test SQLAlchemy connection using Flask app config"""
    try:
        from sqlalchemy import create_engine, text
        
        database_url = f"mysql+mysqlconnector://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        print(f"\nTesting SQLAlchemy connection...")
        print(f"Connection URL: {database_url.replace(DB_PASSWORD, '***')}")
        print("-" * 50)
        
        engine = create_engine(database_url, 
                             pool_pre_ping=True,
                             pool_recycle=300,
                             pool_timeout=20)
        
        with engine.connect() as connection:
            result = connection.execute(text("SELECT 'SQLAlchemy connection successful' as message"))
            print(f"✅ {result.fetchone()[0]}")
            
            result = connection.execute(text("SELECT COUNT(*) FROM user"))
            user_count = result.fetchone()[0]
            print(f"✅ SQLAlchemy found {user_count} users")
            
            return True
            
    except Exception as e:
        print(f"❌ SQLAlchemy connection error: {e}")
        return False

if __name__ == "__main__":
    print("🔍 Database Connection Diagnostic Tool")
    print("=" * 60)
    
    # Check configuration values
    missing_vars = []
    if not config.DB_NAME:
        missing_vars.append('DB_NAME')
    if not config.DB_USER:
        missing_vars.append('DB_USER')
    if not config.DB_PASSWORD:
        missing_vars.append('DB_PASSWORD')
    
    if missing_vars:
        print(f"❌ Missing configuration values: {', '.join(missing_vars)}")
        print("Please check your config.py file")
        exit(1)
    
    # Test connections
    mysql_ok = test_mysql_connection()
    sqlalchemy_ok = test_sqlalchemy_connection()
    
    print("\n" + "=" * 60)
    if mysql_ok and sqlalchemy_ok:
        print("✅ All database connections successful!")
        print("The issue may be related to connection pooling or session management.")
    else:
        print("❌ Database connection issues detected.")
        print("Please check your MySQL server status and credentials.")