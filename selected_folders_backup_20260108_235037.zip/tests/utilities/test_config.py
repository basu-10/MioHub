#!/usr/bin/env python3
"""
Test the Python configuration module to ensure everything works correctly.
"""

import config

def test_config_module():
    """Test the configuration module functionality."""
    print("🧪 Testing Python Configuration Module")
    print("=" * 50)
    
    try:
        # Test database configuration
        print("\n📊 Database Configuration:")
        print(f"  Name: {config.DB_NAME}")
        print(f"  User: {config.DB_USER}")
        print(f"  Host: {config.DB_HOST}")
        print(f"  Port: {config.DB_PORT}")
        
        # Test Flask configuration
        print("\n🌶️ Flask Configuration:")
        secret_key = config.SECRET_KEY
        print(f"  Secret Key: {'*' * 20}...{secret_key[-10:] if secret_key else 'NOT SET'}")
        
        # Test AI configuration
        print("\n🤖 AI Configuration:")
        print(f"  Provider: {config.PROVIDER}")
        print(f"  Model: {config.LLM_MODEL}")
        groq_key = config.GROQ_API_KEY
        print(f"  Groq API Key: {'*' * 20}...{groq_key[-10:] if groq_key else 'NOT SET'}")
        print(f"  Delimiter: {repr(config.AI_DELIMITER)}")
        print(f"  Max Input Chars: {config.MAX_INPUT_CHARS}")
        
        # Test helper functions
        print("\n🔧 Helper Functions:")
        print(f"  Database URI: {config.get_database_uri()[:50]}...")
        print(f"  API Key for Groq: {'*' * 20}...{config.get_api_key_for_provider('groq')[-10:]}")
        
        # Test backward compatibility interface
        print("\n🔄 Testing Backward Compatibility:")
        compat_config = config.get_config()
        print(f"  get_db_name(): {compat_config.get_db_name()}")
        print(f"  get_secret_key(): {'*' * 20}...{compat_config.get_secret_key()[-10:]}")
        print(f"  get('database.name'): {compat_config.get('database.name')}")
        print(f"  get('nonexistent.key', 'DEFAULT'): {compat_config.get('nonexistent.key', 'DEFAULT')}")
        
        # Test configuration dictionaries
        print("\n📚 Configuration Dictionaries:")
        db_config = compat_config.get_database_config()
        print(f"  Database config keys: {list(db_config.keys())}")
        ai_config = compat_config.get_ai_config()
        print(f"  AI config keys: {list(ai_config.keys())}")
        
        print("\n✅ All configuration tests passed!")
        return True
        
    except Exception as e:
        print(f"\n❌ Configuration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_required_values():
    """Test that required configuration values are set."""
    print("\n🔍 Testing Required Configuration Values")
    print("=" * 50)
    
    required_values = {
        'DB_NAME': config.DB_NAME,
        'DB_USER': config.DB_USER,
        'DB_PASSWORD': config.DB_PASSWORD,
        'DB_HOST': config.DB_HOST,
        'SECRET_KEY': config.SECRET_KEY,
        'PROVIDER': config.PROVIDER,
        'LLM_MODEL': config.LLM_MODEL,
    }
    
    all_set = True
    for key, value in required_values.items():
        if value:
            print(f"✅ {key}: Set")
        else:
            print(f"❌ {key}: NOT SET")
            all_set = False
    
    if all_set:
        print("\n✅ All required values are configured")
    else:
        print("\n⚠️ Some required values are missing")
    
    return all_set

if __name__ == "__main__":
    print("🚀 Python Configuration Test Suite")
    print("=" * 50)
    
    values_valid = test_required_values()
    config_valid = test_config_module()
    
    print("\n" + "=" * 50)
    if values_valid and config_valid:
        print("✅ All tests passed! Configuration is working correctly.")
        exit(0)
    else:
        print("❌ Some tests failed. Please review the configuration.")
        exit(1)
