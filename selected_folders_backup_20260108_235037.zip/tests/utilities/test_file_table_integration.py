"""
Quick test to verify File records appear in folder view.
Queries the database and prints what would be shown in the UI.
"""

import sys
import os

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.join(current_dir, '..', '..')
sys.path.insert(0, project_root)

from flask import Flask
from extensions import db
from blueprints.p2.models import File, Folder, User
import config

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = config.get_database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def test_folder_view():
    with app.app_context():
        # Get testuser
        testuser = User.query.filter_by(username='testuser').first()
        if not testuser:
            print("❌ testuser not found")
            return
        
        # Get root folder
        root_folder = Folder.query.filter_by(user_id=testuser.id, parent_id=None).first()
        if not root_folder:
            print("❌ No root folder")
            return
        
        print("=" * 70)
        print(f"📂 Folder: {root_folder.name} (ID: {root_folder.id})")
        print(f"👤 Owner: {testuser.username}")
        print("=" * 70)
        
        # Query items (same as folder_routes.py)
        notes = File.query.filter_by(folder_id=root_folder.id, owner_id=testuser.id, type='note').all()
        boards = File.query.filter_by(folder_id=root_folder.id, owner_id=testuser.id, type='whiteboard').all()
        files = File.query.filter_by(folder_id=root_folder.id, owner_id=testuser.id).filter(File.type.notin_(['note', 'whiteboard'])).all()
        
        print(f"\n📝 NOTES ({len(notes)}) [File.type='note']")
        for note in notes:
            print(f"  - {note.title} (ID: {note.id}, {note.get_content_size()} bytes)")
        
        print(f"\n🎨 BOARDS ({len(boards)}) [File.type='whiteboard']")
        for board in boards:
            print(f"  - {board.title} (ID: {board.id}, {board.get_content_size()} bytes)")
        
        print(f"\n📄 OTHER FILES ({len(files)}) [markdown, todo, diagram, book, etc.]")
        for file in files:
            size = file.get_content_size()
            desc = file.metadata_json.get('description', '') if file.metadata_json else ''
            public = '🌐 PUBLIC' if file.is_public else '🔒 Private'
            print(f"  - {file.title}")
            print(f"    Type: {file.type} | Size: {size} bytes | {public}")
            if desc:
                print(f"    Description: {desc}")
        
        print("\n" + "=" * 70)
        print("✅ File table integration working!")
        print(f"   View at: http://localhost:5555/folders/{root_folder.id}")
        print("=" * 70)

if __name__ == '__main__':
    test_folder_view()
