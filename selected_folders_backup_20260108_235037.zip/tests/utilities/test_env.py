#!/usr/bin/env python3
import config
import os

vars_to_check = [
    ("DB_NAME", config.DB_NAME),
    ("DB_USER", config.DB_USER),
    ("DB_PASSWORD", config.DB_PASSWORD),
    ("DB_PORT", config.DB_PORT),
    ("PROVIDER", config.PROVIDER),
    ("LLM_MODEL", config.LLM_MODEL),
    ("GROQ_API_KEY", config.GROQ_API_KEY),
    ("SECRET_KEY", config.SECRET_KEY),
]

print("Checking configuration values...")
for var_name, value in vars_to_check:
    if value is None or value == "":
        print(f"❌ Missing: {var_name}")
    else:
        print(f"✅ {var_name}={value}")
