"""
Test Document Parsers for Chat Attachments (Phase 2)
Tests all parsing functions from utilities_main.py
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from utilities_main import (
    calculate_file_hash,
    detect_file_encoding,
    parse_pdf_to_text,
    parse_docx_to_text,
    parse_excel_to_text,
    extract_text_from_image_ocr,
    read_text_file_safely,
    parse_document_for_chat,
    get_file_type_from_extension,
    PYPDF_AVAILABLE,
    DOCX_AVAILABLE,
    OPENPYXL_AVAILABLE,
    OCR_AVAILABLE
)
import tempfile
import os


def test_library_availability():
    """Test which parsing libraries are available"""
    print("=" * 60)
    print("LIBRARY AVAILABILITY CHECK")
    print("=" * 60)
    print(f"✓ pypdf available: {PYPDF_AVAILABLE}")
    print(f"✓ python-docx available: {DOCX_AVAILABLE}")
    print(f"✓ openpyxl available: {OPENPYXL_AVAILABLE}")
    print(f"✓ pytesseract available: {OCR_AVAILABLE}")
    
    if not OCR_AVAILABLE:
        print("\n⚠️  WARNING: Tesseract OCR not available")
        print("   Download from: https://github.com/UB-Mannheim/tesseract/wiki")
        print("   Set TESSERACT_CMD in config.py after installation")
    
    print()


def test_file_hash():
    """Test file hash calculation"""
    print("=" * 60)
    print("TEST: File Hash Calculation")
    print("=" * 60)
    
    # Create temp file
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        f.write("Test content for hashing")
        temp_path = f.name
    
    try:
        hash1 = calculate_file_hash(temp_path)
        print(f"✓ Hash calculated: {hash1[:16]}...")
        
        # Same content should produce same hash
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f2:
            f2.write("Test content for hashing")
            temp_path2 = f2.name
        
        hash2 = calculate_file_hash(temp_path2)
        
        if hash1 == hash2:
            print(f"✓ Duplicate detection works (same hash for same content)")
        else:
            print(f"✗ ERROR: Different hashes for same content")
        
        os.unlink(temp_path2)
    finally:
        os.unlink(temp_path)
    
    print()


def test_encoding_detection():
    """Test file encoding detection"""
    print("=" * 60)
    print("TEST: Encoding Detection")
    print("=" * 60)
    
    # Create temp file with UTF-8
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', delete=False, suffix='.txt') as f:
        f.write("Test content with émojis 🎉")
        temp_path = f.name
    
    try:
        encoding = detect_file_encoding(temp_path)
        print(f"✓ Detected encoding: {encoding}")
    finally:
        os.unlink(temp_path)
    
    print()


def test_text_file_parsing():
    """Test text file parsing"""
    print("=" * 60)
    print("TEST: Text File Parsing")
    print("=" * 60)
    
    test_content = """# Sample Python File
def hello():
    print("Hello, World!")
    return True
"""
    
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.py') as f:
        f.write(test_content)
        temp_path = f.name
    
    try:
        content = read_text_file_safely(temp_path)
        if "def hello():" in content:
            print(f"✓ Text file parsed successfully")
            print(f"  Content length: {len(content)} characters")
        else:
            print(f"✗ ERROR: Content not parsed correctly")
    finally:
        os.unlink(temp_path)
    
    print()


def test_file_type_detection():
    """Test file type detection from extensions"""
    print("=" * 60)
    print("TEST: File Type Detection")
    print("=" * 60)
    
    test_cases = [
        ('document.pdf', 'pdf'),
        ('spreadsheet.xlsx', 'xlsx'),
        ('report.docx', 'docx'),
        ('image.png', 'image'),
        ('script.py', 'py'),
        ('config.yaml', 'yaml'),
        ('data.json', 'json'),
        ('README.md', 'md'),
    ]
    
    for filename, expected_type in test_cases:
        detected_type = get_file_type_from_extension(filename)
        status = "✓" if detected_type == expected_type else "✗"
        print(f"{status} {filename} → {detected_type} (expected: {expected_type})")
    
    print()


def test_dispatcher():
    """Test parse_document_for_chat dispatcher"""
    print("=" * 60)
    print("TEST: Document Parsing Dispatcher")
    print("=" * 60)
    
    # Test text file parsing
    test_content = "Sample text content for dispatcher test"
    
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
        f.write(test_content)
        temp_path = f.name
    
    try:
        content, method = parse_document_for_chat(temp_path, 'txt')
        if content == test_content:
            print(f"✓ Dispatcher works correctly")
            print(f"  Parse method: {method}")
        else:
            print(f"✗ ERROR: Dispatcher returned wrong content")
    finally:
        os.unlink(temp_path)
    
    print()


def main():
    """Run all tests"""
    print("\n")
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 10 + "DOCUMENT PARSER TEST SUITE" + " " * 21 + "║")
    print("║" + " " * 12 + "Chat Attachments - Phase 2" + " " * 19 + "║")
    print("╚" + "=" * 58 + "╝")
    print()
    
    try:
        test_library_availability()
        test_file_hash()
        test_encoding_detection()
        test_text_file_parsing()
        test_file_type_detection()
        test_dispatcher()
        
        print("=" * 60)
        print("✅ ALL TESTS COMPLETED")
        print("=" * 60)
        print()
        print("Next steps:")
        print("1. Install Tesseract OCR for image text extraction (if not available)")
        print("2. Create test fixtures (sample PDF, DOCX, XLSX files)")
        print("3. Proceed to Phase 3: Backend Routes & Services")
        print()
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
