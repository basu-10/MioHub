"""
Utility script to analyze undo/redo implementation across the codebase.
Checks for keyboard handlers and undo/redo patterns in editor components.
"""

import re
import json
from pathlib import Path


def analyze_file(file_path):
    """Analyze a file for undo/redo implementation patterns."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        results = {
            'file': str(file_path),
            'undo_patterns': [],
            'redo_patterns': [],
            'keyboard_handlers': [],
            'issues': []
        }
        
        # Check for undo patterns
        undo_patterns = [
            r'undo\s*\(\s*\)',
            r'ctrl\s*\+\s*z',
            r'keydown.*z',
            r'undoStack',
            r'historyLimit',
            r'summernote.*undo'
        ]
        
        for pattern in undo_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                results['undo_patterns'].extend(matches)
        
        # Check for redo patterns
        redo_patterns = [
            r'redo\s*\(\s*\)',
            r'ctrl\s*\+\s*y',
            r'keydown.*y',
            r'redoStack'
        ]
        
        for pattern in redo_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                results['redo_patterns'].extend(matches)
        
        # Check for keyboard event handlers
        keyboard_patterns = [
            r'addEventListener\s*\(\s*[\'"]keydown[\'"]',
            r'onkeydown\s*=',
            r'keydown.*function',
            r'e\.key\s*===?\s*[\'"]z[\'"]',
            r'e\.key\s*===?\s*[\'"]y[\'"]'
        ]
        
        for pattern in keyboard_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                results['keyboard_handlers'].extend(matches)
        
        # Check for potential issues
        if file_path.name.endswith('.html') and 'editor' in content.lower():
            if not results['undo_patterns'] and not results['redo_patterns']:
                results['issues'].append('Editor file without undo/redo implementation')
        
        return results
        
    except Exception as e:
        return {'file': str(file_path), 'error': str(e)}


def main():
    """Main function to analyze the entire codebase."""
    base_dir = Path(__file__).parent.parent.parent
    
    # Files to analyze
    target_files = []
    
    # Find HTML templates and JS files
    for pattern in ['**/*.html', '**/*.js']:
        target_files.extend(base_dir.glob(pattern))
    
    # Filter to relevant files
    relevant_files = []
    for file_path in target_files:
        file_str = str(file_path).lower()
        if any(keyword in file_str for keyword in ['note', 'board', 'editor', 'calculator', 'whiteboard']):
            relevant_files.append(file_path)
    
    print("🔍 Undo/Redo Functionality Analysis")
    print("=" * 50)
    
    all_results = []
    summary = {
        'files_analyzed': 0,
        'files_with_undo': 0,
        'files_with_redo': 0,
        'files_with_keyboard_handlers': 0,
        'potential_issues': 0
    }
    
    for file_path in relevant_files:
        if file_path.is_file():
            print(f"\n📄 Analyzing: {file_path.name}")
            results = analyze_file(file_path)
            all_results.append(results)
            summary['files_analyzed'] += 1
            
            if results.get('undo_patterns'):
                summary['files_with_undo'] += 1
                print(f"  ✅ Undo patterns found: {len(results['undo_patterns'])}")
            
            if results.get('redo_patterns'):
                summary['files_with_redo'] += 1
                print(f"  ✅ Redo patterns found: {len(results['redo_patterns'])}")
            
            if results.get('keyboard_handlers'):
                summary['files_with_keyboard_handlers'] += 1
                print(f"  ⌨️  Keyboard handlers found: {len(results['keyboard_handlers'])}")
            
            if results.get('issues'):
                summary['potential_issues'] += 1
                print(f"  ⚠️  Issues: {', '.join(results['issues'])}")
            
            if not results.get('undo_patterns') and not results.get('redo_patterns'):
                print(f"  ❌ No undo/redo patterns found")
    
    print("\n" + "=" * 50)
    print("📊 SUMMARY")
    print("=" * 50)
    print(f"Files analyzed: {summary['files_analyzed']}")
    print(f"Files with undo functionality: {summary['files_with_undo']}")
    print(f"Files with redo functionality: {summary['files_with_redo']}")
    print(f"Files with keyboard handlers: {summary['files_with_keyboard_handlers']}")
    print(f"Potential issues found: {summary['potential_issues']}")
    
    # Save detailed results to JSON
    output_file = base_dir / 'undo_redo_analysis.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            'summary': summary,
            'detailed_results': all_results
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Detailed results saved to: {output_file}")


if __name__ == "__main__":
    main()
