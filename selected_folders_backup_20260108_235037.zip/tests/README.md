# Test Suite Organization

This directory contains all tests for the Flask multi-product application, organized into a clear structure for maintainability and clarity.

## Directory Structure

```
tests/
├── conftest.py              # Pytest configuration and shared fixtures
├── unit/                    # Unit tests (no database/Flask app required)
│   ├── test_calculator.py
│   ├── test_description_parsing.py
│   ├── test_syntax_errors.py
│   ├── test_table_functionality.py
│   ├── test_template_logic.py
│   ├── test_utilities.py
│   └── test_values.py
├── integration/             # Integration tests (require database/app context)
│   ├── test_send_to.py
│   ├── test_send_to_images.py
│   ├── test_send_to_base64.py
│   └── test_user_folders.py
└── utilities/               # Diagnostic and demo scripts
    ├── analyze_undo_redo.py
    ├── demo_image_deduplication.py
    ├── demo_zip_backup.py
    ├── test_backup_with_images.py
    ├── test_config.py
    ├── test_db_connection.py
    └── test_env.py
```

## Running Tests

### All Tests
```powershell
pytest
```

### Unit Tests Only
```powershell
pytest tests/unit/
```

### Integration Tests Only
```powershell
pytest tests/integration/
```

### With Coverage Report
```powershell
pytest --cov=blueprints --cov-report=html
```

### Specific Test File
```powershell
pytest tests/unit/test_calculator.py -v
```

### Utility Scripts (Manual Execution)
```powershell
python tests/utilities/test_db_connection.py
python tests/utilities/test_config.py
python tests/utilities/analyze_undo_redo.py
```

## Test Categories

### Unit Tests (`tests/unit/`)
Isolated tests that don't require database or Flask application context:
- **test_calculator.py** - Calculator logic and custom functions
- **test_description_parsing.py** - JSON description parsing for notes
- **test_syntax_errors.py** - Python syntax validation for all project files
- **test_table_functionality.py** - Table separator detection logic
- **test_template_logic.py** - Template rendering conditions
- **test_utilities.py** - Utility function validation
- **test_values.py** - Value parsing and constants

### Integration Tests (`tests/integration/`)
Tests requiring database and Flask app context:
- **test_send_to.py** - Note/folder copying between users
- **test_send_to_images.py** - Image deduplication during copy
- **test_send_to_base64.py** - Base64 image conversion during copy
- **test_user_folders.py** - User folder initialization

### Utility Scripts (`tests/utilities/`)
Standalone diagnostic and demonstration scripts:
- **test_config.py** - Configuration validation
- **test_db_connection.py** - Database connectivity diagnostics
- **test_env.py** - Environment setup verification
- **analyze_undo_redo.py** - Undo/redo implementation analysis
- **demo_image_deduplication.py** - Image hashing demonstration
- **demo_zip_backup.py** - Backup functionality demonstration

## Fixtures (conftest.py)

### Unit Test Fixtures
- `dummy_user` - Mock user object for testing
- `dummy_db` - Mock database for testing
- `no_external_flash` - Disable Flask flash messages in tests

### Integration Test Fixtures
- `app` - Flask application instance
- `db` - Database session with rollback
- `client` - Flask test client
- `runner` - Flask CLI test runner

## Writing New Tests

### Unit Test Template
```python
"""
Brief description of what this module tests.
"""
import pytest

def test_something():
    """Test a specific behavior."""
    result = my_function()
    assert result == expected_value
```

### Integration Test Template
```python
"""
Brief description of integration test.
"""
import pytest
from blueprints.p2.models import User, db

@pytest.mark.integration
def test_something(app):
    """Test with database context."""
    with app.app_context():
        user = User(username='test', email='test@example.com')
        db.session.add(user)
        db.session.commit()
        
        # Test logic here
        assert user.id is not None
```

## Test Markers

- `@pytest.mark.integration` - Marks tests requiring database/app context
- `@pytest.mark.slow` - Marks slow tests (can be skipped with `-m "not slow"`)

## Best Practices

1. **Keep unit tests fast** - No database, no Flask context
2. **Integration tests should be isolated** - Use rollback fixtures
3. **Use descriptive names** - Test names should explain what they verify
4. **One assertion per test** - Makes failures easier to diagnose
5. **Cleanup after integration tests** - Delete created data in teardown

## Continuous Integration

Tests are designed to run in CI/CD pipelines. Ensure:
- Database is available for integration tests
- Environment variables are set
- Virtual environment is activated

## Troubleshooting

### Pytest Not Found
```powershell
# Activate virtual environment first
.\.venv\Scripts\Activate.ps1
python -m pytest tests/
```

### Database Connection Errors
```powershell
# Test database connectivity first
python tests/utilities/test_db_connection.py
```

### Import Errors
```powershell
# Ensure you're in the project root
cd "d:\dev_work\web_dev\personal site\from pythonanywhere\myproject_backup.v2.16"
```

## Migration from Old Structure

The old `test/` folder has been consolidated into this structured approach:
- Naive test scripts → Converted to proper pytest format
- Utility scripts → Moved to `tests/utilities/`
- Migration scripts → Moved to project root
- Debug scripts → Moved to `scripts/`

All tests are now in one place with consistent naming and organization.
