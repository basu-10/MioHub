"""Project helper scripts (importable for unit tests)."""
